
 package com.aware.j2k.demo;

//  ******************************************************************
//  Copyright 2000 Aware, Inc.
//
//  $Workfile: AwJ2kDemoDriver.java $    $Revision: 9 $
//  Last Modified: $Date: 6/23/04 3:07p $ by: $Author: Esharp $
//
//  File   : AwJ2kDemoDriver.java
//  Creator: Stephen DelMarco
//
//  a demonstration driver showing how to use the java-wrapped
//  JPEG2000 library
//
//  ******************************************************************

 import java.io.*;
 import com.aware.j2k.codec.engine.*;
import com.aware.j2k.codec.engine.AwJ2kParameters;


/**
  * This class is a demonstration driver showing how
  * to use the java-wrapped JPEG2000 library. Each test
  * is a stand-alone test, i.e., not requiring the execution
  * of or results from any other test.
  *
  * @author Stephen DelMarco
  * @version 1.0,   Copyright (c) Aware, Inc., 2002
  *
  */

 public class AwJ2kDemoDriver {






/**
  * This method is the main method.
  *
  * @param argv command line arguments
  */

  public static void main(String argv[])
{
// ******************************************************************
//
// ******************************************************************

// ---------- handle command line interface

    if ( (argv.length != 0) && (argv.length != 1)) {    // --- validate command line length
      System.out.println(
        "***Error: there are "+argv.length+" command line arguments when there should be 0 or 1");
	  System.exit(1);
      }

    if (argv.length == 0) { // --- display usage
      System.out.println("  Usage: java AwJ2kDemoDriver <options>");
      System.out.println("     Options are (in exact order):");
      System.out.println("     <demo number>   demo number, between 1 and 46, inclusive");
	  System.exit(0);
      }

    String demoNumString    = argv[0];
    int demoNum             = -1;
    try {
        demoNum = Integer.parseInt(demoNumString.trim());
    }
    catch (NumberFormatException exc) {
        System.out.println("**NumberFormatException= "+exc);
        System.exit(1);
    }


// ---------- perform demo

    runDemo(demoNum);

}
/**
  * This method runs the demo.
  *
  * @param demoNum  the demonstration number
  *
  */

  public static void runDemo(int demoNum)
{
// ******************************************************************
//
// ******************************************************************
    switch (demoNum) {
    case 1:
        runDemo1();
        break;
    case 2:
        runDemo2();
        break;
    case 3:
        runDemo3();
        break;
    case 4:
        runDemo4();
        break;
    case 5:
        runDemo5();
        break;
    case 6:
        runDemo6();
        break;
    case 7:
        runDemo7();
        break;
    case 8:
        runDemo8();
        break;
    case 9:
        runDemo9();
        break;
    case 10:
        runDemo10();
        break;
    case 11:
        runDemo11();
        break;
    case 12:
        runDemo12();
        break;
    case 13:
        runDemo13();
        break;
    case 14:
        runDemo14();
        break;
    case 15:
        runDemo15();
        break;
    case 16:
        runDemo16();
        break;
    case 17:
        runDemo17();
        break;
    case 18:
        runDemo18();
        break;
    case 19:
        runDemo19();
        break;
    case 20:
        runDemo20();
        break;
    case 21:
        runDemo21();
        break;
    case 22:
        runDemo22();
        break;
    case 23:
        runDemo23();
        break;
    case 24:
        runDemo24();
        break;
    case 25:
        runDemo25();
        break;
    case 26:
        runDemo26();
        break;
    case 27:
        runDemo27();
        break;
    case 28:
        runDemo28();
        break;
    case 29:
        runDemo29();
        break;
    case 30:
        runDemo30();
        break;
    case 31:
        runDemo31();
        break;
    case 32:
        runDemo32();
        break;
    case 33:
        runDemo33();
        break;
    case 34:
        runDemo34();
        break;
    case 35:
        runDemo35();
        break;
    case 36:
        runDemo36();
        break;
    case 37:
        runDemo37();
        break;
    case 38:
        runDemo38();
        break;
    case 39:
        runDemo39();
        break;
    case 40:
        runDemo40();
        break;
    case 41:
        runDemo41();
        break;
    case 42:
        runDemo42();
        break;
    case 43:
        runDemo43();
        break;
    case 44:
        runDemo44();
        break;
    case 45:
        runDemo45();
        break;
    case 46:
        runDemo46();
        break;
    case 47:
        runDemo47();
        break;
    case 48:
        runDemo48();
        break;
    case 49:
        runDemo49();
        break;
    case 50:
        runDemo50();
        break;
    case 51:
        runDemo51();
        break;


    default:
        System.out.println("** Sorry, there is no demo corresponding to this demo number");
        return;
    }


}
/**
  * This demo shows use of the image file input and image file output
  * methods. An input image is compressed and the compressed image is
  * output.
  *
  */
  public static void runDemo1()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int inputFileType       = AwJ2kParameters.AW_J2K_FORMAT_BMP;
    String outputFileName   = "lena_cmp1.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFileType(inputFileName, inputFileType);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows use of the image input and image file output
  * methods. An input image is read in, and the image data is passed
  * to the input image setter method. The image data is compressed
  * and the compressed image is output.
  *
  */
  public static void runDemo2()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int inputFileType       = AwJ2kParameters.AW_J2K_FORMAT_BMP;
    String outputFileName   = "lena_cmp2.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;

// ---------- run demo

    AwJ2k codec = null;
    try {
        byte[] imageBuffer      = AwJ2kDemoUtils.readImageFile(inputFileName);
        int imageBufferLength   = imageBuffer.length;
        codec = new AwJ2k();
        codec.AwJ2kSetInputImage(imageBuffer, imageBufferLength);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows use of the image input and image file output
  * methods. An input image is read in, and the image data is passed
  * to the input image type setter method. The image data is compressed
  * and the compressed image is output.
  *
  */
  public static void runDemo3()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int inputFileType       = AwJ2kParameters.AW_J2K_FORMAT_BMP;
    String outputFileName   = "lena_cmp3.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;

// ---------- run demo

    AwJ2k codec = null;
    try {
        byte[] imageBuffer      = AwJ2kDemoUtils.readImageFile(inputFileName);
        int imageBufferLength   = imageBuffer.length;
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageType(inputFileType, imageBuffer, imageBufferLength);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows use of the raw image input and image file output
  * methods. A raw input image is read in, and the image data is passed
  * to the input image setter method. The image data is compressed
  * and the compressed image is output.
  *
  */
  public static void runDemo4()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena_gray.raw";
    String outputFileName   = "lena_cmp4.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    int numRows             = 512;
    int numCols             = 512;
    int nChannels           = 1;
    int bpp                 = 8;
    boolean isInterleaved   = false;

// ---------- run demo

    AwJ2k codec = null;
    try {
        byte[] imageBuffer      = AwJ2kDemoUtils.readImageFile(inputFileName);
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageRaw(
                                imageBuffer,
                                numRows,
                                numCols,
                                nChannels,
                                bpp,
                                isInterleaved);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to decompress a J2K compressed image.
  * Compressed and decompressed file names are passed to setter and
  * getter methods to perform compressed image loading, decompression,
  * and output of decompressed data.
  *
  */
  public static void runDemo5()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int inputFileType       = AwJ2kParameters.AW_J2K_FORMAT_BMP;
    String outputFileName   = "lena_cmp5.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String recOutputFileName= "lena_rec5.bmp";
    int recOutputFileType   = AwJ2kParameters.AW_J2K_FORMAT_BMP;

// ---------- run demo

    AwJ2k codec = null;
    try {
// --------------------------------------------- compress
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFileType(inputFileName, inputFileType);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// --------------------------------------------- decompress
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFileType(outputFileName, outputFileType);
        codec.AwJ2kSetOutputType(recOutputFileType);
        codec.AwJ2kGetOutputImageFile(recOutputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows use of the image input and image output
  * methods. A raw input image is read in, and the image data is passed
  * to the input image setter method. The image data is compressed.
  * The compressed image data is obtained and output to a file.
  *
  */
  public static void runDemo6()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena_gray.raw";
    String outputFileName   = "lena_cmp6.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    int numRows             = 512;
    int numCols             = 512;
    int nChannels           = 1;
    int bpp                 = 8;
    boolean isInterleaved   = false;

// ---------- run demo

    AwJ2k codec = null;
    try {
        byte[] imageBuffer      = AwJ2kDemoUtils.readImageFile(inputFileName);
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageRaw(
                                imageBuffer,
                                numRows,
                                numCols,
                                nChannels,
                                bpp,
                                isInterleaved);
        codec.AwJ2kSetOutputType(outputFileType);
        AwOutputImageValue valueObj = codec.AwJ2kGetOutputImage();
        byte[] outBuffer  = valueObj.getImage();
        int outBufferLen  = valueObj.getImageLength();
        AwJ2kDemoUtils.writeImageFile(outputFileName, outBuffer, outBufferLen);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows use of the image input and image output
  * type methods. A raw input image is read in, and the image data is passed
  * to the input image setter method. The image data is compressed.
  * The compressed image data is obtained by supplying the output data
  * type, and the compressed data is output to a file.
  *
  */
  public static void runDemo7()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena_gray.raw";
    String outputFileName   = "lena_cmp7.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    int numRows             = 512;
    int numCols             = 512;
    int nChannels           = 1;
    int bpp                 = 8;
    boolean isInterleaved   = false;

// ---------- run demo

    AwJ2k codec = null;
    try {
        byte[] imageBuffer      = AwJ2kDemoUtils.readImageFile(inputFileName);
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageRaw(
                                imageBuffer,
                                numRows,
                                numCols,
                                nChannels,
                                bpp,
                                isInterleaved);
        AwOutputImageValue valueObj = codec.AwJ2kGetOutputImageType(outputFileType);
        byte[] outBuffer  = valueObj.getImage();
        int outBufferLen  = valueObj.getImageLength();
        AwJ2kDemoUtils.writeImageFile(outputFileName, outBuffer, outBufferLen);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows use of the image input and raw image output
  * type methods. First a compressed image is generated and output. Then
  * the compressed data is read in and decompressed into raw-formatted
  * data. Info about the raw decompressed data is obtained and used to
  * output the raw data to a file.
  *
  */
  public static void runDemo8()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena_gray.raw";
    String outputFileName   = "lena_cmp8.j2k";
    String recOutputFileName= "lena_rec8.raw";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    int numRows             = 512;
    int numCols             = 512;
    int nChannels           = 1;
    int bpp                 = 8;
    boolean isInterleaved   = false;

// ---------- run demo

    AwJ2k codec = null;
    try {
// ------------------------------------------------ compress data
        codec = new AwJ2k();
        byte[] imageBuffer      = AwJ2kDemoUtils.readImageFile(inputFileName);
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageRaw(
                                imageBuffer,
                                numRows,
                                numCols,
                                nChannels,
                                bpp,
                                isInterleaved);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// ------------------------------------------------ decompress data
        byte[] imageBufferCmp   = AwJ2kDemoUtils.readImageFile(outputFileName);
        codec = new AwJ2k();
        codec.AwJ2kSetInputImage(imageBufferCmp, imageBufferCmp.length);
        AwOutputImageRawValue valueObj = codec.AwJ2kGetOutputImageRaw(isInterleaved);
        byte[] outBuffer    = valueObj.getImage();
        int outBufferLen    = valueObj.getImageLength();
	    int outNumRows      = valueObj.getNumRows();
	    int outNumCols      = valueObj.getNumCols();
	    int outNumChan      = valueObj.getNumChannels();
	    int outBpp          = valueObj.getNumBitsPerPixel();
        System.out.println(" --- numRows,outNumRows   = "+numRows+" "+outNumRows);
        System.out.println(" --- numCols,outNumCols   = "+numCols+" "+outNumCols);
        System.out.println(" --- nChannels,outNumChan = "+nChannels+" "+outNumChan);
        System.out.println(" --- bpp,outBpp           = "+bpp+" "+outBpp);
        AwJ2kDemoUtils.writeImageFile(recOutputFileName, outBuffer, outBufferLen);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows use of the image input and image output
  * file type methods. An input image is read in, and the image data is passed
  * to the input image setter method. The image data is compressed.
  * The compressed image data is obtained by supplying the output data
  * type and output file name, and the compressed data is output to a file.
  *
  */
  public static void runDemo9()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int inputFileType       = AwJ2kParameters.AW_J2K_FORMAT_BMP;
    String outputFileName   = "lena_cmp9.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;

// ---------- run demo

    AwJ2k codec = null;
    try {
        byte[] imageBuffer      = AwJ2kDemoUtils.readImageFile(inputFileName);
        int imageBufferLength   = imageBuffer.length;
        codec = new AwJ2k();
        codec.AwJ2kSetInputImage(imageBuffer, imageBufferLength);
        codec.AwJ2kGetOutputImageFileType(outputFileName, outputFileType);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to set the compression ratio and wavelet transform
  * parameters for compressing an image. The compressed image is generated,
  * and then decompressed.
  */
  public static void runDemo10()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena_gray.raw";
    String outputFileName   = "lena_cmp10.j2k";
    String recOutputFileName= "lena_rec10.raw";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    int numRows             = 512;
    int numCols             = 512;
    int nChannels           = 1;
    int bpp                 = 8;
    boolean isInterleaved   = false;
    int transformType       = AwJ2kParameters.AW_J2K_WV_TYPE_R53;
    int numTransformLevels  = 6;
    float ratio             = 0.f;

// ---------- run demo

    AwJ2k codec = null;
    try {
// --------------------------------------------------------------- compress
        byte[] imageBuffer      = AwJ2kDemoUtils.readImageFile(inputFileName);
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageRaw(
                                imageBuffer,
                                numRows,
                                numCols,
                                nChannels,
                                bpp,
                                isInterleaved);
        codec.AwJ2kSetOutputJ2kXform(transformType, numTransformLevels);
        codec.AwJ2kSetOutputJ2kRatio(ratio);
        AwOutputImageValue valueObj = codec.AwJ2kGetOutputImageType(outputFileType);
        byte[] outBuffer  = valueObj.getImage();
        int outBufferLen  = valueObj.getImageLength();
        AwJ2kDemoUtils.writeImageFile(outputFileName, outBuffer, outBufferLen);
        codec.AwJ2kDestroy();
// --------------------------------------------------------------- decompress
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        codec.AwJ2kGetOutputImageFileRaw(recOutputFileName, isInterleaved);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to set the output compressed image bitrate,
  * for image compression.
  */
  public static void runDemo11()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp11.j2k";
    float bpp               = 1.f;

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kBitrate(bpp);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to set the output compression ratio,
  * for image compression.
  */
  public static void runDemo12()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp12.j2k";
    float ratio             = 24.f;

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kRatio(ratio);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to set the output compressed file size,
  * for image compression.
  */
  public static void runDemo13()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp13.j2k";
    int fileSize            = 33108;

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kFileSize(fileSize);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to turn off use of the color transform,
  * for image compression.
  */
  public static void runDemo14()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp14.j2k";
    int colorXform          = 0;    // turn off color transform

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kColorXform(colorXform);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to generate a compressed image codestream
  * using various packet progression orders.
  */
  public static void runDemo15()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName1  = "lena_cmp15x1.j2k";
    String outputFileName2  = "lena_cmp15x2.j2k";
    String outputFileName3  = "lena_cmp15x3.j2k";
    String outputFileName4  = "lena_cmp15x4.j2k";
    String outputFileName5  = "lena_cmp15x5.j2k";
    int progOrder1          = AwJ2kParameters.AW_J2K_PO_LAYER_RESOLUTION_COMPONENT_POSITION;
    int progOrder2          = AwJ2kParameters.AW_J2K_PO_RESOLUTION_LAYER_COMPONENT_POSITION;
    int progOrder3          = AwJ2kParameters.AW_J2K_PO_RESOLUTION_POSITION_COMPONENT_LAYER;
    int progOrder4          = AwJ2kParameters.AW_J2K_PO_POSITION_COMPONENT_RESOLUTION_LAYER;
    int progOrder5          = AwJ2kParameters.AW_J2K_PO_COMPONENT_POSITION_RESOLUTION_LAYER;

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kProgOrder(progOrder1);
        codec.AwJ2kGetOutputImageFile(outputFileName1);
        codec.AwJ2kDestroy();

        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kProgOrder(progOrder2);
        codec.AwJ2kGetOutputImageFile(outputFileName2);
        codec.AwJ2kDestroy();

        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kProgOrder(progOrder3);
        codec.AwJ2kGetOutputImageFile(outputFileName3);
        codec.AwJ2kDestroy();

        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kProgOrder(progOrder4);
        codec.AwJ2kGetOutputImageFile(outputFileName4);
        codec.AwJ2kDestroy();

        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kProgOrder(progOrder5);
        codec.AwJ2kGetOutputImageFile(outputFileName5);
        codec.AwJ2kDestroy();

    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This method ishows how to compress an image using multiple tiles,
  * with tile and image offsets.
  */

  public static void runDemo16()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp16.j2k";
    int xTileOffset         = 9;
    int yTileOffset         = 8;
    int xImageOffset        = 14;
    int yImageOffset        = 13;
    int widthTileSize       = 194;
    int heightTileSize      = 257;

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kTileOffset(xTileOffset, yTileOffset);
        codec.AwJ2kSetOutputJ2kTileSize(widthTileSize, heightTileSize);
        codec.AwJ2kSetOutputJ2kImageOffset(xImageOffset, yImageOffset);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This method shows how to generate a compressed image using error resilience,
  * the 5-3 wavelet transform, and setting the number of layers, guard bits,
  * and codeblock size.
  */

  public static void runDemo17()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp17.j2k";
    int useSOP              = 1;
    int useEPH              = 1;
    int useSEG_SYMB         = 1;
    int transformType       = AwJ2kParameters.AW_J2K_WV_TYPE_R53;
    int numTransformLevels  = 6;
    int numLayers           = 4;
    int numGuardBits        = 2;
    int cbHeight            = 5;
    int cbWidth             = 5;


// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kErrorRes(useSOP, useEPH, useSEG_SYMB);
        codec.AwJ2kSetOutputJ2kXform(transformType, numTransformLevels);
        codec.AwJ2kSetOutputJ2kLayers(numLayers);
        codec.AwJ2kSetOutputJ2kGuardBits(numGuardBits);
        codec.AwJ2kSetOutputJ2kCblockSize(cbHeight, cbWidth);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This method shows how to generate a compressed image using the various
  * quantization types.
  */
  public static void runDemo18()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName1  = "lena_cmp18x1.j2k";
    String outputFileName2  = "lena_cmp18x2.j2k";
    String outputFileName3  = "lena_cmp18x3.j2k";
    int quantType1          = AwJ2kParameters.AW_J2K_QUANTIZATION_REVERSIBLE;
    int quantType2          = AwJ2kParameters.AW_J2K_QUANTIZATION_DERIVED;
    int quantType3          = AwJ2kParameters.AW_J2K_QUANTIZATION_EXPOUNDED;
    int chanIdx1            = -1;
    int chanIdx2            = -1;
    int chanIdx3            = -1;
    int transformType1      = AwJ2kParameters.AW_J2K_WV_TYPE_R53;
    int transformType2      = AwJ2kParameters.AW_J2K_WV_TYPE_I97;
    int transformType3      = AwJ2kParameters.AW_J2K_WV_TYPE_I97;
    int numTransformLevels  = 6;

// ---------- run demo

    AwJ2k codec = null;
    try {
// ---------------------------------------------------- reversible quantization
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kXform(transformType1, numTransformLevels);
        codec.AwJ2kSetOutputJ2kChanQuant(chanIdx1, quantType1);
        codec.AwJ2kGetOutputImageFile(outputFileName1);
        codec.AwJ2kDestroy();
// ---------------------------------------------------- derived quantization
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kXform(transformType2, numTransformLevels);
        codec.AwJ2kSetOutputJ2kChanQuant(chanIdx2, quantType2);
        codec.AwJ2kGetOutputImageFile(outputFileName2);
        codec.AwJ2kDestroy();
// ---------------------------------------------------- expounded quantization
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kXform(transformType3, numTransformLevels);
        codec.AwJ2kSetOutputJ2kChanQuant(chanIdx3, quantType3);
        codec.AwJ2kGetOutputImageFile(outputFileName3);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This method shows how to generate a compressed image using various
  * arithmetic coding options. The coding options consist of resetting the
  * contexts at the end of each codepass, terminating the arithmetic coder
  * at the end of each codeblock, and using predictable termination.
  */
  public static void runDemo19()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp19.j2k";
    int opt1                = AwJ2kParameters.AW_J2K_ARITH_OPT_CONTEXT_RESET;
    int val1                = AwJ2kParameters.AW_J2K_ACR_AT_EACH_CODEPASS_END;
    int opt2                = AwJ2kParameters.AW_J2K_ARITH_OPT_ARITHMETIC_TERMINATION;
    int val2                = AwJ2kParameters.AW_J2K_AT_ONLY_AT_CODEBLOCK_END;
    int opt3                = AwJ2kParameters.AW_J2K_ARITH_OPT_PREDICTABLE_TERMINATION;
    int val3                = AwJ2kParameters.AW_J2K_PT_USE_PREDICTABLE_TERMINATION;

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kArithCodingOpt(opt1, val1);
        codec.AwJ2kSetOutputJ2kArithCodingOpt(opt2, val2);
        codec.AwJ2kSetOutputJ2kArithCodingOpt(opt3, val3);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to generate a compressed image using a specified
  * predictor offset. The predictor offset is used during the rate-control
  * process.
  */
  public static void runDemo20()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp20.j2k";
    int offset              = 1;

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kPredOffset(offset);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to decompress a subset of the total progression
  * levels available in a codestream. First, the image is compressed using
  * a resolution progressive progression order. Then the image is decompressed.
  * Prior to decompression, the decoding progression level is set.
  */
  public static void runDemo21()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName        = "data/lena.bmp";
    int outputFileType          = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName2      = "lena_cmp21x2.j2k";
    int progOrder2              = AwJ2kParameters.AW_J2K_PO_RESOLUTION_LAYER_COMPONENT_POSITION;
    String recOutputFileName2   = "lena_rec21x2.bmp";
    int recOutputFileType       = AwJ2kParameters.AW_J2K_FORMAT_BMP;
    int progLevel               = 4;

// ---------- run demo

    AwJ2k codec = null;
    try {
// --------------------------------------------------- compression
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kProgOrder(progOrder2);
        codec.AwJ2kGetOutputImageFile(outputFileName2);
        codec.AwJ2kDestroy();
// --------------------------------------------------- decompression
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName2);
        codec.AwJ2kSetOutputType(recOutputFileType);
        codec.AwJ2kSetInputJ2kProgLevel(progLevel);
        codec.AwJ2kGetOutputImageFile(recOutputFileName2);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to decompress a subset of the total progression
  * levels available in a codestream. First, the image is compressed,
  * then the image is decompressed. Prior to decompression, the decoding
  * progression level for each of the three types (resolution, quality, and
  * color channel) is set.
  */
  public static void runDemo22()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName        = "data/lena.bmp";
    int outputFileType          = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName       = "lena_cmp22x1.j2k";
    int progOrder               = AwJ2kParameters.AW_J2K_PO_POSITION_COMPONENT_RESOLUTION_LAYER;
    String recOutputFileName1   = "lena_rec22x1.bmp";
    String recOutputFileName2   = "lena_rec22x2.bmp";
    String recOutputFileName3   = "lena_rec22x3.bmp";
    int recOutputFileType       = AwJ2kParameters.AW_J2K_FORMAT_BMP;
    int resolution_level        = 3;
    int full_xform_flag         = 1; // interpolates to present a full size image
    int quality_level           = 4;
    int color_channels          = 2;
    int color_xform_flag        = 1;
    int numLayers               = 5;

// ---------- run demo

    AwJ2k codec = null;
    try {
// --------------------------------------------------- compression
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kLayers(numLayers);
        codec.AwJ2kSetOutputJ2kProgOrder(progOrder);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// --------------------------------------------------- decompression
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        codec.AwJ2kSetOutputType(recOutputFileType);
        codec.AwJ2kSetInputJ2kResLevel(resolution_level, full_xform_flag);
        codec.AwJ2kGetOutputImageFile(recOutputFileName1);
        codec.AwJ2kDestroy();

        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        codec.AwJ2kSetOutputType(recOutputFileType);
        codec.AwJ2kSetInputJ2kQualLevel(quality_level);
        codec.AwJ2kGetOutputImageFile(recOutputFileName2);
        codec.AwJ2kDestroy();

        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        codec.AwJ2kSetOutputType(recOutputFileType);
        codec.AwJ2kSetInputJ2kColorLevel(color_channels, color_xform_flag);
        codec.AwJ2kGetOutputImageFile(recOutputFileName3);
        codec.AwJ2kDestroy();

    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to decompress a selected compressed tile. First
  * an image is compressed using multiple tiles. The the selected tile
  * is decompressed.
  *
  */

  public static void runDemo23()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp23.j2k";
    int recOutputFileType   = AwJ2kParameters.AW_J2K_FORMAT_BMP;
    String recOutputFileName= "lena_rec23.bmp";
    int widthTileSize       = 256;
    int heightTileSize      = 256;
    int tileIdx             = 2;

// ---------- run demo

    AwJ2k codec = null;
    try {
// --------------------------------------------------- compression
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kTileSize(widthTileSize, heightTileSize);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// --------------------------------------------------- decompression
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        codec.AwJ2kSetOutputType(recOutputFileType);
        codec.AwJ2kSetInputJ2kSelectedTile(tileIdx);
        codec.AwJ2kGetOutputImageFile(recOutputFileName);
        codec.AwJ2kDestroy();

    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to reset input options that have been
  * previously set. A compressed image is generated after clearing
  * the input options.
  */
  public static void runDemo24()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp24.j2k";
    int recOutputFileType   = AwJ2kParameters.AW_J2K_FORMAT_BMP;
    String recOutputFileName= "lena_rec24.bmp";
    int widthTileSize       = 256;
    int heightTileSize      = 256;
    int tileIdx             = 2;
    int resolution_level    = 2;
    int full_xform_flag     = 1;
    int quality_level       = 2;
    int color_channels      = 2;
    int color_xform_flag    = 1;
    int progLevel           = 2;

// ---------- run demo

    AwJ2k codec = null;
    try {
// --------------------------------------------------- compression
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kTileSize(widthTileSize, heightTileSize);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// --------------------------------------------------- decompression
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        codec.AwJ2kSetOutputType(recOutputFileType);
        codec.AwJ2kSetInputJ2kSelectedTile(tileIdx);
        codec.AwJ2kSetInputJ2kResLevel(resolution_level, full_xform_flag);
        codec.AwJ2kSetInputJ2kQualLevel(quality_level);
        codec.AwJ2kSetInputJ2kColorLevel(color_channels, color_xform_flag);
        codec.AwJ2kSetInputJ2kProgLevel(progLevel);
        codec.AwJ2kInputResetOptions();
        codec.AwJ2kSetInputImageFile(outputFileName);
        codec.AwJ2kSetOutputType(recOutputFileType);
        codec.AwJ2kGetOutputImageFile(recOutputFileName);
        codec.AwJ2kDestroy();

    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to set an internal option. In this demo,
  * the internal arithmetic option is set to use fixed point processing.
  */
  public static void runDemo25()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp25.j2k";
    int opt                 = AwJ2kParameters.AW_J2K_INTERNAL_ARITHMETIC_OPTION;
    int val                 = AwJ2kParameters.AW_J2K_INTERNAL_USE_FIXED_POINT;

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetInternalOption(opt, val);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to use the image information method to
  * produce information about the current image.
  *
  */
  public static void runDemo26()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        AwInputImageInfoValue valueObj = codec.AwJ2kGetInputImageInfo();
        int numOutputImageCols      = valueObj.getNumOutputImageCols();
        int numOutputImageRows      = valueObj.getNumOutputImageRows();
        int numOutputBitsPerPixel   = valueObj.getNumOutputBitsPerPixel();
        int numOutputChannels       = valueObj.getNumOutputChannels();
        System.out.println(" numOutputImageCols   = "+numOutputImageCols);
        System.out.println(" numOutputImageRows   = "+numOutputImageRows);
        System.out.println(" numOutputBitsPerPixel= "+numOutputBitsPerPixel);
        System.out.println(" numOutputChannels    = "+numOutputChannels);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to work with comment information. A compressed
  * image is generated and comments are added to the main header of the
  * compressed codestream. The number of comments information is then retrieved
  * from the compressed codestream. Next, the comment information is
  * retrieved from the compressed codestream.
  *
  */
  public static void runDemo27()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp27.j2k";
    String demoComment1     = "this is demo comment number 1";
    String demoComment2     = "O.K., a second comment";
    String demoComment3     = "and yet one more comment";
    int commentType         = AwJ2kParameters.AW_J2K_CO_ISO_8859;
    int commentLocation     = AwJ2kParameters.A2_COMMENT_LOCATION_MAIN_HEADER;
    String badValueString   = "#### INCORRECT VALUE ####";

// ---------- run demo

    AwJ2k codec = null;
    try {
// --------------------------------------- add comments and compress
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kAddComment(
                                    demoComment1,
                                    commentType,
                                    demoComment1.length(),
                                    commentLocation);
        codec.AwJ2kSetOutputJ2kAddComment(
                                    demoComment2,
                                    commentType,
                                    demoComment2.length(),
                                    commentLocation);
        codec.AwJ2kSetOutputJ2kAddComment(
                                    demoComment3,
                                    commentType,
                                    demoComment3.length(),
                                    commentLocation);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// --------------------------------------- get number of comments
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        AwInputNumCommentsInfoValue valueObj0   = codec.AwJ2kGetInputNumCommentsInfo();
        int numComments = valueObj0.getOutputNumComments();
        System.out.println(" numComments   = "+numComments);
// --------------------------------------- get each comment
        AwInputCommentsInfoValue valueObj= null;
        byte[] outputCommentBuffer      = null;
        int outputCommentLength         = -9999;
        int outputCommentType           = -9999;
        int outputCommentLocation       = -9999;
        String outputCommentTypeString  = null;
        String outputCommentLocString   = null;
// ------------------------------------------------------ comment 0
        valueObj = codec.AwJ2kGetInputCommentsInfo(0);
        outputCommentBuffer         = valueObj.getOutputCommentBuffer();
        outputCommentLength         = valueObj.getOutputCommentLength();
        outputCommentType           = valueObj.getOutputCommentType();
        outputCommentLocation       = valueObj.getOutputCommentLocation();
        if (outputCommentType == commentType)
          outputCommentTypeString   = "AW_J2K_CO_ISO_8859";
        else
          outputCommentTypeString   = badValueString;
        if (outputCommentLocation == commentLocation)
          outputCommentLocString   = "A2_COMMENT_LOCATION_MAIN_HEADER";
        else
          outputCommentLocString   = badValueString;
        System.out.println(" ----------------- comment 0 -----------------------------");
        System.out.println(" outputCommentBuffer    = "+new String(outputCommentBuffer));
        System.out.println(" outputCommentLength    = "+outputCommentLength);
        System.out.println(" outputCommentTypeString= "+outputCommentTypeString);
        System.out.println(" outputCommentLocString = "+outputCommentLocString);
// ------------------------------------------------------ comment 1
        valueObj = codec.AwJ2kGetInputCommentsInfo(1);
        outputCommentBuffer         = valueObj.getOutputCommentBuffer();
        outputCommentLength         = valueObj.getOutputCommentLength();
        outputCommentType           = valueObj.getOutputCommentType();
        outputCommentLocation       = valueObj.getOutputCommentLocation();
        if (outputCommentType == commentType)
          outputCommentTypeString   = "AW_J2K_CO_ISO_8859";
        else
          outputCommentTypeString   = badValueString;
        if (outputCommentLocation == commentLocation)
          outputCommentLocString   = "A2_COMMENT_LOCATION_MAIN_HEADER";
        else
          outputCommentLocString   = badValueString;
        System.out.println(" ----------------- comment 1 -----------------------------");
        System.out.println(" outputCommentBuffer    = "+new String(outputCommentBuffer));
        System.out.println(" outputCommentLength    = "+outputCommentLength);
        System.out.println(" outputCommentTypeString= "+outputCommentTypeString);
        System.out.println(" outputCommentLocString = "+outputCommentLocString);
// ------------------------------------------------------ comment 2
        valueObj = codec.AwJ2kGetInputCommentsInfo(2);
        outputCommentBuffer         = valueObj.getOutputCommentBuffer();
        outputCommentLength         = valueObj.getOutputCommentLength();
        outputCommentType           = valueObj.getOutputCommentType();
        outputCommentLocation       = valueObj.getOutputCommentLocation();
        if (outputCommentType == commentType)
          outputCommentTypeString   = "AW_J2K_CO_ISO_8859";
        else
          outputCommentTypeString   = badValueString;
        if (outputCommentLocation == commentLocation)
          outputCommentLocString   = "A2_COMMENT_LOCATION_MAIN_HEADER";
        else
          outputCommentLocString   = badValueString;
        System.out.println(" ----------------- comment 2 -----------------------------");
        System.out.println(" outputCommentBuffer    = "+new String(outputCommentBuffer));
        System.out.println(" outputCommentLength    = "+outputCommentLength);
        System.out.println(" outputCommentTypeString= "+outputCommentTypeString);
        System.out.println(" outputCommentLocString = "+outputCommentLocString);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to clear comments that were about to be added
  * to a compressed image codestream. The number of comments info
  * is retrieved from the compressed codestream to verify that no
  * comments were added.
  */
  public static void runDemo28()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp28.j2k";
    String demoComment1     = "this is demo comment number 1";
    String demoComment2     = "O.K., a second comment";
    String demoComment3     = "and yet one more comment";
    int commentType         = AwJ2kParameters.AW_J2K_CO_ISO_8859;
    int commentLocation     = AwJ2kParameters.A2_COMMENT_LOCATION_MAIN_HEADER;

// ---------- run demo

    AwJ2k codec = null;
    try {
// --------------------------------------- add comments, then clear comments and compress
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kAddComment(
                                    demoComment1,
                                    commentType,
                                    demoComment1.length(),
                                    commentLocation);
        codec.AwJ2kSetOutputJ2kAddComment(
                                    demoComment2,
                                    commentType,
                                    demoComment2.length(),
                                    commentLocation);
        codec.AwJ2kSetOutputJ2kAddComment(
                                    demoComment3,
                                    commentType,
                                    demoComment3.length(),
                                    commentLocation);
        codec.AwJ2kSetOutputJ2kClearComnts();
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// --------------------------------------- get number of comments to verify clearing
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        AwInputNumCommentsInfoValue valueObj0   = codec.AwJ2kGetInputNumCommentsInfo();
        int numComments = valueObj0.getOutputNumComments();
        System.out.println(" numComments   = "+numComments);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to generate progression information.
  *
  */
  public static void runDemo29()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp29.j2k";
    int transformType       = AwJ2kParameters.AW_J2K_WV_TYPE_R53;
    int numTransformLevels  = 6;
    int numLayers           = 4;
    int progOrder           = AwJ2kParameters.AW_J2K_PO_LAYER_RESOLUTION_COMPONENT_POSITION;
    String badValueString   = "#### INCORRECT VALUE ####";


// ---------- run demo

    AwJ2k codec = null;
    try {
// ------------------------------------------------- compress image
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kXform(transformType, numTransformLevels);
        codec.AwJ2kSetOutputJ2kProgOrder(progOrder);
        codec.AwJ2kSetOutputJ2kLayers(numLayers);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// ------------------------------------------------- get progression info
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        AwProgressionInfoValue valueObj= codec.AwJ2kGetProgressionInfo();
        int outputProgressionOrder     = valueObj.getOutputProgressionOrder();
    	int outputNumProgLevels        = valueObj.getOutputNumProgLevels();
    	int outputNumResolutionLevels  = valueObj.getOutputNumTransformLevels();
    	int outputNumLayers            = valueObj.getOutputNumLayers();
    	int numOutputChannels          = valueObj.getNumOutputChannels();
    	int outputNumPrecincts         = valueObj.getOutputNumPrecincts();
    	int outputProgAvailable        = valueObj.getOutputProgAvailable();
    	String outProgOrderString      = badValueString;
    	if (outputProgressionOrder == AwJ2kParameters.AW_J2K_PO_LAYER_RESOLUTION_COMPONENT_POSITION)
    	  outProgOrderString    = "AW_J2K_PO_LAYER_RESOLUTION_COMPONENT_POSITION";
        System.out.println(" outProgOrderString       = "+outProgOrderString);
        System.out.println(" outputNumProgLevels      = "+outputNumProgLevels);
        System.out.println(" outputNumResolutionLevels= "+outputNumResolutionLevels);
        System.out.println(" outputNumLayers          = "+outputNumLayers);
        System.out.println(" numOutputChannels        = "+numOutputChannels);
        System.out.println(" outputNumPrecincts       = "+outputNumPrecincts);
        System.out.println(" outputProgAvailable      = "+outputProgAvailable);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to generate tile information.
  *
  */
  public static void runDemo30()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp30.j2k";
    int xTileOffset         = 9;
    int yTileOffset         = 8;
    int xImageOffset        = 14;
    int yImageOffset        = 13;
    int widthTileSize       = 194;
    int heightTileSize      = 257;

// ---------- run demo

    AwJ2k codec = null;
    try {
// ------------------------------------------------- compress image
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kTileOffset(xTileOffset, yTileOffset);
        codec.AwJ2kSetOutputJ2kTileSize(widthTileSize, heightTileSize);
        codec.AwJ2kSetOutputJ2kImageOffset(xImageOffset, yImageOffset);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// ------------------------------------------------- get tile info
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        AwTileInfoValue valueObj= codec.AwJ2kGetInputTileInfo();
	    int outputTileOffsetX   = valueObj.getOutputTileOffsetX();
	    int outputTileOffsetY   = valueObj.getOutputTileOffsetY();
	    int outputNumTileCols   = valueObj.getOutputNumTileCols();
	    int outputNumTileRows   = valueObj.getOutputNumTileRows();
	    int outputImageOffsetX  = valueObj.getOutputImageOffsetX();
	    int outputImageOffsetY  = valueObj.getOutputImageOffsetY();
        System.out.println(" outputTileOffsetX     = "+outputTileOffsetX);
        System.out.println(" outputTileOffsetY     = "+outputTileOffsetY);
        System.out.println(" outputNumTileCols     = "+outputNumTileCols);
        System.out.println(" outputNumTileRows     = "+outputNumTileRows);
        System.out.println(" outputImageOffsetX    = "+outputImageOffsetX);
        System.out.println(" outputImageOffsetY    = "+outputImageOffsetY);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to generate progression level byte count information.
  * This byte count value represents the number of bytes from the compressed
  * codestream needed to decode to a certain progression level.
  *
  */
  public static void runDemo31()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp31.j2k";
    int transformType       = AwJ2kParameters.AW_J2K_WV_TYPE_R53;
    int numTransformLevels  = 6;
    int numLayers           = 4;
    int progOrder2          = AwJ2kParameters.AW_J2K_PO_RESOLUTION_LAYER_COMPONENT_POSITION;


// ---------- run demo

    AwJ2k codec = null;
    try {
// ------------------------------------------------- compress image
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputJ2kProgOrder(progOrder2);
        codec.AwJ2kSetOutputJ2kXform(transformType, numTransformLevels);
        codec.AwJ2kSetOutputJ2kLayers(numLayers);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// ------------------------------------------------- get byte count info
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        AwProgressionInfoValue valueObj0= codec.AwJ2kGetProgressionInfo();
    	int outputNumProgLevels        = valueObj0.getOutputNumProgLevels();
        System.out.println(" number of available progression levels = "+outputNumProgLevels);
        AwInputProgByteCountValue valueObj= null;
        for (int progLevel=1; progLevel<=outputNumProgLevels; ++progLevel) {
          valueObj= codec.AwJ2kGetProgByteCountInfo(progLevel);
          int numBytes  = valueObj.getOutputProgOffset();
          System.out.println(" progLevel = "+progLevel+" numBytes= "+numBytes);
          }
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to generate component registration information.
  *
  */
  public static void runDemo32()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp32.j2k";
    int component           = 2;
    int Xreg                = 32768;
    int Yreg                = 32768;

// ---------- run demo

    AwJ2k codec = null;
    try {
// ------------------------------------------------- compress image
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputJ2kCompReg(component, Xreg, Yreg);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// ------------------------------------------------- get component registration info
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        AwInputCompRegValue valueObj= codec.AwJ2kGetInputCompRegInfo(component);
	    int outXreg = valueObj.getXRegistration();
	    int outYreg = valueObj.getYRegistration();
        System.out.println(" outXreg = "+outXreg);
        System.out.println(" outYreg = "+outYreg);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to generate a JPEG image, based upon a desired
  * quality level.
  *
  */
  public static void runDemo33()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_JPG;
    String outputFileName   = "lena_cmp33.jpg";
    int quality             = 50;

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJpegOptions(quality);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to generate a multiple layer compressed image in
  * which the layer bitrates are set.
  *
  */
  public static void runDemo34()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp34.j2k";
    int numLayers           = 10;
    int layerIdx0           = 0;
    int layerIdx1           = 9;
    float bpp0              = .1f;
    float bpp1              = 1.f;


// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kLayers(numLayers);
        codec.AwJ2kSetOutputJ2kLayerBitrate(layerIdx0, bpp0);
        codec.AwJ2kSetOutputJ2kLayerBitrate(layerIdx1, bpp1);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to generate a multiple layer compressed image in
  * which the layer compression ratios are set.
  *
  */
  public static void runDemo35()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp35.j2k";
    int numLayers           = 15;
    int layerIdx0           = 0;
    int layerIdx1           = 14;
    float ratio0            = 75.f;
    float ratio1            = 5.f;


// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kLayers(numLayers);
        codec.AwJ2kSetOutputJ2kLayerRatio(layerIdx0, ratio0);
        codec.AwJ2kSetOutputJ2kLayerRatio(layerIdx1, ratio1);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to generate a multiple layer compressed image in
  * which the layer compressed sizes are set.
  *
  */
  public static void runDemo36()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp36.j2k";
    int numLayers           = 10;
    int layerIdx0           = 0;
    int layerIdx1           = 9;
    int cbytes0             = 1000;
    int cbytes1             = 10000;


// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kLayers(numLayers);
        codec.AwJ2kSetOutputJ2kLayerSize(layerIdx0, cbytes0);
        codec.AwJ2kSetOutputJ2kLayerSize(layerIdx1, cbytes1);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to use a region of interest (ROI) to provide extra
  * compression fidelity to the chosen region. This demo uses ROI
  * byte data, read in from a file.
  *
  */
  public static void runDemo37()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    String inputRoiFileName = "data/lena_face_roi.pgm";
    String outputFileName   = "lena_cmp37.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    float ratio             = 60.f;

// ---------- run demo

    AwJ2k codec = null;
    try {
        byte[] roiBuffer      = AwJ2kDemoUtils.readImageFile(inputRoiFileName);
        int roiBufferLength   = roiBuffer.length;
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kRoiFromImage(roiBuffer, roiBufferLength);
        codec.AwJ2kSetOutputJ2kRatio(ratio);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to use a region of interest (ROI) to provide extra
  * compression fidelity to the chosen region. This demo uses ROI
  * raw byte data, read in from a file.
  *
  */
  public static void runDemo38()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    String inputRoiFileName = "data/lena_face_roi.raw";
    String outputFileName   = "lena_cmp38.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    float ratio             = 60.f;
    int numRows             = 512;
    int numCols             = 512;
    int nChannels           = 1;
    int bpp                 = 8;
    boolean isInterlaced    = false;

// ---------- run demo

    AwJ2k codec = null;
    try {
        byte[] roiBuffer      = AwJ2kDemoUtils.readImageFile(inputRoiFileName);
        int roiBufferLength   = roiBuffer.length;
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kRoiFromImageRaw(
                                            roiBuffer,
                                            numRows,
                                            numCols,
                                            bpp,
                                            isInterlaced);
        codec.AwJ2kSetOutputJ2kRatio(ratio);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to use a region of interest (ROI) to provide extra
  * compression fidelity to the chosen region. This demo uses an ROI
  * file.
  *
  */
  public static void runDemo39()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    String inputRoiFileName = "data/lena_face_roi.pgm";
    String outputFileName   = "lena_cmp39.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    float ratio             = 60.f;

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kRoiFromFile(inputRoiFileName);
        codec.AwJ2kSetOutputJ2kRatio(ratio);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to use a region of interest (ROI) to provide extra
  * compression fidelity to the chosen region. This demo uses a raw ROI
  * file.
  *
  */
  public static void runDemo40()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    String inputRoiFileName = "data/lena_face_roi.raw";
    String outputFileName   = "lena_cmp40.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    float ratio             = 60.f;
    int numRows             = 512;
    int numCols             = 512;
    int nChannels           = 1;
    int bpp                 = 8;
    boolean isInterlaced    = false;

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kRoiFromFileRaw(
                                            inputRoiFileName,
                                            numRows,
                                            numCols,
                                            bpp,
                                            isInterlaced);
        codec.AwJ2kSetOutputJ2kRatio(ratio);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to use a region of interest (ROI) to provide extra
  * compression fidelity to the chosen region. This demo uses a defined
  * rectangular ROI.
  *
  */
  public static void runDemo41()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    String outputFileName   = "lena_cmp41.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    float ratio             = 60.f;
    int shape               = AwJ2kParameters.AW_ROISHAPE_RECTANGLE;
    int x                   = 240;
    int y                   = 240;
    int width               = 100;
    int height              = 100;

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kRoiAddShape(
                                            shape,
                                            x,
                                            y,
                                            width,
                                            height);
        codec.AwJ2kSetOutputJ2kRatio(ratio);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to clear a previously define region of interest.
  *
  */
  public static void runDemo42()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    String outputFileName   = "lena_cmp42.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    float ratio             = 60.f;
    int shape               = AwJ2kParameters.AW_ROISHAPE_RECTANGLE;
    int x                   = 100;
    int y                   = 100;
    int width               = 200;
    int height              = 200;

// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kRoiAddShape(
                                            shape,
                                            x,
                                            y,
                                            width,
                                            height);
        codec.AwJ2kSetOutputJ2kClearRoi();
        codec.AwJ2kSetOutputJ2kRatio(ratio);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}




/**
  * This demo shows how to use a raw image retrieval method which produces
  * a global reference to the image data. After using the image data,
  * it must be explicitly released, to prevent memory leaks.
  *
  */
  public static void runDemo43()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena_gray.raw";
    String outputFileName   = "lena_cmp43.j2k";
    String recOutputFileName= "lena_rec43.raw";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    int numRows             = 512;
    int numCols             = 512;
    int nChannels           = 1;
    int bpp                 = 8;
    boolean isInterleaved   = false;

// ---------- run test

    AwJ2k codec = null;
    try {
// ------------------------------------------------ compress
        codec = new AwJ2k();
        byte[] imageBuffer      = AwJ2kDemoUtils.readImageFile(inputFileName);
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageRaw(
                                imageBuffer,
                                numRows,
                                numCols,
                                nChannels,
                                bpp,
                                isInterleaved);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// ------------------------------------------------ decompress
        codec = new AwJ2k();
        byte[] imageBufferCmp   = AwJ2kDemoUtils.readImageFile(outputFileName);
        codec.AwJ2kSetInputImage(imageBufferCmp, imageBufferCmp.length);
        AwOutputImageRawValue valueObj = codec.AwJ2kGetOutputImageRaw(isInterleaved);
        byte[] outBuffer    = valueObj.getImage();
        int outBufferLen    = valueObj.getImageLength();
	    int outNumRows      = valueObj.getNumRows();
	    int outNumCols      = valueObj.getNumCols();
	    int outNumChan      = valueObj.getNumChannels();
	    int outBpp          = valueObj.getNumBitsPerPixel();
        System.out.println(" --- numRows,outNumRows   = "+numRows+" "+outNumRows);
        System.out.println(" --- numCols,outNumCols   = "+numCols+" "+outNumCols);
        System.out.println(" --- nChannels,outNumChan = "+nChannels+" "+outNumChan);
        System.out.println(" --- bpp,outBpp           = "+bpp+" "+outBpp);
        AwJ2kDemoUtils.writeImageFile(recOutputFileName, outBuffer, outBufferLen);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }

}
/**
  * This demo shows how to use an image type retrieval method which produces
  * a global reference to the image data. After using the image data,
  * it must be explicitly released, to prevent memory leaks.
  *
  */
  public static void runDemo44()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena_gray.raw";
    String outputFileName   = "lena_cmp44.j2k";
    String recOutputFileName= "lena_rec44.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    int recOutputFileType   = AwJ2kParameters.AW_J2K_FORMAT_BMP;
    int numRows             = 512;
    int numCols             = 512;
    int nChannels           = 1;
    int bpp                 = 8;
    boolean isInterleaved   = false;

// ---------- run test

    AwJ2k codec = null;
    try {
// ------------------------------------------------ compress
        codec = new AwJ2k();
        byte[] imageBuffer      = AwJ2kDemoUtils.readImageFile(inputFileName);
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageRaw(
                                imageBuffer,
                                numRows,
                                numCols,
                                nChannels,
                                bpp,
                                isInterleaved);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// ------------------------------------------------ decompress
        codec = new AwJ2k();
        byte[] imageBufferCmp   = AwJ2kDemoUtils.readImageFile(outputFileName);
        codec.AwJ2kSetInputImage(imageBufferCmp, imageBufferCmp.length);
        AwOutputImageValue valueObj = codec.AwJ2kGetOutputImageType(recOutputFileType);
        byte[] outBuffer    = valueObj.getImage();
        int outBufferLen    = valueObj.getImageLength();
        AwJ2kDemoUtils.writeImageFile(recOutputFileName, outBuffer, outBufferLen);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to use an image retrieval method which produces
  * a global reference to the image data. After using the image data,
  * it must be explicitly released, to prevent memory leaks.
  *
  */
  public static void runDemo45()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena_gray.raw";
    String outputFileName   = "lena_cmp45.j2k";
    String recOutputFileName= "lena_rec45.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    int recOutputFileType   = AwJ2kParameters.AW_J2K_FORMAT_BMP;
    int numRows             = 512;
    int numCols             = 512;
    int nChannels           = 1;
    int bpp                 = 8;
    boolean isInterleaved   = false;

// ---------- run test

    AwJ2k codec = null;
    try {
// ------------------------------------------------ compress
        codec = new AwJ2k();
        byte[] imageBuffer      = AwJ2kDemoUtils.readImageFile(inputFileName);
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageRaw(
                                imageBuffer,
                                numRows,
                                numCols,
                                nChannels,
                                bpp,
                                isInterleaved);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// ------------------------------------------------ decompress
        codec = new AwJ2k();
        byte[] imageBufferCmp   = AwJ2kDemoUtils.readImageFile(outputFileName);
        codec.AwJ2kSetInputImage(imageBufferCmp, imageBufferCmp.length);
        codec.AwJ2kSetOutputType(recOutputFileType);
        AwOutputImageValue valueObj = codec.AwJ2kGetOutputImage();
        byte[] outBuffer  = valueObj.getImage();
        int outBufferLen  = valueObj.getImageLength();
        AwJ2kDemoUtils.writeImageFile(recOutputFileName, outBuffer, outBufferLen);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to use a comment info retrieval method which produces
  * a global reference to the comment data. After using the comment data,
  * it must be explicitly released, to prevent memory leaks.
  *
  */
  public static void runDemo46()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp46.j2k";
    String testComment1     = "this is test comment number 1";
    String testComment2     = "O.K., a second comment";
    String testComment3     = "and yet one more comment";
    int commentType         = AwJ2kParameters.AW_J2K_CO_ISO_8859;
    int commentLocation     = AwJ2kParameters.A2_COMMENT_LOCATION_MAIN_HEADER;
    String badValueString   = "#### INCORRECT VALUE ####";

// ---------- run test

    AwJ2k codec = null;
    try {
// --------------------------------------- add comments and compress
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kAddComment(
                                    testComment1,
                                    commentType,
                                    testComment1.length(),
                                    commentLocation);
        codec.AwJ2kSetOutputJ2kAddComment(
                                    testComment2,
                                    commentType,
                                    testComment2.length(),
                                    commentLocation);
        codec.AwJ2kSetOutputJ2kAddComment(
                                    testComment3,
                                    commentType,
                                    testComment3.length(),
                                    commentLocation);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// --------------------------------------- get number of comments
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        AwInputNumCommentsInfoValue valueObj0   = codec.AwJ2kGetInputNumCommentsInfo();
        int numComments = valueObj0.getOutputNumComments();
        System.out.println(" numComments   = "+numComments);
// --------------------------------------- get each comment
        AwInputCommentsInfoValue valueObj= null;
        byte[] outputCommentBuffer      = null;
        int outputCommentLength         = -9999;
        int outputCommentType           = -9999;
        int outputCommentLocation       = -9999;
        String outputCommentTypeString  = null;
        String outputCommentLocString   = null;
// ------------------------------------------------------ comment 0
        valueObj = codec.AwJ2kGetInputCommentsInfo(0);
        outputCommentBuffer         = valueObj.getOutputCommentBuffer();
        outputCommentLength         = valueObj.getOutputCommentLength();
        outputCommentType           = valueObj.getOutputCommentType();
        outputCommentLocation       = valueObj.getOutputCommentLocation();
        if (outputCommentType == commentType)
          outputCommentTypeString   = "AW_J2K_CO_ISO_8859";
        else
          outputCommentTypeString   = badValueString;
        if (outputCommentLocation == commentLocation)
          outputCommentLocString   = "A2_COMMENT_LOCATION_MAIN_HEADER";
        else
          outputCommentLocString   = badValueString;
        System.out.println(" ----------------- comment 0 -----------------------------");
        System.out.println(" outputCommentBuffer    = "+new String(outputCommentBuffer));
        System.out.println(" outputCommentLength    = "+outputCommentLength);
        System.out.println(" outputCommentTypeString= "+outputCommentTypeString);
        System.out.println(" outputCommentLocString = "+outputCommentLocString);
// ------------------------------------------------------ comment 1
        valueObj = codec.AwJ2kGetInputCommentsInfo(1);
        outputCommentBuffer         = valueObj.getOutputCommentBuffer();
        outputCommentLength         = valueObj.getOutputCommentLength();
        outputCommentType           = valueObj.getOutputCommentType();
        outputCommentLocation       = valueObj.getOutputCommentLocation();
        if (outputCommentType == commentType)
          outputCommentTypeString   = "AW_J2K_CO_ISO_8859";
        else
          outputCommentTypeString   = badValueString;
        if (outputCommentLocation == commentLocation)
          outputCommentLocString   = "A2_COMMENT_LOCATION_MAIN_HEADER";
        else
          outputCommentLocString   = badValueString;
        System.out.println(" ----------------- comment 1 -----------------------------");
        System.out.println(" outputCommentBuffer    = "+new String(outputCommentBuffer));
        System.out.println(" outputCommentLength    = "+outputCommentLength);
        System.out.println(" outputCommentTypeString= "+outputCommentTypeString);
        System.out.println(" outputCommentLocString = "+outputCommentLocString);
// ------------------------------------------------------ comment 2
        valueObj = codec.AwJ2kGetInputCommentsInfo(2);
        outputCommentBuffer         = valueObj.getOutputCommentBuffer();
        outputCommentLength         = valueObj.getOutputCommentLength();
        outputCommentType           = valueObj.getOutputCommentType();
        outputCommentLocation       = valueObj.getOutputCommentLocation();
        if (outputCommentType == commentType)
          outputCommentTypeString   = "AW_J2K_CO_ISO_8859";
        else
          outputCommentTypeString   = badValueString;
        if (outputCommentLocation == commentLocation)
          outputCommentLocString   = "A2_COMMENT_LOCATION_MAIN_HEADER";
        else
          outputCommentLocString   = badValueString;
        System.out.println(" ----------------- comment 2 -----------------------------");
        System.out.println(" outputCommentBuffer    = "+new String(outputCommentBuffer));
        System.out.println(" outputCommentLength    = "+outputCommentLength);
        System.out.println(" outputCommentTypeString= "+outputCommentTypeString);
        System.out.println(" outputCommentLocString = "+outputCommentLocString);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to generate tile geometry information for
  * a selected tile index.
  *
  */
  public static void runDemo47()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName   = "lena_cmp47.j2k";
    int xTileOffset         = 9;
    int yTileOffset         = 8;
    int xImageOffset        = 14;
    int yImageOffset        = 13;
    int widthTileSize       = 117;
    int heightTileSize      = 102;
    int selectedTileIndex   = 7;

// ---------- run demo

    AwJ2k codec = null;
    try {
// ------------------------------------------------- compress image
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kTileOffset(xTileOffset, yTileOffset);
        codec.AwJ2kSetOutputJ2kTileSize(widthTileSize, heightTileSize);
        codec.AwJ2kSetOutputJ2kImageOffset(xImageOffset, yImageOffset);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// ------------------------------------------------- get selected tile gemoetry info
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        AwSelectedTileGeomInfoValue valueObj=
                        codec.AwJ2kGetInputSelectedTileGeomInfo(selectedTileIndex);
	    int tileIndex           = valueObj.getTileIndex();
	    int outputTileOffsetX   = valueObj.getOutputTileOffsetX();
	    int outputTileOffsetY   = valueObj.getOutputTileOffsetY();
	    int outputNumTileCols   = valueObj.getOutputNumTileCols();
	    int outputNumTileRows   = valueObj.getOutputNumTileRows();
        System.out.println(" tileIndex             = "+tileIndex);
        System.out.println(" outputTileOffsetX     = "+outputTileOffsetX);
        System.out.println(" outputTileOffsetY     = "+outputTileOffsetY);
        System.out.println(" outputNumTileCols     = "+outputNumTileCols);
        System.out.println(" outputNumTileRows     = "+outputNumTileRows);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows use of the binwidth scaling method for image compression.
  * A raw 8-bit grayscale input image is read in, and the image data is passed
  * to the input image setter method. The binwidth scale is set and the
  * image data is compressed. The compressed image data is obtained and
  * output to a file.
  *
  */
  public static void runDemo48()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena_gray.raw";
    String outputFileName   = "lena_cmp48.j2k";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    int numRows             = 512;
    int numCols             = 512;
    int nChannels           = 1;
    int bpp                 = 8;
    boolean isInterleaved   = false;
    float binwidthScale     = .0625f;    // 1/16
    float ratio             = 1.2f;

// ---------- run demo

    AwJ2k codec = null;
    try {
        byte[] imageBuffer      = AwJ2kDemoUtils.readImageFile(inputFileName);
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageRaw(
                                imageBuffer,
                                numRows,
                                numCols,
                                nChannels,
                                bpp,
                                isInterleaved);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kQuantBinwidthScale(binwidthScale);
        codec.AwJ2kSetOutputJ2kRatio(ratio);
        AwOutputImageValue valueObj = codec.AwJ2kGetOutputImage();
        byte[] outBuffer  = valueObj.getImage();
        int outBufferLen  = valueObj.getImageLength();
        AwJ2kDemoUtils.writeImageFile(outputFileName, outBuffer, outBufferLen);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to decompress sub-resolution images contained
  * in the JPEG2000 codestream. First, the image is compressed,
  * using a resolution-progressive progression order. Five levels
  * of wavelet transform are used, which provide six resolution levels:
  * five sub-resolution images and one full resolution image. After compression
  * each of the five available sub-resolution image is decompressed. The
  * decompression starts from the largest sub-resolution image and ends
  * with the smallest sub-resolution image. In this example the
  * the input image file is a 512 by 512 rgb color image in bmp
  * format named lena.bmp. The decompressed images are contained in
  * files named recX_lena.bmp, where X refers to the resolution level.
  */
  public static void runDemo49()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code compression parameters

    String inputFileName        = "data/lena.bmp";
    int outputFileType          = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName       = "lena_cmp.j2k";
    int progOrder               = AwJ2kParameters.AW_J2K_PO_RESOLUTION_LAYER_COMPONENT_POSITION;
    int transformType           = AwJ2kParameters.AW_J2K_WV_TYPE_R53;
    int numTransformLevels      = 5;

 // ---------- hard code decompression parameters

    int recOutputFileType       = AwJ2kParameters.AW_J2K_FORMAT_BMP;
    int full_xform_flag         = 0; // does not interpolate to present a full size image

// ---------- run demo

    AwJ2k codec = null;
    try {
// --------------------------------------------------- compression
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kProgOrder(progOrder);
        codec.AwJ2kSetOutputJ2kXform(transformType, numTransformLevels);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// --------------------------------------------------- decompression
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);       // set the input image to be the compressed image
        codec.AwJ2kSetOutputType(recOutputFileType);        // set decompressed image type
        AwProgressionInfoValue valueObj= codec.AwJ2kGetProgressionInfo();
    	int numResLevels  = valueObj.getOutputNumTransformLevels(); // get num res levels
        for (int i=2; i<=numResLevels; ++i) {               // loop over sub-res images and decompress
          codec.AwJ2kSetInputJ2kResLevel(
                                        i,                  // resolution_level
                                        full_xform_flag);   // indicates if interpolation is used
          codec.AwJ2kGetOutputImageFile("rec"+i+"_"+inputFileName); // decompress to an output file
        }
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows how to determine the J2K library version.
  *
  */
  public static void runDemo50()
{
// ******************************************************************
//
// ******************************************************************

    
// ---------- run demo

    AwJ2k codec = null;
    try {
        codec = new AwJ2k();
        AwLibraryVersionValue valObj    = codec.AwJ2kGetLibraryVersion();
        byte[] libraryVersion   = valObj.getLibraryVersion();
        int libraryVersionId    = valObj.getLibraryVersionId();
        System.out.println( " libraryVersion   = "+(new String(libraryVersion)));
        System.out.println( " libraryVersionId = "+libraryVersionId);
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}
/**
  * This demo shows use of the JP2 methods for working with JP2 file-formatted
  * data. Three intellectual property boxes are added to the JP2 image buffer,
  * and a JP2 file is created. Then, the JP2 file is read-in and the number
  * of intellectual property boxes along with the pertinent metadata is
  * extracted..
  *
  */
  public static void runDemo51()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code data

    String inputFileName    = "data/lena.bmp";
    String outputFileName   = "lena_cmp51.jp2";
    int outputFileType      = AwJ2kParameters.AW_J2K_FORMAT_JP2;
    byte[][] uuid    = {
                                {0x41,0x42,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0x4a,0x4b,0x4c,0x4d,0x4e,0x4f,0x50},
                                {0x50,0x4f,0x4e,0x4d,0x4c,0x4b,0x4a,0x49,0x48,0x47,0x46,0x45,0x44,0x43,0x42,0x41},
                                {0x5a,0x5b,0x5c,0x5d,0x5e,0x5f,0x61,0x62,0x63,0x64,0x65,0x66,0x67,0x68,0x69,0x6a}   
                        };
    String[] metaData    =   {
                                  "test 1 of an intellectual property box"  ,
                                  "a second small test of the functionality of an ip box"  ,
                                  "test number three indicating the workings of an ipbx"
                              };                       
    int boxType     = AwJ2kParameters.AW_JP2_MDTYPE_JP2I;

    
// ---------- run demo

    AwJ2k codec = null;
    try {
// ------------------------------------- add boxes and create JP2 file       
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        for (int i=0; i<metaData.length; ++i) 
           codec.AwJ2kSetOutputJp2AddMetadataBox(
                                boxType,
                                metaData[i],
                                metaData[i].length(),
                                uuid[i],
                                uuid[i].length);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
 // ------------------------------------- decode JP2 file and get box info      
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);
        AwInputNumMetadataBoxesValue valueObj101    =
                        codec.AwJ2kGetInputJp2NumMetadataBoxes(boxType);
        int boxType2            = valueObj101.getBoxType();
        int numMetadataBoxes    = valueObj101.getNumMetadataBoxes();
        System.out.println(" boxType2          = "+boxType2);
        System.out.println(" numMetadataBoxes  = "+numMetadataBoxes);
                                                  
        for (int i=0; i<metaData.length; ++i) {
          AwInputMetadataBoxValue valueObj102 = codec.AwJ2kGetInputJp2MetadataBox(
                                                                            boxType,
                                                                            i); // index
          int retBoxType          = valueObj102.getBoxType();
          int retBoxIndex         = valueObj102.getBoxIndex();
          byte[] retMetaData      = valueObj102.getMetadata();
          byte[] retUUIDdata      = valueObj102.getUuid();
          String metadataString   = new String(retMetaData);
          System.out.println(" index "+i+" retBoxType  = "+retBoxType);
          System.out.println(" index "+i+" retBoxIndex = "+retBoxIndex);
          System.out.println(" metadataString          = "+metadataString);
        }                                                             
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }
     catch (Exception exc) {
        System.out.println(" Exception exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}

} // end of class



