
 package com.aware.j2k.demo;

//  ******************************************************************
//  File   : AwJ2kCmdLineDriver.java
//  Creator: Stephen DelMarco
//
//
//  This file contains a command-line driver for exercising the
//  the native interface to the J2K library.
//
//
//  Notes:
//
//
//  ******************************************************************

 import java.util.*;
 import java.io.*;
 import java.awt.*;
 import java.awt.image.*;
 import java.awt.event.*;
 import com.aware.j2k.codec.engine.*;
import com.aware.j2k.codec.engine.AwJ2kParameters;


/**
  *   This class is the command-line driver for the java-wrapped
  *   J2K library. The general usage of this driver is:
  *<p>
  *   java AwJ2kCmdLineDriver [options set]<p>
  *   <p>
  *   where the options set format consists of sets of suboptions
  *   enclosed in braces, preceded by sub-options name flags. The general
  *   format of the (case-sensitive) options set is given by:
  *    <p>
  *   <code>-Driver {opts} -InputImage {opts} -Info {opts} -Options {opts} -OutputImage {opts} </code><br>
  *    <p>
  *    or, the abbreviated form may be used:
  *    <p>
  *   <code>-D {opts} -I {opts} -F {opts} -P {opts} -O {opts}. </code><br>
  *    <p>
  *    The order of the sets of sub-options must be maintained. The
  *    exception to the above format occurs for this usage display,
  *    which is provided by using no arguments or using the -h or -help
  *    arguments.
  *    <p>
  *    The -Driver options are options used for the driver and are not required.
  *    The -InputImage options are required.
  *    The -Info options are not required.
  *    The -Options options are not required.
  *    The -OutputImage options are required, unless the -Info options are present.
  *    <p>
  *    The -Driver options set consists of:
  *    <p>
  *           <code>-v or -verbose</code> this option turns on the verbosity.<br>
  *           <code>-h or -help</code> this option prints this usage message.<br>
  *    <p>
  *    <p>
  *    The -InputImage options set consists of:
  *    <p>
  *           <code>-input-file &lt;fileName&gt;</code><br>
  *    or<br>
  *           <code>-input-file-type &lt;fileName&gt; &lt;fileType&gt;</code><br>
  *    or<br>
  *           <code>-input-file-raw &lt;fileName&gt; &lt;numRows&gt; &lt;numCols&gt; &lt;numChannels&gt; &lt;numBpp&gt; &lt;isInterleaved&gt; &lt;endianness&gt;</code><br>
  *    or<br>
  *           <code>-input-image &lt;fileName&gt;</code><br>
  *    or<br>
  *           <code>-input-image-type &lt;fileName&gt; &lt;imageType&gt;</code><br>
  *    or<br>
  *           <code>-input-image-raw &lt;fileName&gt; &lt;numRows&gt; &lt;numCols&gt; &lt;numChannels&gt; &lt;numBpp&gt; &lt;isInterleaved&gt; &lt;endianness&gt;</code><br>
  *    <p>
  *    <p>
  *    <p>
  *    The -Info options set consists of:</code><br>
  *    <p>
  *           <code>-input-image </code><br>
  *    or<br>
  *           <code>-progression </code><br>
  *    or<br>
  *           <code>-number-of-comments </code><br>
  *    or<br>
  *           <code>-comments &lt;commentIndex&gt;</code><br>
  *    or<br>
  *           <code>-tile </code><br>
  *    or<br>
  *           <code>-bytes-read </code><br>
  *    or<br>
  *           <code>-prog-byte-count &lt;index&gt;</code><br>
  *    or<br>
  *           <code>-comp-reg-info &lt;index&gt;</code><br>
  *    <p>
  *    <p>
  *    <p>
  *    The -Options options set consists of:</code><br>
  *    <p>
  *    <p>
  *           <code>-recval &lt;reconstructionValue&gt;</code><br>
  *           <code>-proglevel &lt;progressionLevel&gt;</code><br>
  *           <code>-quallevel &lt;qualitylevel&gt;</code><br>
  *           <code>-fs &lt;outputFileSize&gt;</code><br>
  *           <code>-bpp &lt;bits per pixel&gt;</code><br>
  *           <code>-tol &lt;tolerance&gt;</code><br>
  *           <code>-cxform &lt;colorTransform&gt;</code><br>
  *           <code>-lay &lt;number of layers&gt;</code><br>
  *           <code>-quant &lt;quantization option&gt; &lt;channel index&gt; </code><br>
  *           <code>-guard &lt;number of guard bits&gt;</code><br>
  *           <code>-prog-order &lt;progression order&gt;</code><br>
  *           <code>-code-style &lt;coding style&gt;</code><br>
  *           <code>-clear-com </code><br>
  *           <code>-lambda &lt;initial lambda&gt;</code><br>
  *           <code>-ratio &lt;compression ratio&gt;</code><br>
  *           <code>-jpg-qual &lt;jpeg quality level&gt;</code><br>
  *           <code>-res &lt;resolution level&gt; &lt;full transform flag&gt;</code><br>
  *           <code>-col-level &lt;color level&gt; &lt;color transform flag&gt;</code><br>
  *           <code>-region &lt;x0 coord&gt; &lt;y0 coord&gt; &lt;x1 coord&gt; &lt;y1 coord&gt; </code><br>
  *           <code>-xform &lt;transform type&gt; &lt;number of transform levels&gt; </code><br>
  *           <code>-cblock &lt;codeblock width&gt; &lt;codeblock height&gt; </code><br>
  *           <code>-error-res &lt;use SOP markers&gt; &lt;use EPH markers&gt; &lt;use segmentation symbols&gt; </code><br>
  *           <code>-comment &lt;type> &lt;location&gt; &lt;comment file name&gt;</code><br>
  *           <code>-tile-off &lt;x tile offset coord&gt; &lt;y tile offset coord&gt; </code><br>
  *           <code>-tile-size &lt;tile width&gt; &lt;tile height&gt; </code><br>
  *           <code>-image-off &lt;x image offset coord&gt; &lt;y image offset coord&gt; </code><br>
  *           <code>-selected-tile &lt;tile index&gt; </code><br>
  *           <code>-layer-ratio &lt;layer index&gt; &lt;ratio&gt;</code><br>
  *           <code>-layer-size &lt;layer index&gt; &lt;number of bytes&gt;</code><br>
  *           <code>-layer-bpp &lt;layer index&gt; &lt;bits per pixel&gt;</code><br>
  *           <code>-pred-offset &lt;predictor offset&gt;</code><br>
  *           <code>-mqcoder-opt &lt;option&gt; &lt;value&gt;</code><br>
  *           <code>-intern-opt &lt;option&gt; &lt;value&gt;</code><br>
  *           <code>-comp-reg &lt;component index&gt; &lt;x-reg&gt; &lt;y-reg></code><br>
  *           <code>-tile-toc </code><br>
  *           <code>-tile-data-toc </code><br>
  *           <code>-roi-image &lt;fileName&gt;</code><br>
  *           <code>-roi-image-type &lt;fileName&gt; &lt;image type&gt;</code><br>
  *           <code>-roi-image-raw &lt;fileName&gt; &lt;numRows&gt; &lt;numCols&gt; &lt;numBpp&gt; &lt;isInterleaved&gt;</code><br>
  *           <code>-roi-file-raw &lt;fileName&gt; &lt;numRows&gt; &lt;numCols&gt; &lt;numBpp&gt; &lt;isInterleaved&gt;</code><br>
  *           <code>-roi-shape &lt;shape&gt; &lt;x coord&gt; &lt;y coord&gt; &lt;width&gt; &lt;height&gt;</code><br>
  *           <code>-roi-file &lt;fileName&gt;</code><br>
  *           <code>-clear-roi </code><br>
  *    <p>
  *    The -OutputImage options set consists of:
  *    <p>
  *    <p>
  *           <code>-output-file &lt;fileType&gt; &lt;fileName&gt;</code><br>
  *    or<br>
  *           <code>-output-file-type &lt;fileType&gt; &lt;fileName&gt;</code><br>
  *    or<br>
  *           <code>-output-file-raw &lt;isInterleaved&gt; &lt;fileName&gt; &lt;endianness&gt;</code><br>
  *    or<br>
  *           <code>-output-image &lt;imageType&gt; &lt;fileName&gt;</code><br>
  *    or<br>
  *           <code>-output-image-type &lt;imageType&gt; &lt;fileName&gt;</code><br>
  *    or<br>
  *           <code>-output-image-raw &lt;isInterleaved&gt; &lt;fileName&gt; &lt;endianness&gt;</code><br>
  * <p>
  * <p>
  *    Here are a few examples showing use of the different image input flags. In these
  *    examples, lena.bmp is a 512 by 512 rgb color, 24 bit per pixel image contained in
  *    a bmp formatted file. lena_gray.raw is the corresponding gray scale, 8 bit per pixel
  *    image in a raw format (i.e., raw byte data). LenacmpXX and lenarecXX are compressed
  *    and decompressed images.
  * <p>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lena.bmp} -O {-output-file 72 lenacmp1.j2k}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-image-raw lena_gray.raw 512 512 1 8 0 0} -O {-output-file-type 72 lenacmp2.j2k}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file-raw lena_gray.raw 512 512 1 8 0 0} -O {-output-file-type 72 lenacmp3.j2k}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file-type lenacmp2.j2k 72} -O {-output-file-raw 0 lenarec4.raw 0}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-image lenacmp2.j2k} -O {-output-file-raw 0 lenarec5.raw 0}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-image-type lenacmp2.j2k 72} -O {-output-file-raw 0 lenarec6.raw 0}</code><br>
  * <p>
  *  Here are a few examples showing use of the different image output flags.
  * <p>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lena.bmp} -O {-output-file 72 lenacmp7.j2k}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lena.bmp} -O {-output-image-type 72 lenacmp8.j2k}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lena.bmp} -O {-output-image 72 lenacmp9.j2k}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lena.bmp} -O {-output-file-type 72 lenacmp10.j2k}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lenacmp2.j2k} -O {-output-image-raw 0 lenarec11.raw 0}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lenacmp2.j2k} -O {-output-file-raw 0 lenarec12.raw 0}</code><br>
  * <p>
  *  Here are a few examples showing use of the region of interest flags, and the compression ratio option.
  * <p>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lena.bmp} -P {-ratio 60. -roi-image lena_face_roi.pgm} -O {-output-file 72 lenacmp13.j2k}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lena.bmp} -P {-ratio 60. -roi-image-type lena_face_roi.bmp 69} -O {-output-file 72 lenacmp14.j2k}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lena.bmp} -P {-ratio 60. -roi-image-raw lena_face_roi.raw 512 512 8 0} -O {-output-file 72 lenacmp15.j2k}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lena.bmp} -P {-ratio 60. -roi-file-raw lena_face_roi.raw 512 512 8 0} -O {-output-file 72 lenacmp16.j2k}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lena.bmp} -P {-ratio 60. -roi-file lena_face_roi.pgm} -O {-output-file 72 lenacmp17.j2k}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lena.bmp} -P {-ratio 60. -roi-shape 0 240 240 100 100} -O {-output-file 72 lenacmp18.j2k}</code><br>
  * <p>
  *  Here are a few examples showing use of options flags.
  * <p>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lena.bmp} -P {-fs 10000 -tile-size 256 256 -image-off 12 15 -tile-off 7 8 -lay 6 -cblock 5 5} -O {-output-file 72 lenacmp20.j2k}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lena.bmp} -P {-quant 0 -1 -xform 1 6} -O {-output-file 72 lenacmp23.j2k}</code><br>
  *  <code>java AwJ2kCmdLineDriver  -D {-v} -I {-input-file lena.bmp} -P {-mqcoder-opt 1 1} -O {-output-file 72 lenacmp28.j2k}</code><br>
  *
  *
  * @author Stephen DelMarco
  * @version 1.0,   Copyright (c) Aware, Inc., 2002
  *
  */

 public class AwJ2kCmdLineDriver {


        private static final String   DRIVER_FLAG                   = "-Driver";
        private static final String   DRIVER_FLAG_ABBREV            = "-D";
        private static final String   INPUT_IMAGE_FLAG              = "-InputImage";
        private static final String   INPUT_IMAGE_FLAG_ABBREV       = "-I";
        private static final String   INFO_FLAG                     = "-Info";
        private static final String   INFO_FLAG_ABBREV              = "-F";
        private static final String   OPTIONS_FLAG                  = "-Options";
        private static final String   OPTIONS_FLAG_ABBREV           = "-P";
        private static final String   OUTPUT_IMAGE_FLAG             = "-OutputImage";
        private static final String   OUTPUT_IMAGE_FLAG_ABBREV      = "-O";
        private static final String   START_SUB_OPTIONS_SEPARATOR   = "{";
        private static final String   END_SUB_OPTIONS_SEPARATOR     = "}";

        private boolean isVerboseDrvOpt     = false;
        private boolean isUsingInfoOpt      = false;

        private AwJ2k   codec;





/**
  * The main method serving as an entry point for the stand-alone application.
  *
  * @param argv   commandline argument list
  */
  public static void main(String[] argv)
{
// ******************************************************************
//
// ******************************************************************

// ---------- create the driver

    AwJ2kCmdLineDriver driver   = new AwJ2kCmdLineDriver();
    try {
        driver.runDriver(argv);
    }
    catch (AwJ2kException exc) {
        exc.printStackTrace(System.out);
    }

    System.exit(0);

}
/**
  * default constructor.
  *
  */
  public AwJ2kCmdLineDriver()
{
// ******************************************************************
//
// ******************************************************************

}
/**
  * runs the stand-alone commandline driver.
  *
  * @param argv   commandline argument list
  *
  * @exception com.aware.j2k.codec.engine.AwJ2kException an interface, or J2K-specific exception
  */
  public void runDriver(
                    String[]    argv)  throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************

// ---------- handle usage display

    boolean isDisplayingUsage   = handleDisplayUsage(argv);
    if (isDisplayingUsage)
      return;

// ---------- create the sub-options string

    String[]  driverSubOptions        = createDriverSubOptions(argv);
    String[]  inputImageSubOptions    = createInputImageSubOptions(argv);
    String[]  infoSubOptions          = createInfoSubOptions(argv);
    String[]  optionsSubOptions       = createOptionsSubOptions(argv);
    String[]  outputImageSubOptions   = createOutputImageSubOptions(argv);

// ---------- handle the options for this driver

    handleDriverOptions(driverSubOptions);

// ---------- create the j2k object, handle input image setting, info
// ---------- generation, option setting and output generation

    codec = new AwJ2k();

    handleSetInputImage(inputImageSubOptions);
    boolean isGeneratingInfo    = handleGenerateInfo(infoSubOptions);
    if (isGeneratingInfo)
      return;
    handleSetOptions(optionsSubOptions);
    handleGenerateOutput(outputImageSubOptions);


    return;
}
/**
  * This method
  *
  * @return none
  */

  protected boolean handleDisplayUsage(
                            String[]    argv)
{
// ******************************************************************
//
// ******************************************************************

    boolean isDisplayingUsage   = false;

    if (    (argv.length == 0)
         || (
                    (argv.length == 1)
                &&  (
                            (argv[0].trim().toLowerCase().equals("-h")   )
                        ||  (argv[0].trim().toLowerCase().equals("-help"))
                    )
            )
       ) {
      displayUsage();
      isDisplayingUsage = true;
      }

    return(isDisplayingUsage);
}
/**
  * displays the usage statement for the commandline driver
  *
  */

  public void displayUsage()
{
// ******************************************************************
//
// ******************************************************************

    String intro    =
     " \n"
  +  " Usage: java AwJ2kCmdLineDriver [options set]\n"
  +  " \n"
  +  " where the options set format consists of sets of suboptions \n"
  +  " enclosed in braces, preceded by sub-options name flags. The general \n"
  +  " format of the (case-sensitive) options set is given by:\n"
  +  "  \n"
  +  " -Driver {opts} -InputImage {opts} -Info {opts} -Options {opts} -OutputImage {opts} \n"
  +  "  \n"
  +  "  or, the abbreviated form may be used:\n"
  +  "  \n"
  +  " -D {opts} -I {opts} -F {opts} -P {opts} -O {opts}. \n"
  +  "  \n"
  +  "  The order of the sets of sub-options must be maintained. The\n"
  +  "  exception to the above format occurs for this usage display, \n"
  +  "  which is provided by using no arguments or using the -h or -help\n"
  +  "  arguments.\n"
  +  "  \n"
  +  "  The -Driver options are options used for this driver and are not required. \n"
  +  "  The -InputImage options are required. \n"
  +  "  The -Info options are not required. \n"
  +  "  The -Options options are not required.  \n"
  +  "  The -OutputImage options are required, unless the -Info options are present.\n"
  +  "  \n"
  +  "  The -Driver options set consists of:\n"
  +  "  \n"
  +  "         -v or -verbose\n"
  +  "               this option turns on the verbosity.\n"
  +  "         -h or -help\n"
  +  "               this option prints this usage message.\n"
  +  "  \n"
  +  "  \n"
  +  "  The -InputImage options set consists of:\n"
  +  "  \n"
  +  "         -input-file <fileName>\n"
  +  "  or\n"
  +  "         -input-file-type <fileName> <fileType>\n"
  +  "  or\n"
  +  "         -input-file-raw <fileName> <numRows> <numCols> <numChannels> <numBpp> <isInterleaved> <endianness>\n"
  +  "  or\n"
  +  "         -input-image <fileName>\n"
  +  "  or\n"
  +  "         -input-image-type <fileName> <imageType>\n"
  +  "  or\n"
  +  "         -input-image-raw <fileName> <numRows> <numCols> <numChannels> <numBpp> <isInterleaved> <endianness>\n"
  +  "  \n"
  +  "  \n"
  +  "  \n"
  +  "  The -Info options set consists of:\n"
  +  "  \n"
  +  "         -input-image \n"
  +  "  or\n"
  +  "         -progression \n"
  +  "  or\n"
  +  "         -number-of-comments \n"
  +  "  or\n"
  +  "         -comments <commentIndex>\n"
  +  "  or\n"
  +  "         -tile \n"
  +  "  or\n"
  +  "         -bytes-read \n"
  +  "  or\n"
  +  "         -prog-byte-count <index>\n"
  +  "  or\n"
  +  "         -comp-reg-info <index>\n"
  +  "  \n"
  +  "  \n"
  +  "  \n"
  +  "  The -Options options set consists of:\n"
  +  "  \n"
  +  "  \n"
  +  "         -recval <reconstructionValue>\n"
  +  "         -proglevel <progressionLevel>\n"
  +  "         -quallevel <qualitylevel>\n"
  +  "         -fs <outputFileSize>\n"
  +  "         -bpp <bits per pixel>\n"
  +  "         -tol <tolerance>\n"
  +  "         -cxform <colorTransform>\n"
  +  "         -lay <number of layers>\n"
  +  "         -quant <quantization option> <channel index> \n"
  +  "         -guard <number of guard bits>\n"
  +  "         -prog-order <progression order>\n"
  +  "         -code-style <coding style>\n"
  +  "         -clear-com \n"
  +  "         -lambda <initial lambda>\n"
  +  "         -ratio <compression ratio>\n"
  +  "         -jpg-qual <jpeg quality level>\n"
  +  "         -res <resolution level> <full transform flag>\n"
  +  "         -col-level <color level> <color transform flag>\n"
  +  "         -region <x0 coord> <y0 coord> <x1 coord> <y1 coord> \n"
  +  "         -xform <transform type> <number of transform levels> \n"
  +  "         -cblock <codeblock width> <codeblock height> \n"
  +  "         -error-res <use SOP markers> <use EPH markers> <use segmentation symbols> \n"
  +  "         -comment <type> <location> <comment file name>\n"
  +  "         -tile-off <x tile offset coord> <y tile offset coord> \n"
  +  "         -tile-size <tile width> <tile height> \n"
  +  "         -image-off <x image offset coord> <y image offset coord> \n"
  +  "         -selected-tile <tile index> \n"
  +  "         -layer-ratio <layer index> <ratio>\n"
  +  "         -layer-size <layer index> <number of bytes>\n"
  +  "         -layer-bpp <layer index> <bits per pixel>\n"
  +  "         -pred-offset <predictor offset>\n"
  +  "         -mqcoder-opt <option> <value>\n"
  +  "         -intern-opt <option> <value>\n"
  +  "         -comp-reg <component index> <x-reg> <y-reg>\n"
  +  "         -tile-toc \n"
  +  "         -tile-data-toc \n"
  +  "         -roi-image <fileName>\n"
  +  "         -roi-image-type <fileName> <image type>\n"
  +  "         -roi-image-raw <fileName> <numRows> <numCols> <numBpp> <isInterleaved>\n"
  +  "         -roi-file-raw <fileName> <numRows> <numCols> <numBpp> <isInterleaved>\n"
  +  "         -roi-shape <shape> <x coord> <y coord> <width> <height>\n"
  +  "         -roi-file <fileName>\n"
  +  "         -clear-roi \n"
  +  "  \n"
  +  "  The -OutputImage options set consists of:\n"
  +  "  \n"
  +  "  \n"
  +  "         -output-file <fileType> <fileName>\n"
  +  "  or\n"
  +  "         -output-file-type <fileType> <fileName>\n"
  +  "  or\n"
  +  "         -output-file-raw <isInterleaved> <fileName> <endianness>\n"
  +  "  or\n"
  +  "         -output-image <imageType> <fileName>\n"
  +  "  or\n"
  +  "         -output-image-type <imageType> <fileName>\n"
  +  "  or\n"
  +  "         -output-image-raw <isInterleaved> <fileName> <endianness>\n"

  +  "  \n"
  +  "  \n";


    System.out.println(intro);

}
/**
  * This method
  *
  * @return none
  */

  protected String[] createDriverSubOptions(
                                    String[]    argv) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************
    return(createSubOptions(argv, DRIVER_FLAG, DRIVER_FLAG_ABBREV));
}
/**
  * This method
  *
  * @return none
  */

  protected String[] createInputImageSubOptions(
                                    String[]    argv) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************
    return(createSubOptions(argv, INPUT_IMAGE_FLAG, INPUT_IMAGE_FLAG_ABBREV));
}
/**
  * This method
  *
  * @return none
  */

  protected String[] createInfoSubOptions(
                                    String[]    argv) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************
    return(createSubOptions(argv, INFO_FLAG, INFO_FLAG_ABBREV));
}
/**
  * This method
  *
  * @return none
  */

  protected String[] createOutputImageSubOptions(
                                    String[]    argv) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************
    return(createSubOptions(argv, OUTPUT_IMAGE_FLAG, OUTPUT_IMAGE_FLAG_ABBREV));
}
/**
  * This method
  *
  * @return none
  */

  protected String[] createOptionsSubOptions(
                                    String[]    argv) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************
    return(createSubOptions(argv, OPTIONS_FLAG, OPTIONS_FLAG_ABBREV));
}
/**
  * This method
  *
  * @return none
  */

  protected String[] createSubOptions(
                                    String[]    argv,
                                    String      optionsFlag,
                                    String      optionsFlagAbbrev)  throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************

    int totalNumOptions = argv.length;
    int startIdx        = -1;
    int endIdx          = -1;

// ---------- loop over the total number of options, looking for the
// ---------- option. When found, record its index into the array.
// ---------- Then continue looking for the end of the options set, as
// ---------- signified by the separator. Record the end index. If the option
// ---------- is not found, as indicated by the unset start index, then return null

    for (int i=0; i<totalNumOptions; ++i) {
      if ( (argv[i].trim().equals(optionsFlag)) || (argv[i].trim().equals(optionsFlagAbbrev)) )
        startIdx    = i;
      if (startIdx > -1) {
        if (    (endsWithSubOptSeparator(argv[i]) )
             || (equalsSubOptEndSeparator(argv[i])) ) {
           endIdx   = i;
           break;
           }
        }
      }

    if (startIdx == -1)    // option not found
      return(null);


// ---------- modify the start and end index values, in case they
// ---------- only consist of the options separator character. Note that
// ---------- the start index is augmented by one to skip the options flag

    startIdx++;
/*
System.out.println(" startIdx= "+startIdx);
System.out.println(" argv[startIdx]= "+argv[startIdx]);
System.out.println(" equalsSubOptStartSeparator(argv[startIdx])= "+equalsSubOptStartSeparator(argv[startIdx]));
System.out.println(" startsWithSubOptSeparator(argv[startIdx]) = "+startsWithSubOptSeparator(argv[startIdx]));
*/
    if (equalsSubOptStartSeparator(argv[startIdx]))
      startIdx++;
    else if (startsWithSubOptSeparator(argv[startIdx]))
      argv[startIdx]    = removeSubOptStartSeparator(argv[startIdx]);
    else
      throw new AwJ2kException("***Error: inconsistent option");



    if (equalsSubOptEndSeparator(argv[endIdx]))
      endIdx--;
    else if (endsWithSubOptSeparator(argv[endIdx]))
      argv[endIdx]    = removeSubOptEndSeparator(argv[endIdx]);
    else
      throw new AwJ2kException("***Error: inconsistent option");

// ---------- set the options

    int numSubOptions   = endIdx - startIdx + 1;
    String[] subOptions = new String [numSubOptions];
    for (int i=0; i<numSubOptions; ++i)
      subOptions[i] = argv[i+startIdx].trim();


    return(subOptions);
}
/**
  * This method
  *
  * @return none
  */

  protected boolean startsWithSubOptSeparator(
                                    String  option)
{
// ******************************************************************
//
// ******************************************************************
    return(option.trim().startsWith(START_SUB_OPTIONS_SEPARATOR));
}
/**
  * This method
  *
  * @return none
  */

  protected boolean equalsSubOptStartSeparator(
                                    String  option)
{
// ******************************************************************
//
// ******************************************************************
    return(option.trim().equals(START_SUB_OPTIONS_SEPARATOR));
}
/**
  * This method
  *
  * @return none
  */

  protected String removeSubOptStartSeparator(
                                    String  option)
{
// ******************************************************************
//
// ******************************************************************
    return(option.trim().substring(1));
}
/**
  * This method
  *
  * @return none
  */

  protected boolean endsWithSubOptSeparator(
                                    String  option)
{
// ******************************************************************
//
// ******************************************************************
    return(option.trim().endsWith(END_SUB_OPTIONS_SEPARATOR));
}
/**
  * This method
  *
  * @return none
  */

  protected boolean equalsSubOptEndSeparator(
                                    String  option)
{
// ******************************************************************
//
// ******************************************************************
    return(option.trim().equals(END_SUB_OPTIONS_SEPARATOR));
}
/**
  * This method
  *
  * @return none
  */

  protected String removeSubOptEndSeparator(
                                    String  option)
{
// ******************************************************************
//
// ******************************************************************
    return(option.trim().substring(0,option.length()-1));
}
/**
  * This method
  *
  * @return none
  */

  protected void handleDriverOptions(
                            String[]    options) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************

// ---------- check to see if options exist

    if (options == null)
      return;

// ---------- loop over the options

    int numOptions      = options.length;

    int idx             = 0;
    String  optionsFlag = null;
    while (idx < numOptions) {
      optionsFlag   = options[idx++];
      idx           = parseAndSetDriverOptions(options, idx, optionsFlag);
      }

// ---------- display options

    if (isVerboseDrvOpt) {
      System.out.println(" sub-options name = "+DRIVER_FLAG);
      for (int i=0; i<numOptions; ++i)
         System.out.println("       option = "+options[i]);

      }


}
/**
  * This method
  *
  * @return none
  */

  protected int parseAndSetDriverOptions(
                            String[]    options,
                            int         idx,
                            String      optionsFlag) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************


// ------------------------------------------------------------ -verbose
    if (optionsFlag.equals("-v") || optionsFlag.equals("-verbose")) {
      isVerboseDrvOpt   = true;
      }
// ------------------------------------------------------------ -help
    else if (optionsFlag.equals("-h") || optionsFlag.equals("-help")) {
      displayUsage();
      }

    return(idx);
}
/**
  * This method
  *
  * @return none
  */

  protected void handleSetInputImage(
                            String[]    options) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************

// ---------- check to see if options exist. These are required so
// ---------- throw an exception if they don't exist

    if (options == null)
      throw new AwJ2kException("***Error: the required input image options don't exist");


// ---------- handle option

    String optionsFlag  = options[0];

    if (isVerboseDrvOpt)
      System.out.println(" sub-options name = "+INPUT_IMAGE_FLAG);


// ------------------------------------------------------------ -input-file
    if (optionsFlag.equals("-input-file")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input image options array is too small");
      String fileName   = options[1];
      if (isVerboseDrvOpt) {
        System.out.println("        option name      = "+optionsFlag);
        System.out.println("        file name option = "+fileName);
        }
      codec.AwJ2kSetInputImageFile(fileName);
      }
// ------------------------------------------------------------ -input-file-type
    else if (optionsFlag.equals("-input-file-type")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input image options array is too small");
      String fileName       = options[1];
      String fileTypeString = options[2];
      int fileType  = -1;
      try {
        fileType    = Integer.parseInt(fileTypeString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing file type");
        }
      if (isVerboseDrvOpt) {
        System.out.println("        option name      = "+optionsFlag);
        System.out.println("        file name option = "+fileName);
        System.out.println("        file type option = "+fileTypeString);
        }
      codec.AwJ2kSetInputImageFileType(fileName, fileType);
      }
// ------------------------------------------------------------ -input-file-raw
    else if (optionsFlag.equals("-input-file-raw")) {
      if (options.length < 8)
        throw new AwJ2kException("***Error: input image options array is too small");
      String fileName               = options[1];
      String numRowsString          = options[2];
      String numColsString          = options[3];
      String numChannelsString      = options[4];
      String numBppString           = options[5];
      String isInterleavedString    = options[6];
      String endianTypeString       = options[7];
      int numRows       = -1;
      int numCols       = -1;
      int numChannels   = -1;
      int numBpp        = -1;
      int isInterleaved = -1;
      int endianType    = -1;
      try {
        numRows         = Integer.parseInt(numRowsString);
        numCols         = Integer.parseInt(numColsString);
        numChannels     = Integer.parseInt(numChannelsString);
        numBpp          = Integer.parseInt(numBppString);
        isInterleaved   = Integer.parseInt(isInterleavedString);
        endianType      = Integer.parseInt(endianTypeString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("        option name      = "+optionsFlag);
        System.out.println("        file name option                = "+fileName);
        System.out.println("        number of rows option           = "+numRowsString);
        System.out.println("        number of cols option           = "+numColsString);
        System.out.println("        number of channels option       = "+numChannelsString);
        System.out.println("        number of bits per pixel option = "+numBppString);
        System.out.println("        is interleaved option           = "+isInterleavedString);
        System.out.println("        endian type option              = "+endianType);
        }
      boolean isInterleavedBoolean  = false;
      if (isInterleaved != 0)
        isInterleavedBoolean    = true;
      if (      (endianType != AwJ2kParameters.AW_J2K_ENDIAN_LOCAL_MACHINE)
            &&  (endianType != AwJ2kParameters.AW_J2K_ENDIAN_SMALL        )
            &&  (endianType != AwJ2kParameters.AW_J2K_ENDIAN_BIG          ) )
        throw new AwJ2kException("***Error: invalid input endianness value");
      codec.AwJ2kSetInputRawEndianness(endianType);
      codec.AwJ2kSetInputImageFileRaw(
                                fileName,
                                numRows,
                                numCols,
                                numChannels,
                                numBpp,
                                isInterleavedBoolean);
      }
// ------------------------------------------------------------ -input-image
    else if (optionsFlag.equals("-input-image")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input image options array is too small");
      String fileName           = options[1];
      byte[] inputImageBuffer   = readData(fileName);
      if (isVerboseDrvOpt) {
        System.out.println("        option name      = "+optionsFlag);
        System.out.println("        file name option = "+fileName);
        }
      codec.AwJ2kSetInputImage(inputImageBuffer, inputImageBuffer.length);
      }
// ------------------------------------------------------------ -input-image-type
    else if (optionsFlag.equals("-input-image-type")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input image options array is too small");
      String fileName           = options[1];
      String imageTypeString    = options[2];
      int imageType             = -1;
      try {
        imageType    = Integer.parseInt(imageTypeString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing image type");
        }
      byte[] inputImageBuffer   = readData(fileName);
      if (isVerboseDrvOpt) {
        System.out.println("        option name      = "+optionsFlag);
        System.out.println("        image type option = "+imageTypeString);
        }
      codec.AwJ2kSetInputImageType(imageType, inputImageBuffer, inputImageBuffer.length);
      }
// ------------------------------------------------------------ -input-image-raw
    else if (optionsFlag.equals("-input-image-raw")) {
      if (options.length < 8)
        throw new AwJ2kException("***Error: input image options array is too small");
      String fileName               = options[1];
      String numRowsString          = options[2];
      String numColsString          = options[3];
      String numChannelsString      = options[4];
      String numBppString           = options[5];
      String isInterleavedString    = options[6];
      String endianTypeString       = options[7];
      int numRows       = -1;
      int numCols       = -1;
      int numChannels   = -1;
      int numBpp        = -1;
      int isInterleaved = -1;
      int endianType    = -1;
      try {
        numRows         = Integer.parseInt(numRowsString);
        numCols         = Integer.parseInt(numColsString);
        numChannels     = Integer.parseInt(numChannelsString);
        numBpp          = Integer.parseInt(numBppString);
        isInterleaved   = Integer.parseInt(isInterleavedString);
        endianType      = Integer.parseInt(endianTypeString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      byte[] inputImageBuffer       = readData(fileName);
      boolean isInterleavedBoolean  = false;
      if (isInterleaved != 0)
        isInterleavedBoolean    = true;
      if (isVerboseDrvOpt) {
        System.out.println("        option name      = "+optionsFlag);
        System.out.println("        file name option                = "+fileName);
        System.out.println("        number of rows option           = "+numRowsString);
        System.out.println("        number of cols option           = "+numColsString);
        System.out.println("        number of channels option       = "+numChannelsString);
        System.out.println("        number of bits per pixel option = "+numBppString);
        System.out.println("        is interleaved option           = "+isInterleavedString);
        System.out.println("        endian type option              = "+endianType);
        }
      if (      (endianType != AwJ2kParameters.AW_J2K_ENDIAN_LOCAL_MACHINE)
            &&  (endianType != AwJ2kParameters.AW_J2K_ENDIAN_SMALL        )
            &&  (endianType != AwJ2kParameters.AW_J2K_ENDIAN_BIG          ) )
        throw new AwJ2kException("***Error: invalid input endianness value");
      codec.AwJ2kSetInputRawEndianness(endianType);
      codec.AwJ2kSetInputImageRaw(
                                inputImageBuffer,
                                numRows,
                                numCols,
                                numChannels,
                                numBpp,
                                isInterleavedBoolean);
      }
    else {
      throw new AwJ2kException("***Error: unknown input image option flag");
      }



}
/**
  * This method
  *
  * @return none
  */

  protected boolean handleGenerateInfo(
                            String[]    options) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************

// ---------- check to see if options exist. These are not required.

    if (options == null) {
      isUsingInfoOpt    = false;
      return(false);
      }
    else
      isUsingInfoOpt    = true;


// ---------- grab Info options

    String optionsFlag  = options[0];

    if (isVerboseDrvOpt)
      System.out.println(" sub-options name = "+INFO_FLAG);


// ------------------------------------------------------------ -input-image
    if (optionsFlag.equals("-input-image")) {
      if (isVerboseDrvOpt) {
        System.out.println("       option name      = "+optionsFlag);
        }
      AwInputImageInfoValue valueObj = codec.AwJ2kGetInputImageInfo();
      int numOutputImageCols      = valueObj.getNumOutputImageCols();
      int numOutputImageRows      = valueObj.getNumOutputImageRows();
      int numOutputBitsPerPixel   = valueObj.getNumOutputBitsPerPixel();
      int numOutputChannels       = valueObj.getNumOutputChannels();
      System.out.println(" numOutputImageCols   = "+numOutputImageCols);
      System.out.println(" numOutputImageRows   = "+numOutputImageRows);
      System.out.println(" numOutputBitsPerPixel= "+numOutputBitsPerPixel);
      System.out.println(" numOutputChannels    = "+numOutputChannels);
      }
// ------------------------------------------------------------ -progression
    else if (optionsFlag.equals("-progression")) {
      if (isVerboseDrvOpt) {
        System.out.println("       option name      = "+optionsFlag);
        }
      AwProgressionInfoValue valueObj= codec.AwJ2kGetProgressionInfo();
        int outputProgressionOrder     = valueObj.getOutputProgressionOrder();
        int outputNumProgLevels        = valueObj.getOutputNumProgLevels();
    	int outputNumResolutionLevels  = valueObj.getOutputNumTransformLevels();
    	int outputNumLayers            = valueObj.getOutputNumLayers();
    	int numOutputChannels          = valueObj.getNumOutputChannels();
    	int outputNumPrecincts         = valueObj.getOutputNumPrecincts();
    	int outputProgAvailable        = valueObj.getOutputProgAvailable();
    	String outProgOrderString      = "unknown progression order";
    	if (outputProgressionOrder == AwJ2kParameters.AW_J2K_PO_DEFAULT)
    	  outProgOrderString    = "AW_J2K_PO_DEFAULT";
    	else if (outputProgressionOrder == AwJ2kParameters.AW_J2K_PO_LAYER_RESOLUTION_COMPONENT_POSITION)
    	  outProgOrderString    = "AW_J2K_PO_LAYER_RESOLUTION_COMPONENT_POSITION";
    	else if (outputProgressionOrder == AwJ2kParameters.AW_J2K_PO_RESOLUTION_LAYER_COMPONENT_POSITION)
    	  outProgOrderString    = "AW_J2K_PO_RESOLUTION_LAYER_COMPONENT_POSITION";
    	else if (outputProgressionOrder == AwJ2kParameters.AW_J2K_PO_RESOLUTION_POSITION_COMPONENT_LAYER)
    	  outProgOrderString    = "AW_J2K_PO_RESOLUTION_POSITION_COMPONENT_LAYER";
    	else if (outputProgressionOrder == AwJ2kParameters.AW_J2K_PO_POSITION_COMPONENT_RESOLUTION_LAYER)
    	  outProgOrderString    = "AW_J2K_PO_POSITION_COMPONENT_RESOLUTION_LAYER";
    	else if (outputProgressionOrder == AwJ2kParameters.AW_J2K_PO_COMPONENT_POSITION_RESOLUTION_LAYER)
    	  outProgOrderString    = "AW_J2K_PO_COMPONENT_POSITION_RESOLUTION_LAYER";
        System.out.println(" outProgOrderString       = "+outProgOrderString);
        System.out.println(" outputNumProgLevels      = "+outputNumProgLevels);
        System.out.println(" outputNumResolutionLevels= "+outputNumResolutionLevels);
        System.out.println(" outputNumLayers          = "+outputNumLayers);
        System.out.println(" numOutputChannels        = "+numOutputChannels);
        System.out.println(" outputNumPrecincts       = "+outputNumPrecincts);
        System.out.println(" outputProgAvailable      = "+outputProgAvailable);
      }
// ------------------------------------------------------------ -number-of-comments
    else if (optionsFlag.equals("-number-of-comments")) {
      if (isVerboseDrvOpt) {
        System.out.println("       option name      = "+optionsFlag);
        }
      AwInputNumCommentsInfoValue valueObj0   = codec.AwJ2kGetInputNumCommentsInfo();
      int numComments = valueObj0.getOutputNumComments();
      System.out.println(" numComments   = "+numComments);
      }
// ------------------------------------------------------------ -comments
    else if (optionsFlag.equals("-comments")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input info options array is too small");
      String commentIndexString = options[1];
      int commentIndex          = -1;
      try {
        commentIndex    = Integer.parseInt(commentIndexString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing comment index");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name      = "+optionsFlag);
        System.out.println("       comment index    = "+commentIndex);
        }
      AwInputCommentsInfoValue valueObj = codec.AwJ2kGetInputCommentsInfo(commentIndex);
      byte[]  outputCommentBuffer       = valueObj.getOutputCommentBuffer();
      int  outputCommentLength          = valueObj.getOutputCommentLength();
      int  outputCommentType            = valueObj.getOutputCommentType();
      int  outputCommentLocation        = valueObj.getOutputCommentLocation();
      String outputCommentTypeString   = "unknown comment type";
      if (outputCommentType == AwJ2kParameters.AW_J2K_CO_ISO_8859)
        outputCommentTypeString   = "AW_J2K_CO_ISO_8859";
      else if (outputCommentType == AwJ2kParameters.AW_J2K_CO_BINARY)
        outputCommentTypeString   = "AW_J2K_CO_BINARY";
      String outputCommentLocString   = "unknown comment location";
      if (outputCommentLocation == AwJ2kParameters.A2_COMMENT_LOCATION_MAIN_HEADER)
        outputCommentLocString   = "A2_COMMENT_LOCATION_MAIN_HEADER";
      else if (outputCommentLocation == AwJ2kParameters.A2_COMMENT_LOCATION_TILEPART_HEADER)
        outputCommentLocString   = "A2_COMMENT_LOCATION_TILEPART_HEADER";
      System.out.println(" outputCommentBuffer    = "+new String(outputCommentBuffer));
      System.out.println(" outputCommentLength    = "+outputCommentLength);
      System.out.println(" outputCommentTypeString= "+outputCommentTypeString);
      System.out.println(" outputCommentLocString = "+outputCommentLocString);
      }
// ------------------------------------------------------------ -tile
    else if (optionsFlag.equals("-tile")) {
      if (isVerboseDrvOpt) {
        System.out.println("       option name      = "+optionsFlag);
        }
      AwTileInfoValue valueObj= codec.AwJ2kGetInputTileInfo();
	  int outputTileOffsetX   = valueObj.getOutputTileOffsetX();
	  int outputTileOffsetY   = valueObj.getOutputTileOffsetY();
	  int outputNumTileCols   = valueObj.getOutputNumTileCols();
	  int outputNumTileRows   = valueObj.getOutputNumTileRows();
	  int outputImageOffsetX  = valueObj.getOutputImageOffsetX();
	  int outputImageOffsetY  = valueObj.getOutputImageOffsetY();
      System.out.println(" outputTileOffsetX     = "+outputTileOffsetX);
      System.out.println(" outputTileOffsetY     = "+outputTileOffsetY);
      System.out.println(" outputNumTileCols     = "+outputNumTileCols);
      System.out.println(" outputNumTileRows     = "+outputNumTileRows);
      System.out.println(" outputImageOffsetX    = "+outputImageOffsetX);
      System.out.println(" outputImageOffsetY    = "+outputImageOffsetY);
      }
// ------------------------------------------------------------ -bytes-read
    else if (optionsFlag.equals("-bytes-read")) {
      if (isVerboseDrvOpt) {
        System.out.println("       option name      = "+optionsFlag);
        }
      AwInputBytesReadInfoValue valueObj = codec.AwJ2kGetInputBytesReadInfo();
      int outputNumBytesRead    = valueObj.getOutputNumBytesRead();
      System.out.println(" outputNumBytesRead    = "+outputNumBytesRead);
      }
// ------------------------------------------------------------ -comp-reg-info
    else if (optionsFlag.equals("-comp-reg-info")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input info options array is too small");
      String componentString = options[1];
      int component          = -1;
      try {
        component    = Integer.parseInt(componentString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing component index");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name      = "+optionsFlag);
        System.out.println("       component        = "+component);
        }
      AwInputCompRegValue valueObj  = codec.AwJ2kGetInputCompRegInfo(component);
	  int outXreg = valueObj.getXRegistration();
	  int outYreg = valueObj.getYRegistration();
      System.out.println(" outXreg = "+outXreg);
      System.out.println(" outYreg = "+outYreg);
      }
// ------------------------------------------------------------ -prog-byte-count
    else if (optionsFlag.equals("-prog-byte-count")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input info options array is too small");
      String indexString = options[1];
      int index          = -1;
      try {
        index    = Integer.parseInt(indexString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing prog byte count index");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name      = "+optionsFlag);
        System.out.println("       index            = "+index);
        }
      AwInputProgByteCountValue valueObj= codec.AwJ2kGetProgByteCountInfo(index);
      int numBytes  = valueObj.getOutputProgOffset();
      System.out.println(" numBytes= "+numBytes);
      }
    else {
      throw new AwJ2kException("***Error: unknown input info option flag");
      }




    return(true);

}
/**
  * This method
  *
  * @return none
  */

  protected void handleSetOptions(
                            String[]    options) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************

// ---------- check to see if options exist

    if (options == null)
      return;


    if (isVerboseDrvOpt)
      System.out.println(" sub-options name = "+OPTIONS_FLAG);


    int numOptions      = options.length;

    int idx             = 0;
    String  optionsFlag = null;
    while (idx < numOptions) {
      optionsFlag   = options[idx++];
      idx           = parseAndSetOptions(options, idx, optionsFlag);
      }

}
/**
  * This method
  *
  * @return none
  */

  protected int parseAndSetOptions(
                            String[]    options,
                            int         idx,
                            String      optionsFlag) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************


// ------------------------------------------------------------ -recval
    if (optionsFlag.equals("-recval")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String recValString   = options[idx++];
      float recVal          = -1;
      try {
        recVal    = (Float.valueOf(recValString)).floatValue();
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       reconstruction value = "+recVal);
        }
      codec.AwJ2kSetInputJ2kRvalue(recVal);
      }
// ------------------------------------------------------------ -proglevel
    else if (optionsFlag.equals("-proglevel")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String progLevelString    = options[idx++];
      int progLevel             = -1;
      try {
        progLevel    = Integer.parseInt(progLevelString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       progression level = "+progLevel);
        }
      codec.AwJ2kSetInputJ2kProgLevel(progLevel);
      }
// ------------------------------------------------------------ -quallevel
    else if (optionsFlag.equals("-quallevel")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String quallevelString    = options[idx++];
      int quallevel             = -1;
      try {
        quallevel    = Integer.parseInt(quallevelString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       quality level     = "+quallevel);
        }
      codec.AwJ2kSetInputJ2kQualLevel(quallevel);
      }
// ------------------------------------------------------------ -fs
    else if (optionsFlag.equals("-fs")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String fileSizeString     = options[idx++];
      int fileSize              = -1;
      try {
        fileSize    = Integer.parseInt(fileSizeString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       file size         = "+fileSize);
        }
      codec.AwJ2kSetOutputJ2kFileSize(fileSize);
      }
// ------------------------------------------------------------ -bpp
    else if (optionsFlag.equals("-bpp")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String bppString   = options[idx++];
      float bpp          = -1;
      try {
        bpp    = (Float.valueOf(bppString)).floatValue();
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       bits per pixel    = "+bpp);
        }
      codec.AwJ2kSetOutputJ2kBitrate(bpp);
      }
// ------------------------------------------------------------ -tol
    else if (optionsFlag.equals("-tol")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String tolString   = options[idx++];
      float tol          = -1;
      try {
        tol    = (Float.valueOf(tolString)).floatValue();
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       tolerance         = "+tol);
        }
      codec.AwJ2kSetOutputJ2kTolerance(tol);
      }
// ------------------------------------------------------------ -cxform
    else if (optionsFlag.equals("-cxform")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String colorTransformString     = options[idx++];
      int colorTransform              = -1;
      try {
        colorTransform    = Integer.parseInt(colorTransformString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       color transform   = "+colorTransform);
        }
      codec.AwJ2kSetOutputJ2kColorXform(colorTransform);
      }
// ------------------------------------------------------------ -lay
    else if (optionsFlag.equals("-lay")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String numLayersString     = options[idx++];
      int numLayers              = -1;
      try {
        numLayers    = Integer.parseInt(numLayersString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       number of layers   = "+numLayers);
        }
      codec.AwJ2kSetOutputJ2kLayers(numLayers);
      }
// ------------------------------------------------------------ -quant
    else if (optionsFlag.equals("-quant")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input options array is too small");
      String quantOptionString     = options[idx++];
      String channelIdxString      = options[idx++];
      int quantOption              = -1;
      int channelIdx               = -1;
      try {
        quantOption    = Integer.parseInt(quantOptionString);
        channelIdx     = Integer.parseInt(channelIdxString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       quantization option = "+quantOption);
        System.out.println("       channel index       = "+channelIdx);
        }
      codec.AwJ2kSetOutputJ2kChanQuant(channelIdx, quantOption);
      }
// ------------------------------------------------------------ -guard
    else if (optionsFlag.equals("-guard")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String guardString     = options[idx++];
      int guard              = -1;
      try {
        guard    = Integer.parseInt(guardString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       number of guard bits = "+guard);
        }
      codec.AwJ2kSetOutputJ2kGuardBits(guard);
      }
// ------------------------------------------------------------ -prog-order
    else if (optionsFlag.equals("-prog-order")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String progressionOrderString     = options[idx++];
      int progressionOrder              = -1;
      try {
        progressionOrder    = Integer.parseInt(progressionOrderString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       progression order = "+progressionOrder);
        }
      codec.AwJ2kSetOutputJ2kProgOrder(progressionOrder);
      }
// ------------------------------------------------------------ -code-style
    else if (optionsFlag.equals("-code-style")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String codingStyleString     = options[idx++];
      int codingStyle              = -1;
      try {
        codingStyle    = Integer.parseInt(codingStyleString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       coding style      = "+codingStyle);
        }
      codec.AwJ2kSetOutputJ2kCodingStyle(codingStyle);
      }
// ------------------------------------------------------------ -clear-com
    else if (optionsFlag.equals("-clear-com")) {
      codec.AwJ2kSetOutputJ2kClearComnts();
      }
// ------------------------------------------------------------ -lambda
    else if (optionsFlag.equals("-lambda")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String lambdaString   = options[idx++];
      float lambda          = -1;
      try {
        lambda    = (Float.valueOf(lambdaString)).floatValue();
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       lambda            = "+lambda);
        }
      codec.AwJ2kSetOutputJ2kLambda(lambda);
      }
// ------------------------------------------------------------ -ratio
    else if (optionsFlag.equals("-ratio")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String ratioString   = options[idx++];
      float ratio          = -1.f;
      try {
        ratio    = (Float.valueOf(ratioString)).floatValue();
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       compression ratio = "+ratio);
        }
      codec.AwJ2kSetOutputJ2kRatio(ratio);
      }
// ------------------------------------------------------------ -jpg-qual
    else if (optionsFlag.equals("-jpg-qual")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String jpegQualityLevelString     = options[idx++];
      int jpegQualityLevel              = -1;
      try {
        jpegQualityLevel    = Integer.parseInt(jpegQualityLevelString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       jpeg quality level= "+jpegQualityLevel);
        }
      codec.AwJ2kSetOutputJpegOptions(jpegQualityLevel);
      }
// ------------------------------------------------------------ -res
    else if (optionsFlag.equals("-res")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input options array is too small");
      String resolutionLevelString     = options[idx++];
      String fullTransformFlagString   = options[idx++];
      int resolutionLevel              = -1;
      int fullTransformFlag            = -1;
      try {
        resolutionLevel     = Integer.parseInt(resolutionLevelString);
        fullTransformFlag   = Integer.parseInt(fullTransformFlagString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       resolution level   = "+resolutionLevel);
        System.out.println("       full transform flag= "+fullTransformFlag);
        }
      codec.AwJ2kSetInputJ2kResLevel(resolutionLevel, fullTransformFlag);
      }
// ------------------------------------------------------------ -col-level
    else if (optionsFlag.equals("-col-level")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input options array is too small");
      String numColorLevelsString       = options[idx++];
      String colorTransformFlagString   = options[idx++];
      int numColorLevels                = -1;
      int colorTransformFlag            = -1;
      try {
        numColorLevels          = Integer.parseInt(numColorLevelsString);
        colorTransformFlag      = Integer.parseInt(colorTransformFlagString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       number of color levels  = "+numColorLevels);
        System.out.println("       color transform flag    = "+colorTransformFlag);
        }
      codec.AwJ2kSetInputJ2kColorLevel(numColorLevels, colorTransformFlag);
      }
// ------------------------------------------------------------ -region
    else if (optionsFlag.equals("-region")) {
      if (options.length < 5)
        throw new AwJ2kException("***Error: input options array is too small");
      String x0RegionLevelString       = options[idx++];
      String y0RegionLevelString       = options[idx++];
      String x1RegionLevelString       = options[idx++];
      String y1RegionLevelString       = options[idx++];
      int x0RegionLevel                = -1;
      int y0RegionLevel                = -1;
      int x1RegionLevel                = -1;
      int y1RegionLevel                = -1;
      try {
        x0RegionLevel          = Integer.parseInt(x0RegionLevelString);
        y0RegionLevel          = Integer.parseInt(y0RegionLevelString);
        x1RegionLevel          = Integer.parseInt(x1RegionLevelString);
        y1RegionLevel          = Integer.parseInt(y1RegionLevelString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       x0 region level coordinate  = "+x0RegionLevel);
        System.out.println("       y0 region level coordinate  = "+y0RegionLevel);
        System.out.println("       x1 region level coordinate  = "+x1RegionLevel);
        System.out.println("       y1 region level coordinate  = "+y1RegionLevel);
        }
      codec.AwJ2kSetInputJ2kRegionLevel(x0RegionLevel, y0RegionLevel, x1RegionLevel, y1RegionLevel);
      }
// ------------------------------------------------------------ -xform
    else if (optionsFlag.equals("-xform")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input options array is too small");
      String transformTypeString        = options[idx++];
      String numTransformLevelsString   = options[idx++];
      int transformType                 = -1;
      int numTransformLevels            = -1;
      try {
        transformType           = Integer.parseInt(transformTypeString);
        numTransformLevels      = Integer.parseInt(numTransformLevelsString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       wavelet transform type      = "+transformType);
        System.out.println("       number of transform levels  = "+numTransformLevels);
        }
      codec.AwJ2kSetOutputJ2kXform(transformType, numTransformLevels);
      }
// ------------------------------------------------------------ -cblock
    else if (optionsFlag.equals("-cblock")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input options array is too small");
      String widthCodeblockString       = options[idx++];
      String heightCodeblockString      = options[idx++];
      int widthCodeblock                = -1;
      int heightCodeblock               = -1;
      try {
        widthCodeblock              = Integer.parseInt(widthCodeblockString);
        heightCodeblock             = Integer.parseInt(heightCodeblockString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       codeblock width      = "+widthCodeblock);
        System.out.println("       codeblock height     = "+heightCodeblock);
        }
      codec.AwJ2kSetOutputJ2kCblockSize(heightCodeblock, widthCodeblock);
      }
// ------------------------------------------------------------ -error-res
    else if (optionsFlag.equals("-error-res")) {
      if (options.length < 4)
        throw new AwJ2kException("***Error: input options array is too small");
      String use_SOP_markerString               = options[idx++];
      String use_EPH_markerString               = options[idx++];
      String use_segmentation_symbolsString     = options[idx++];
      int use_SOP_marker                        = -1;
      int use_EPH_marker                        = -1;
      int use_segmentation_symbols              = -1;
      try {
        use_SOP_marker                          = Integer.parseInt(use_SOP_markerString);
        use_EPH_marker                          = Integer.parseInt(use_EPH_markerString);
        use_segmentation_symbols                = Integer.parseInt(use_segmentation_symbolsString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       SOP marker use flag      = "+use_SOP_marker);
        System.out.println("       EPH marker use flag      = "+use_SOP_marker);
        System.out.println("       segmentation symbol use  = "+use_segmentation_symbols);
        }
      codec.AwJ2kSetOutputJ2kErrorRes(use_SOP_marker, use_EPH_marker, use_segmentation_symbols);
      }
// ------------------------------------------------------------ -comment
   else  if (optionsFlag.equals("-comment")) {
      if (options.length < 4)
        throw new AwJ2kException("***Error: input options array is too small");
      String typeString         = options[idx++];
      String locationString     = options[idx++];
      String fileName           = options[idx++];
      int type                  = -1;
      int location              = -1;
      String comment            = readComment(fileName);
      try {
        type                   = Integer.parseInt(typeString);
        location               = Integer.parseInt(locationString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       file name option  = "+fileName);
        System.out.println("       comment type      = "+type);
        System.out.println("       comment location  = "+type);
        System.out.println("       comment           = "+comment);
        }
      codec.AwJ2kSetOutputJ2kAddComment(comment, type, comment.length(), location);
      }
// ------------------------------------------------------------ -tile-off
    else if (optionsFlag.equals("-tile-off")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input options array is too small");
      String xTileOffsetString          = options[idx++];
      String yTileOffsetString          = options[idx++];
      int xTileOffset                   = -1;
      int yTileOffset                   = -1;
      try {
        xTileOffset                 = Integer.parseInt(xTileOffsetString);
        yTileOffset                 = Integer.parseInt(yTileOffsetString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       x-direction tile offset  = "+xTileOffset);
        System.out.println("       y-direction tile offset  = "+yTileOffset);
        }
      codec.AwJ2kSetOutputJ2kTileOffset(xTileOffset, yTileOffset);
      }
// ------------------------------------------------------------ -tile-size
    else if (optionsFlag.equals("-tile-size")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input options array is too small");
      String widthTileString            = options[idx++];
      String heightTileString           = options[idx++];
      int widthTile                     = -1;
      int heightTile                    = -1;
      try {
        widthTile                   = Integer.parseInt(widthTileString);
        heightTile                  = Integer.parseInt(heightTileString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       tile width        = "+widthTile);
        System.out.println("       tile height       = "+heightTile);
        }
      codec.AwJ2kSetOutputJ2kTileSize(widthTile, heightTile);
      }
// ------------------------------------------------------------ -image-off
    else if (optionsFlag.equals("-image-off")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input options array is too small");
      String xImageOffsetString          = options[idx++];
      String yImageOffsetString          = options[idx++];
      int xImageOffset                   = -1;
      int yImageOffset                   = -1;
      try {
        xImageOffset                 = Integer.parseInt(xImageOffsetString);
        yImageOffset                 = Integer.parseInt(yImageOffsetString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       x-direction image offset  = "+xImageOffset);
        System.out.println("       y-direction image offset  = "+yImageOffset);
        }
      codec.AwJ2kSetOutputJ2kImageOffset(xImageOffset, yImageOffset);
      }
// ------------------------------------------------------------ -selected-tile
    else if (optionsFlag.equals("-selected-tile")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String selTileString          = options[idx++];
      int selTile                   = -1;
      try {
        selTile                 = Integer.parseInt(selTileString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       selected tile index  = "+selTile);
        }
      codec.AwJ2kSetInputJ2kSelectedTile(selTile);
      }
// ------------------------------------------------------------ -layer-ratio
    else if (optionsFlag.equals("-layer-ratio")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input options array is too small");
      String layerIdxString       = options[idx++];
      String ratioString          = options[idx++];
      int layerIdx                = -1;
      float ratio                 = -1.f;
      try {
        layerIdx                 = Integer.parseInt(layerIdxString);
        ratio                    = (Float.valueOf(ratioString)).floatValue();
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       layer index       = "+layerIdx);
        System.out.println("       compression ratio = "+ratio);
        }
      codec.AwJ2kSetOutputJ2kLayerRatio(layerIdx, ratio);
      }
// ------------------------------------------------------------ -layer-size
    else if (optionsFlag.equals("-layer-size")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input options array is too small");
      String layerIdxString       = options[idx++];
      String numBytesString       = options[idx++];
      int layerIdx                = -1;
      int numBytes                = -1;
      try {
        layerIdx                 = Integer.parseInt(layerIdxString);
        numBytes                 = Integer.parseInt(numBytesString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       layer index       = "+layerIdx);
        System.out.println("       number of bytes   = "+numBytes);
        }
      codec.AwJ2kSetOutputJ2kLayerSize(layerIdx, numBytes);
      }
// ------------------------------------------------------------ -layer-bpp
    else if (optionsFlag.equals("-layer-bpp")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input options array is too small");
      String layerIdxString       = options[idx++];
      String bppString            = options[idx++];
      int layerIdx                = -1;
      float bpp                   = -1.f;
      try {
        layerIdx                 = Integer.parseInt(layerIdxString);
        bpp                      = (Float.valueOf(bppString)).floatValue();
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       layer index       = "+layerIdx);
        System.out.println("       bits per pixel    = "+bpp);
        }
      codec.AwJ2kSetOutputJ2kLayerBitrate(layerIdx, bpp);
      }
// ------------------------------------------------------------ -pred-offset
    else if (optionsFlag.equals("-pred-offset")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String predOffsetString       = options[idx++];
      int predOffset                = -1;
      try {
        predOffset                 = Integer.parseInt(predOffsetString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       predictor offset  = "+predOffset);
        }
      codec.AwJ2kSetOutputJ2kPredOffset(predOffset);
      }
// ------------------------------------------------------------ -mqcoder-opt
    else if (optionsFlag.equals("-mqcoder-opt")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input options array is too small");
      String optionString       = options[idx++];
      String valueString        = options[idx++];
      int option                = -1;
      int value                 = -1;
      try {
        option                 = Integer.parseInt(optionString);
        value                  = Integer.parseInt(valueString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       option            = "+option);
        System.out.println("       value             = "+value);
        }
      codec.AwJ2kSetOutputJ2kArithCodingOpt(option, value);
      }
// ------------------------------------------------------------ -intern-opt
    else if (optionsFlag.equals("-intern-opt")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input options array is too small");
      String optionString       = options[idx++];
      String valueString        = options[idx++];
      int option                = -1;
      int value                 = -1;
      try {
        option                 = Integer.parseInt(optionString);
        value                  = Integer.parseInt(valueString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       option            = "+option);
        System.out.println("       value             = "+value);
        }
      codec.AwJ2kSetInternalOption(option, value);
      }
// ------------------------------------------------------------ -comp-reg
    else if (optionsFlag.equals("-comp-reg")) {
      if (options.length < 4)
        throw new AwJ2kException("***Error: input options array is too small");
      String componentString    = options[idx++];
      String xRegString         = options[idx++];
      String yRegString         = options[idx++];
      int component             = -1;
      int xReg                  = -1;
      int yReg                  = -1;
      try {
        component               = Integer.parseInt(componentString);
        xReg                    = Integer.parseInt(xRegString);
        yReg                    = Integer.parseInt(yRegString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       component index   = "+component);
        System.out.println("       x-registration    = "+xReg);
        System.out.println("       y-registration    = "+yReg);
        }
      codec.AwJ2kSetOutputJ2kCompReg(component, xReg, yReg);
      }
// ------------------------------------------------------------ -tile-toc
    else if (optionsFlag.equals("-tile-toc")) {
      codec.AwJ2kSetOutputJ2kTileToc();
      }
// ------------------------------------------------------------ -tile-data-toc
    else if (optionsFlag.equals("-tile-data-toc")) {
      codec.AwJ2kSetOutputJ2kTileDataToc();
      }
// ------------------------------------------------------------ -roi-image
    else if (optionsFlag.equals("-roi-image")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String fileName           = options[idx++];
      byte[] inputROIImage      = readData(fileName);
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       file name option  = "+fileName);
        }
      codec.AwJ2kSetOutputJ2kRoiFromImage(inputROIImage, inputROIImage.length);
      }
// ------------------------------------------------------------ -roi-image-type
    else if (optionsFlag.equals("-roi-image-type")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: input options array is too small");
      String fileName                   = options[idx++];
      String inputROIImageTypeString    = options[idx++];
      int inputROIImageType             = -1;
      try {
        inputROIImageType       = Integer.parseInt(inputROIImageTypeString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      byte[] inputROIImage      = readData(fileName);
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       file name option  = "+fileName);
        System.out.println("       ROI image type    = "+inputROIImageType);
        }
      codec.AwJ2kSetOutputJ2kRoiFromImageType(
                                        inputROIImage,
                                        inputROIImage.length,
                                        inputROIImageType);
      }
// ------------------------------------------------------------ -roi-image-raw
    else if (optionsFlag.equals("-roi-image-raw")) {
      if (options.length < 6)
        throw new AwJ2kException("***Error: input options array is too small");
      String fileName                   = options[idx++];
      String inputROINumRowsString      = options[idx++];
      String inputROINumColsString      = options[idx++];
      String inputROINumBppString       = options[idx++];
      String inputROIbInterlacedString  = options[idx++];
      int inputROINumRows               = -1;
      int inputROINumCols               = -1;
      int inputROINumBpp                = -1;
      int inputROIbInterlaced           = -1;
      try {
        inputROINumRows             = Integer.parseInt(inputROINumRowsString);
        inputROINumCols             = Integer.parseInt(inputROINumColsString);
        inputROINumBpp              = Integer.parseInt(inputROINumBppString);
        inputROIbInterlaced         = Integer.parseInt(inputROIbInterlacedString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      byte[] inputROIImage      = readData(fileName);
      boolean isInterlaced      = false;
      if (inputROIbInterlaced != 0)
        isInterlaced    = true;
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       file name option             = "+fileName);
        System.out.println("       ROI number of rows           = "+inputROINumRows);
        System.out.println("       ROI number of columns        = "+inputROINumCols);
        System.out.println("       ROI number of bits per pixel = "+inputROINumBpp);
        System.out.println("       ROI interlacing type         = "+inputROIbInterlaced);
        }
      codec.AwJ2kSetOutputJ2kRoiFromImageRaw(
                                        inputROIImage,
                                        inputROINumRows,
                                        inputROINumCols,
                                        inputROINumBpp,
                                        isInterlaced);
      }
// ------------------------------------------------------------ -roi-file-raw
    else if (optionsFlag.equals("-roi-file-raw")) {
      if (options.length < 6)
        throw new AwJ2kException("***Error: input options array is too small");
      String inputROIFileName           = options[idx++];
      String inputROINumRowsString      = options[idx++];
      String inputROINumColsString      = options[idx++];
      String inputROINumBppString       = options[idx++];
      String inputROIbInterlacedString  = options[idx++];
      int inputROINumRows               = -1;
      int inputROINumCols               = -1;
      int inputROINumBpp                = -1;
      int inputROIbInterlaced           = -1;
      try {
        inputROINumRows             = Integer.parseInt(inputROINumRowsString);
        inputROINumCols             = Integer.parseInt(inputROINumColsString);
        inputROINumBpp              = Integer.parseInt(inputROINumBppString);
        inputROIbInterlaced         = Integer.parseInt(inputROIbInterlacedString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      boolean isInterlaced      = false;
      if (inputROIbInterlaced != 0)
        isInterlaced    = true;
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       ROI number of rows           = "+inputROINumRows);
        System.out.println("       ROI number of columns        = "+inputROINumCols);
        System.out.println("       ROI number of bits per pixel = "+inputROINumBpp);
        System.out.println("       ROI interlacing type         = "+inputROIbInterlaced);
        }
      codec.AwJ2kSetOutputJ2kRoiFromFileRaw(
                                        inputROIFileName,
                                        inputROINumRows,
                                        inputROINumCols,
                                        inputROINumBpp,
                                        isInterlaced);
      }
// ------------------------------------------------------------ -roi-file
    else if (optionsFlag.equals("-roi-file")) {
      if (options.length < 2)
        throw new AwJ2kException("***Error: input options array is too small");
      String fileName     = options[idx++];
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       file name option  = "+fileName);
        }
      codec.AwJ2kSetOutputJ2kRoiFromFile(fileName);
      }
// ------------------------------------------------------------ -roi-shape
    else if (optionsFlag.equals("-roi-shape")) {
      if (options.length < 6)
        throw new AwJ2kException("***Error: input options array is too small");
      String inputROIShapeString    = options[idx++];
      String inputROIxString        = options[idx++];
      String inputROIyString        = options[idx++];
      String inputROIWidthString    = options[idx++];
      String inputROIHeightString   = options[idx++];
      int inputROIShape             = -1;
      int inputROIx                 = -1;
      int inputROIy                 = -1;
      int inputROIWidth             = -1;
      int inputROIHeight            = -1;
      try {
        inputROIShape               = Integer.parseInt(inputROIShapeString);
        inputROIx                   = Integer.parseInt(inputROIxString);
        inputROIy                   = Integer.parseInt(inputROIyString);
        inputROIWidth               = Integer.parseInt(inputROIWidthString);
        inputROIHeight              = Integer.parseInt(inputROIHeightString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing data");
        }
      if (isVerboseDrvOpt) {
        System.out.println("       option name       = "+optionsFlag);
        System.out.println("       ROI shape         = "+inputROIShape);
        System.out.println("       ROI x coordinate  = "+inputROIx);
        System.out.println("       ROI y coordinate  = "+inputROIy);
        System.out.println("       ROI width         = "+inputROIWidth);
        System.out.println("       ROI height        = "+inputROIHeight);
        }
      codec.AwJ2kSetOutputJ2kRoiAddShape(
                                        inputROIShape,
                                        inputROIx,
                                        inputROIy,
                                        inputROIWidth,
                                        inputROIHeight);
      }
// ------------------------------------------------------------ -clear-roi
    else if (optionsFlag.equals("-clear-roi")) {
      codec.AwJ2kSetOutputJ2kClearRoi();
      }
    else {
      throw new AwJ2kException("***Error: unknown option flag");
      }


    return(idx);


}
/**
  * This method
  *
  * @return none
  */

  protected void handleGenerateOutput(
                            String[]    options) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************

// ---------- check to see if options exist. These are required, unless
// ---------- the Info options are present. If Info options are not used,
// ---------- then throw an exception if these don't exist

    if (options == null)
      if (!isUsingInfoOpt)
        throw new AwJ2kException("***Error: the required output image options don't exist");



    String optionsFlag  = options[0];

    if (isVerboseDrvOpt)
      System.out.println(" sub-options name = "+OUTPUT_IMAGE_FLAG);


// ------------------------------------------------------------ -output-file
    if (optionsFlag.equals("-output-file")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: output image options array is too small");
      String fileTypeString   = options[1];
      String fileName         = options[2];
      int fileType          = -1;
      try {
        fileType    = Integer.parseInt(fileTypeString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing file type");
        }
      if (isVerboseDrvOpt) {
        System.out.println("        option name      = "+optionsFlag);
        System.out.println("        file name option = "+fileName);
        System.out.println("        file type option = "+fileType);
        }
      codec.AwJ2kSetOutputType(fileType);
      codec.AwJ2kGetOutputImageFile(fileName);
      }
// ------------------------------------------------------------ -output-file-type
    else if (optionsFlag.equals("-output-file-type")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: output image options array is too small");
      String fileTypeString = options[1];
      String fileName       = options[2];
      int fileType          = -1;
      try {
        fileType    = Integer.parseInt(fileTypeString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing file type");
        }
      if (isVerboseDrvOpt) {
        System.out.println("        option name      = "+optionsFlag);
        System.out.println("        file name option = "+fileName);
        System.out.println("        file type option = "+fileType);
        }
      codec.AwJ2kGetOutputImageFileType(fileName, fileType);
      }
// ------------------------------------------------------------ -output-file-raw
    else if (optionsFlag.equals("-output-file-raw")) {
      if (options.length < 4)
        throw new AwJ2kException("***Error: output image options array is too small");
      String isInterleavedString = options[1];
      String fileName            = options[2];
      String endianTypeString    = options[3];
      int isInterleaved          = -1;
      int endianType             = -1;
      try {
        isInterleaved   = Integer.parseInt(isInterleavedString);
        endianType      = Integer.parseInt(endianTypeString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing file type");
        }
      if (isVerboseDrvOpt) {
        System.out.println("        option name      = "+optionsFlag);
        System.out.println("        file name option = "+fileName);
        System.out.println("        interleaving     = "+isInterleaved);
        System.out.println("        endianness       = "+endianType);
        }
      boolean isInterleavedBoolean  = false;
      if (isInterleaved != 0)
        isInterleavedBoolean    = true;
      if (      (endianType != AwJ2kParameters.AW_J2K_ENDIAN_LOCAL_MACHINE)
            &&  (endianType != AwJ2kParameters.AW_J2K_ENDIAN_SMALL        )
            &&  (endianType != AwJ2kParameters.AW_J2K_ENDIAN_BIG          ) )
        throw new AwJ2kException("***Error: invalid input endianness value");
      codec.AwJ2kSetOutputRawEndianness(endianType);
      codec.AwJ2kGetOutputImageFileRaw(fileName, isInterleavedBoolean);
      }
// ------------------------------------------------------------ -output-image
    else if (optionsFlag.equals("-output-image")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: output image options array is too small");
      String imageTypeString   = options[1];
      String fileName          = options[2];
      int imageType          = -1;
      try {
        imageType    = Integer.parseInt(imageTypeString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing file type");
        }
      if (isVerboseDrvOpt) {
        System.out.println("        option name      = "+optionsFlag);
        System.out.println("        file name option  = "+fileName);
        System.out.println("        image type option = "+imageType);
        }
      codec.AwJ2kSetOutputType(imageType);
      AwOutputImageValue valueObj = codec.AwJ2kGetOutputImage();
      byte[] outBuffer  = valueObj.getImage();
      int outBufferLen  = valueObj.getImageLength();
      writeData(fileName, outBuffer, outBufferLen);
      }
// ------------------------------------------------------------ -output-image-type
    else if (optionsFlag.equals("-output-image-type")) {
      if (options.length < 3)
        throw new AwJ2kException("***Error: output image options array is too small");
      String imageTypeString = options[1];
      String fileName        = options[2];
      int imageType          = -1;
      try {
        imageType    = Integer.parseInt(imageTypeString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing file type");
        }
      if (isVerboseDrvOpt) {
        System.out.println("        option name      = "+optionsFlag);
        System.out.println("        file name option = "+fileName);
        System.out.println("        image type option= "+imageType);
        }
      AwOutputImageValue valueObj = codec.AwJ2kGetOutputImageType(imageType);
      byte[] outBuffer  = valueObj.getImage();
      int outBufferLen  = valueObj.getImageLength();
      writeData(fileName, outBuffer, outBufferLen);
      }
// ------------------------------------------------------------ -output-image-raw
    else if (optionsFlag.equals("-output-image-raw")) {
      if (options.length < 4)
        throw new AwJ2kException("***Error: output image options array is too small");
      String isInterleavedString = options[1];
      String fileName            = options[2];
      String endianTypeString    = options[3];
      int isInterleaved          = -1;
      int endianType             = -1;
      try {
        isInterleaved   = Integer.parseInt(isInterleavedString);
        endianType      = Integer.parseInt(endianTypeString);
        }
      catch (NumberFormatException exc) {
        throw new AwJ2kException("***Error: number format exception when parsing file type");
        }
      if (isVerboseDrvOpt) {
        System.out.println("        option name      = "+optionsFlag);
        System.out.println("        file name option = "+fileName);
        System.out.println("        interleaving     = "+isInterleaved);
        System.out.println("        endianness       = "+endianType);
        }
      boolean isInterleavedBoolean  = false;
      if (isInterleaved != 0)
        isInterleavedBoolean    = true;
      if (      (endianType != AwJ2kParameters.AW_J2K_ENDIAN_LOCAL_MACHINE)
            &&  (endianType != AwJ2kParameters.AW_J2K_ENDIAN_SMALL        )
            &&  (endianType != AwJ2kParameters.AW_J2K_ENDIAN_BIG          ) )
        throw new AwJ2kException("***Error: invalid input endianness value");
      codec.AwJ2kSetOutputRawEndianness(endianType);
      AwOutputImageRawValue valueObj = codec.AwJ2kGetOutputImageRaw(isInterleavedBoolean);
      byte[] outBuffer    = valueObj.getImage();
      int outBufferLen    = valueObj.getImageLength();
	  int outNumRows      = valueObj.getNumRows();
	  int outNumCols      = valueObj.getNumCols();
	  int outNumChan      = valueObj.getNumChannels();
	  int outBpp          = valueObj.getNumBitsPerPixel();
	  writeData(fileName, outBuffer, outBufferLen);
      }
    else {
      throw new AwJ2kException("***Error: unknown output image option flag");
      }




}
/**
  * This method
  *
  * @return none
  */

  protected byte[] readData(
                    String  fileName) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************

    BufferedInputStream bin = null;
    byte[] data             = null;
    try {
        bin             = new BufferedInputStream(
                                    new FileInputStream(fileName));
        int numBytes    = bin.available();
        data            = new byte [numBytes];
        bin.read(data);
    }
    catch (IOException exc) {
        throw new AwJ2kException("***IOException during data reading= "+exc);
    }
    finally {
        try {
            if (bin != null)
              bin.close();
        } catch (IOException exc) {}
    }

    return(data);
}
/**
  * This method
  *
  * @return none
  */

  protected String readComment(
                    String  fileName) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************

    BufferedReader bin = null;
    String textLine    = null;
    String comment     = null;
    StringBuffer buf   = new StringBuffer();
    try {
        bin             = new BufferedReader(
                                    new FileReader(fileName));
        while ( (textLine = bin.readLine()) != null)
            buf.append(textLine);
        comment = buf.toString();
    }
    catch (IOException exc) {
        throw new AwJ2kException("***IOException during data reading= "+exc);
    }
    finally {
        try {
            if (bin != null)
              bin.close();
        } catch (IOException exc) {}
    }

    return(comment);
}
/**
  * This method writes out image data.
  *
  * @param imageFileName output image file name
  * @param imageData     output image byte data
  * @param imageLength   output image byte data length in number of bytes
  *
  * @throws com.aware.j2k.codec.engine.AwJ2kException
  */
  protected void writeData(
                            String  imageFileName,
                            byte[]  imageData,
                            int     imageLength)  throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************

    BufferedOutputStream bos = null;
    try {
		bos             = new BufferedOutputStream(
                        	        new FileOutputStream(imageFileName));
        bos.write(imageData, 0, imageLength);
    }
    catch (IOException exc) {
        throw new AwJ2kException("***IOException during data writing= "+exc);
    }
    finally {
        try {
            if (bos != null)
              bos.close();
        } catch (IOException exc) {}
    }

}
/**
  * Gets the J2K codec object.
  *
  * @return the J2K codec object.
  */
  public AwJ2k getAwJ2kCodec() {return(codec);}







} // end of class



