/**********************************************************************
 *
 * Copyright 2006 Aware, Inc.
 *
 * $Workfile: j2kdriver.java $    $Revision: 7 $
 * Last Modified: $Date: 2/14/07 12:09p $ by: $Author: Rgut $
 *
 **********************************************************************/

package com.aware.j2k.demo;
import com.aware.j2k.codec.engine.*;
import java.lang.String;
import java.lang.Character;
import java.util.Date;
import java.io.PrintStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.*;

/**
 * This class is a Java implementation of the command-line driver for
 * the java-wrapped J2K library.  The usage of this driver is the
 * same as that of the c-based j2kdriver.
 *
 * Dispatch of the appropriate handler for each command line option is
 * done through reflection, based on a mapping of the option to a
 * method name.  For each command line option there are two method, a
 * handler method (the call method) and a documentation method (the
 * help method).  The name of the call method is derived by prepending
 * `call' to the the option (with dashes replaced by underscores),
 * while the help method is derived by prepending `help' to the the
 * option (with dashes replaced by underscores).  For example, the
 * --help option is dispatched to call__help() or help__help().  The
 * help_flag class parameter controls whether a call or a help method
 * is dispatched.
 */
public class j2kdriver {
  final static String id_j2kdriver_java = "@(#) $Header: /JPEG2000/platform/Java/src/demo/com/aware/j2k/demo/j2kdriver.java 7     2/14/07 12:09p Rgut $ Aware Inc.";

  final static int ARG_MANDATORY = 0; /* mandatory argument */
  final static int ARG_OPTIONAL  = 1; /* optional argument */

  final static int VERBOSITY_MAXIMUM_LEVEL = 2;
  final static int VERBOSITY_MINIMUM_LEVEL = 0;


  int verbosity_flag;           /* level of info printout  */
  int benchmark_flag;           /* number of benchmark iterations */
  int arg;                      // current option
  String[] argv;
  boolean help_flag;
  double file_read_time;         /* time to read image into memory */
  double memory_read_time;       /* time to load image into object */
  PrintStream diagnostic_stream;
  AwJ2k j2k_object;

  public j2kdriver(String[] argv)
  {
    verbosity_flag = VERBOSITY_MINIMUM_LEVEL;
    benchmark_flag = 0;
    help_flag = false;
    file_read_time = 0;
    memory_read_time = 0;
    diagnostic_stream = System.err;
    this.argv = argv;
    try {
      j2k_object = new AwJ2k();
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
  }

  public void call__help()
  {
    help_flag = true;
    return;
  }
  public void help__help()
  {
    System.out.print("--help \n" +
                     "Turns on the help system.  Descriptions of every option listed on the\n" +
                     "command line will be printed after this option is encountered.\n" +
                     "");
  }

  public void call_h()
  {
    call__help();
  }

  public void help_h()
  {
    help__help();
  }


  public void call__get_library_version()
  {
    AwLibraryVersionValue version;
    String print_which;

    print_which = read_string(ARG_OPTIONAL, null);

    try {
      AwLibraryVersionValue library_version_value =
        j2k_object.AwJ2kGetLibraryVersion();
      long library_version = library_version_value.getLibraryVersionId();
      byte[] library_version_string = library_version_value.getLibraryVersion();

      if (print_which != null && (print_which.charAt(0) == 'n' ||
                                  print_which.charAt(0) == 'N'))
        diagnostic_stream.print((library_version / 1000000) + "." +
                                ((library_version / 10000) % 100) + "." +
                                ((library_version / 100) % 100) + "." +
                                (library_version % 100) + "\n");
      else
        diagnostic_stream.print(new String(library_version_string, 0,
                                           library_version_string.length,
                                           "US-ASCII") + " (" +
                                (library_version / 1000000) + "." +
                                ((library_version / 10000) % 100) + "." +
                                ((library_version / 100) % 100) + "." +
                                (library_version % 100) + ")\n");
    }
    catch (java.io.UnsupportedEncodingException uee) {
      uee.printStackTrace(diagnostic_stream);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__get_library_version()
  {
    System.out.print("--get-library-version [<type>]\n" +
                     "Prints the current library version.  The optional argument <type> can be:\n" +
                     "  Numeric - print the only the numeric version\n" +
                     "  String  - print the full version string\n" +
                     "The full version string is printed by default\n" +
                     "");
  }

  public void call__reset_all_options()
  {
    try {
      j2k_object.AwJ2kResetAllOptions();
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__reset_all_options()
  {
    System.out.print("--reset-all-options \n" +
                     "Resets the J2K library object to its initial state.\n" +
                     "");
  }

  public void call__set_internal_option()
  {
    int internal_option, internal_option_value;
    
    internal_option = internal_option_value = 0;
    
    if (argv[arg].equals("--fixed-point")) {
      internal_option       = AwJ2kParameters.AW_J2K_INTERNAL_ARITHMETIC_OPTION;
      internal_option_value = AwJ2kParameters.AW_J2K_INTERNAL_USE_FIXED_POINT;
    }
    else if (argv[arg].equals("--floating-point")) {
      internal_option       = AwJ2kParameters.AW_J2K_INTERNAL_ARITHMETIC_OPTION;
      internal_option_value = AwJ2kParameters.AW_J2K_INTERNAL_USE_FLOATING_POINT;
    }
    else {
      Object internal_option_object =
        read_int_or_string(ARG_MANDATORY, "Internal option not specified");
      Object internal_option_value_object = 
        read_int_or_string(ARG_MANDATORY, "Internal option value not specified");
      
      if (internal_option_value_object instanceof Integer) {
        internal_option_value =
          ((Integer)internal_option_value_object).intValue();
      }
      else {
        internal_option_value = 0;
      }

      if (internal_option_object instanceof Integer) {
        internal_option =
          ((Integer)internal_option_object).intValue();
      }
      else {
        if (internal_option_object instanceof java.lang.String) {
          if ((((String)internal_option_object).charAt(0) == 'a') ||
              (((String)internal_option_object).charAt(0) == 'A')) {
            internal_option = AwJ2kParameters.AW_J2K_INTERNAL_ARITHMETIC_OPTION;
            if (internal_option_value_object instanceof java.lang.String) {
              if ((((String)internal_option_value_object).charAt(0) == 'f') ||
                  (((String)internal_option_value_object).charAt(0) == 'F')) {
                if (((String)internal_option_value_object).charAt(1) == 'l' ||
                    ((String)internal_option_value_object).charAt(1) == 'L')
                  internal_option_value = AwJ2kParameters.AW_J2K_INTERNAL_USE_FLOATING_POINT;
                else if (((String)internal_option_value_object).charAt(1) == 'i' ||
                         ((String)internal_option_value_object).charAt(1) == 'I')
                  internal_option_value = AwJ2kParameters.AW_J2K_INTERNAL_USE_FIXED_POINT;
                else {
                  diagnostic_stream.println("Unknown internal option value `" +
                                            ((String)internal_option_value_object) +
                                            "', ignored.");
                  return;
                }
              }
            }
          }
          else if ((((String)internal_option_object).charAt(0) == 'm') ||
                   (((String)internal_option_object).charAt(0) == 'M')) {
            internal_option = AwJ2kParameters.AW_J2K_INTERNAL_MULTITHREADING_OPTION;
          }
          else {
            diagnostic_stream.println("Unknown internal option `" +
                                      ((String)internal_option_object) +
                                      "', ignored.");
            return;
          }
        }
      }
    }
    
    try {
      j2k_object.AwJ2kSetInternalOption(internal_option, internal_option_value);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_internal_option()
  {
    System.out.print("--set-internal-option <option> <value>\n" +
                     "Sets the internal option <option> to <value>.  The options are:\n" +
                     "  arithmetic - sets the type of arithmetic operations that will be used for\n" +
                     "               irreversible processing (i.e. when using the I97 wavelet)\n" +
                     "For the arithmetic option, the values are:\n" +
                     "  fixed      - for fixed-point operation\n" +
                     "  float      - for floating-point operation\n" +
                     "Using the --fixed-point flag is equivalent to using\n" +
                     "`--set-internal-option arithmetic fixed', and using the --floating-point\n" +
                     "flag is equivalent to `--set-internal-option arithmetic float'.\n" +
                     "");
  }
  public void call__floating_point()
  {
    call__set_internal_option();
  }
  public void help__floating_point()
  {
    System.out.print("--floating-point \n" +
                     "Selects the usage of fixed-point arithmetic for irreversible processing\n" +
                     "(i.e. when using the I97 wavelet).  Using the --floating-point flag is\n" +
                     "equivalent to using `--set-internal-option arithmetic float'.\n" +
                     "");
  }
  public void call__fixed_point()
  {
    call__set_internal_option();
  }
  public void help__fixed_point()
  {
    System.out.print("--fixed-point \n" +
                     "Selects the usage of fixed-point arithmetic for irreversible processing\n" +
                     "(i.e. when using the I97 wavelet).  Using the --fixed-point flag is\n" +
                     "equivalent to using `--set-internal-option arithmetic fixed'.\n" +
                     "");
  }

  public void call__set_input_image()
  {
    String image_name;
    byte[] buffer;

    image_name = read_string(ARG_MANDATORY, "Image file name not specified");

    file_read_time = get_precise_time();
    buffer = load_raw_data(image_name);
    file_read_time = get_precise_time() - file_read_time;

    if (buffer == null || buffer.length == 0) {
      if (image_name.equals("-"))
        System.err.println("Error: unable to read from stdin");
      else
        System.err.println("Error: unable to read `" + image_name + "'");
      return;
    }

    try {
      memory_read_time = get_precise_time();
      j2k_object.AwJ2kSetInputImage(buffer, buffer.length);
      memory_read_time = get_precise_time() - memory_read_time;
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_image()
  {
    System.out.print("--set-input-image <image file name>\n" +
                     "Reads an input image from the file <image file name>, and inputs it into\n" +
                     "the library using the memory-buffer interface.  The image type is deduced\n" +
                     "From the image itself.\n" +
                     "");
  }

  public void call_i()
  {
    call__set_input_image();
  }

  public void help_i()
  {
    help__set_input_image();
  }

  public void call__input_file_name()
  {
    call__set_input_image();
  }

  public void help__input_file_name()
  {
    help__set_input_image();
  }
  public void call__set_input_image_type()
  {
    String image_name;
    byte[] buffer;
    int type;

    type = read_type(ARG_MANDATORY, "Image type not specified");

    image_name = read_string(ARG_MANDATORY, "Image file name not specified");

    file_read_time = get_precise_time();
    buffer = load_raw_data(image_name);
    file_read_time = get_precise_time() - file_read_time;

    if (buffer == null || buffer.length == 0) {
      if (image_name.equals("-"))
        System.err.println("Error: unable to read from stdin");
      else
        System.err.println("Error: unable to read `" + image_name + "'");
      return;
    }

    try {
      memory_read_time = get_precise_time();
      j2k_object.AwJ2kSetInputImageType(type, buffer, buffer.length);
      memory_read_time = get_precise_time() - memory_read_time;
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_image_type()
  {
    System.out.print("--set-input-image-type <image type> <image file name>\n" +
                     "Reads an input image from the file <image file name>, and inputs it into\n" +
                     "the library using the memory-buffer interface.  The image type is specified\n" +
                     "by <image type>, which must be one of:\n" +
                     "  j2k                - JPEG2000 codestreams\n" +
                     "  jp2                - JPEG2000 file format\n" +
                     "  tif, tiff          - TIFF\n" +
                     "  pnm, pbm, pgm, ppm - Any of the portable bit/gray/pix-map formats\n" +
                     "  dcm, dcm_raw       - DICOM (with embedded raw pixels)\n" +
                     "  dcm_j2k            - DICOM (with embedded J2K codestreams)\n" +
                     "  bmp                - Windows bitmap\n" +
                     "  tga, targa         - TARGA image format\n" +
                     "  jpg, jpeg          - Original JPEG format\n" +
                     "  pgx                - Extended portable graymap format\n" +
                     "");
  }
  public void call__set_input_image_raw()
  {
    String image_name;
    byte[] buffer;
    int rows, cols, channels;
    int bit_depth;
    boolean interleaved = false;

    image_name = read_string(ARG_MANDATORY, "Image file name not specified");

    rows = read_int(ARG_MANDATORY, "Image rows not specified");
    cols = read_int(ARG_MANDATORY, "Image columns not specified");
    channels = read_int(ARG_MANDATORY,
                        "The number of image channels not specified");
    bit_depth = read_int(ARG_MANDATORY, "Total image bit depth not specified");

    interleaved = read_boolean(ARG_OPTIONAL, null, false);

    file_read_time = get_precise_time();
    buffer = load_raw_data(image_name);
    file_read_time = get_precise_time() - file_read_time;

    if (buffer == null || buffer.length == 0) {
      if (image_name.equals("-"))
        System.err.println("Error: unable to read from stdin");
      else
        System.err.println("Error: unable to read `" + image_name + "'");
      return;
    }

    try {
      memory_read_time = get_precise_time();
      j2k_object.AwJ2kSetInputImageRaw(buffer, rows, cols, channels,
                                       bit_depth, interleaved);
      memory_read_time = get_precise_time() - memory_read_time;
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_image_raw()
  {
    System.out.print("--set-input-image-raw <image file name> <rows> <columns> <channels> <total bit depth> [<interleaved>]\n" +
                     "Reads a raw input image from the file <image file name>, and inputs it into\n" +
                     "the library using the memory-buffer interface.  The size of the image must\n" +
                     "be specified using <rows>, <columns>, <channels>, and <total bit depth>.  The\n" +
                     "optional <interleaved> flag indicates whether the channel data is interleaved\n" +
                     "or not (the default if not specified).  <interleaved> may be `yes' or `no'.\n" +
                     "");
  }
  public void call__input_file_raw()
  {
    call__set_input_image_raw();
  }

  public void help__input_file_raw()
  {
    help__set_input_image_raw();
  }
  public void call__set_input_image_raw_ex()
  {
    String image_name;
    byte[] buffer;
    int rows, cols, channels;
    int bits_allocated, bits_stored;
    boolean interleaved = false;

    image_name = read_string(ARG_MANDATORY, "Image file name not specified");

    rows = read_int(ARG_MANDATORY, "Image rows not specified");
    cols = read_int(ARG_MANDATORY, "Image columns not specified");
    channels = read_int(ARG_MANDATORY,
                        "The number of image channels not specified");
    bits_allocated = read_int(ARG_MANDATORY,
                              "Total bits allocated not specified");
    bits_stored = read_int(ARG_MANDATORY,
                           "Total bits stored not specified");

    interleaved = read_boolean(ARG_OPTIONAL, null, false);

    file_read_time = get_precise_time();
    buffer = load_raw_data(image_name);
    file_read_time = get_precise_time() - file_read_time;

    if (buffer == null || buffer.length == 0) {
      if (image_name.equals("-"))
        System.err.println("Error: unable to read from stdin");
      else
        System.err.println("Error: unable to read `" + image_name + "'");
      return;
    }

    try {
      memory_read_time = get_precise_time();
      j2k_object.AwJ2kSetInputImageRawEx(buffer, rows, cols, channels,
                                         bits_allocated, bits_stored,
                                         interleaved);
      memory_read_time = get_precise_time() - memory_read_time;
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_image_raw_ex()
  {
    System.out.print("--set-input-image-raw-ex <image file name> <rows> <columns> <channels> <bits allocated> <bits stored> [<interleaved>]\n" +
                     "Reads a raw input image from the file <image file name>, and inputs it into\n" +
                     "the library using the memory-buffer interface.  The size of the image must\n" +
                     "be specified using <rows>, <columns>, <channels>, <bits allocated> and <bits\n" +
                     "stored>.  The optional <interleaved> flag indicates whether the channel data\n" +
                     "is interleaved or not (the default if not specified).  <interleaved> may be\n" +
                     "`yes' or `no'.\n" +
                     "");
  }
  public void call__set_input_image_raw_channel()
  {
    String image_name;
    byte[] buffer;
    int channel;

    channel = read_int(ARG_MANDATORY, "Channel index not specified");

    image_name = read_string(ARG_MANDATORY,
                             "Channel data file name not specified");

    file_read_time = get_precise_time();
    buffer = load_raw_data(image_name);
    file_read_time = get_precise_time() - file_read_time;

    if (buffer == null || buffer.length == 0) {
      if (image_name.equals("-"))
        System.err.println("Error: unable to read from stdin");
      else
        System.err.println("Error: unable to read `" + image_name + "'");
      return;
    }

    try {
      memory_read_time = get_precise_time();
      j2k_object.AwJ2kSetInputImageRawChannel(channel, buffer, buffer.length);
      memory_read_time = get_precise_time() - memory_read_time;
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_image_raw_channel()
  {
    System.out.print("--set-input-image-raw-channel <channel index> <channel data file name>\n" +
                     "Loads the data for channel number <channel index> from <channel data file\n" +
                     "name>.  The data is input into the library using the memory-buffer interface\n" +
                     "The dimensions of the image can be provided via a call to\n" +
                     "--set-input-raw-information.\n" +
                     "");
  }


  public void call__set_input_image_raw_region()
  {
    String image_name;
    byte[] buffer;
    long channel, rows, row_offset, cols, col_offset;
    boolean bInterleaved = false;

    image_name = read_string(ARG_MANDATORY,
                             "Region data file name not specified");

    row_offset = read_long(ARG_MANDATORY, "row offset not specified");
    col_offset = read_long(ARG_MANDATORY, "col offset not specified");
    rows = read_long(ARG_MANDATORY, "row not specified");
    cols = read_long(ARG_MANDATORY, "col not specified");
    channel = read_long(ARG_MANDATORY, "channel not specified");
    bInterleaved = read_boolean(ARG_OPTIONAL, null, false);

    file_read_time = get_precise_time();
    buffer = load_raw_data(image_name);
    file_read_time = get_precise_time() - file_read_time;

    if (buffer == null || buffer.length == 0) {
      if (image_name.equals("-"))
        System.err.println("Error: unable to read from stdin");
      else
        System.err.println("Error: unable to read `" + image_name + "'");
      return;
    }

    try {
      memory_read_time = get_precise_time();
      j2k_object.AwJ2kSetInputImageRawRegion(row_offset, col_offset, rows,
                                             cols, channel, buffer,
                                             bInterleaved);
      memory_read_time = get_precise_time() - memory_read_time;
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_image_raw_region()
  {
    System.out.print("--set-input-image-raw-region <region file name> <row offset> <cols offset> <rows> <cols> <channels> <interleaved>\n" +
                     "Loads the data for give region from <channel data file name>.  The data is\n" +
                     "input into the library using the memory-buffer interface.  The dimensions of\n" +
                     "the full image should be provided via a call to --set-input-raw-information.\n" +
                     "");
  }

  public void call__set_input_image_file()
  {
    String image_name;

    image_name = read_string(ARG_MANDATORY, "Image file name not specified");

    try {
      memory_read_time = 0;
      file_read_time = get_precise_time();
      j2k_object.AwJ2kSetInputImageFile(image_name);
      file_read_time = get_precise_time() - file_read_time;
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_image_file()
  {
    System.out.print("--set-input-image-file <image file name>\n" +
                     "Reads an input image from the file <image file name>, and inputs it into\n" +
                     "the library using the file interface.  The image type is deduced\n" +
                     "From the image itself.\n" +
                     "");
  }

  public void call__input_file()
  {
    call__set_input_image_file();
  }

  public void help__input_file()
  {
    help__set_input_image_file();
  }

  public void call__set_input_image_file_type()
  {
    String image_name;
    int type;

    image_name = read_string(ARG_MANDATORY, "Image file name not specified");
    type = read_type(ARG_MANDATORY, "Image type not specified");

    try {
      memory_read_time = 0;
      file_read_time = get_precise_time();
      j2k_object.AwJ2kSetInputImageFileType(image_name, type);
      file_read_time = get_precise_time() - file_read_time;
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_image_file_type()
  {
    System.out.print("--set-input-image-file-type <image file name> <image type>\n" +
                     "Reads an input image from the file <image file name>, and inputs it into\n" +
                     "the library using the file interface.  The image type is specified\n" +
                     "by <image type>, which must be one of:\n" +
                     "  j2k                - JPEG2000 codestreams\n" +
                     "  jp2                - JPEG2000 file format\n" +
                     "  tif, tiff          - TIFF\n" +
                     "  pnm, pbm, pgm, ppm - Any of the portable bit/gray/pix-map formats\n" +
                     "  dcm, dcm_raw       - DICOM (with embedded raw pixels)\n" +
                     "  dcm_j2k            - DICOM (with embedded J2K codestreams)\n" +
                     "  bmp                - Windows bitmap\n" +
                     "  tga, targa         - TARGA image format\n" +
                     "  jpg, jpeg          - Original JPEG format\n" +
                     "  pgx                - Extended portable graymap format\n" +
                     "");
  }

  public void call__set_input_image_file_raw()
  {
    String image_name;
    int rows, cols, channels;
    int bit_depth;
    boolean interleaved = false;

    image_name = read_string(ARG_MANDATORY, "Image file name not specified");

    rows = read_int(ARG_MANDATORY, "Image rows not specified");
    cols = read_int(ARG_MANDATORY, "Image columns not specified");
    channels = read_int(ARG_MANDATORY,
                        "The number of image channels not specified");
    bit_depth = read_int(ARG_MANDATORY, "Total image bit depth not specified");

    interleaved = read_boolean(ARG_OPTIONAL, null, false);

    try {
      memory_read_time = 0;
      file_read_time = get_precise_time();
      j2k_object.AwJ2kSetInputImageFileRaw(image_name, rows, cols, channels,
                                           bit_depth, interleaved);
      file_read_time = get_precise_time() - file_read_time;
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_image_file_raw()
  {
    System.out.print("--set-input-image-file-raw <image file name> <rows> <columns> <channels> <total bit depth> [<interleaved>]\n" +
                     "Reads a raw input image from the file <image file name>, and inputs it into\n" +
                     "the library using the file interface.  The size of the image must\n" +
                     "be specified using <rows>, <columns>, <channels>, and <total bit depth>.  The\n" +
                     "optional <interleaved> flag indicates whether the channel data is interleaved\n" +
                     "or not (the default if not specified).  <interleaved> may be `yes' or `no'.\n" +
                     "");
  }

  public void call__input_image_file_raw()
  {
    call__set_input_image_file_raw();
  }

  public void help__input_image_file_raw()
  {
    help__set_input_image_file_raw();
  }


  public void call__set_input_raw_information()
  {
    int rows, cols, channels;
    int bit_depth;
    boolean interleaved = false;

    rows = read_int(ARG_MANDATORY, "Image rows not specified");
    cols = read_int(ARG_MANDATORY, "Image columns not specified");
    channels = read_int(ARG_MANDATORY,
                        "The number of image channels not specified");
    bit_depth = read_int(ARG_MANDATORY, "Total image bit depth not specified");

    interleaved = read_boolean(ARG_OPTIONAL, null, false);

    try {
      j2k_object.AwJ2kSetInputRawInformation(rows, cols, channels,
                                             bit_depth, interleaved);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_raw_information()
  {
    System.out.print("--set-input-raw-information <rows> <columns> <channels> <total bit depth> [<interleaved>]\n" +
                     "Sets the dimensions of an image, without providing the image itself.  The\n" +
                     "image data can be provided later using --set-input-image-raw-channel.\n" +
                     "If the data is signed, the bit depth should be negative; it should be positive\n" +
                     "for unsigned data.  <interleaved> may be `yes' or `no'.\n" +
                     "");
  }

  public void call__set_input_raw_channel_bpp()
  {
    int channel;
    int bit_depth;

    channel = read_int(ARG_MANDATORY, "Channel index not specified");
    bit_depth = read_int(ARG_MANDATORY, "Channel bit depth not specified");

    try {
      j2k_object.AwJ2kSetInputRawChannelBpp(channel, bit_depth);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_raw_channel_bpp()
  {
    System.out.print("--set-input-raw-channel-bpp <channel index> <channel bit depth>\n" +
                     "Sets the bit depth of the data in the specified channel.  If the data is\n" +
                     "signed, the bit depth should be negative; it should be positive for unsigned\n" +
                     "data.\n" +
                     "");
  }

  public void call__set_input_raw_endianness()
  {
    int retval, endianness;
    String endianness_string;
  
    endianness_string = null;
    endianness = 0;
  
    Object endianness_option =
      read_int_or_string(ARG_MANDATORY, "Missing endianness specification");
  
    if (endianness_option instanceof String) {
      endianness_string = (String)endianness_option;
      switch (endianness_string.charAt(0)) {
      case 'b': case 'B':         /* "big" */
        endianness = AwJ2kParameters.AW_J2K_ENDIAN_BIG;
        break;
      case 'l': case 'L': case 's': case 'S':
        endianness = AwJ2kParameters.AW_J2K_ENDIAN_SMALL;
        break;
      default:
        endianness = AwJ2kParameters.AW_J2K_ENDIAN_LOCAL_MACHINE;
      }
    }
    else if (endianness_option instanceof Integer) {
      endianness = ((Integer)endianness_option).intValue();
    }
  
    try {
      j2k_object.AwJ2kSetInputRawEndianness(endianness);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_raw_endianness()
  {
    System.out.print("--set-input-raw-endianness <endianness>\n" +
                     "Sets the endianness of multi-byte-per-channel raw images.  The value of\n" +
                     "<endianness> should be `big' or `little'.\n" +
                     "");
  }

  public void call__set_input_raw_channel_subsampling()
  {
    int channel, x_subsampling, y_subsampling;
  
    channel = read_int(ARG_MANDATORY, "Channel index not specified");
    x_subsampling = read_int(ARG_MANDATORY,
                             "Horizontal subsampling not specified");
    y_subsampling = read_int(ARG_MANDATORY,
                             "Vertical subsampling not specified");
  
    try {
      j2k_object.AwJ2kSetInputRawChannelSubsampling(channel, x_subsampling,
                                                    y_subsampling);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_raw_channel_subsampling()
  {
    System.out.print("--set-input-raw-channel-subsampling <channel index> <horizontal subsampling> <vertical subsampling>\n" +
                     "Specifies the subsampling of a specific channel relative to the\n" +
                     "full image dimensions.\n" +
                     "");
  }
  public void call__get_input_type()
  {
    int image_type;
    try {
      image_type = j2k_object.AwJ2kGetInputType();
      diagnostic_stream.print("Original image type: ");
      switch (image_type) {
      case AwJ2kParameters.AW_J2K_FORMAT_UNKNOWN:
        diagnostic_stream.println("UNKNOWN");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_RAW:
        diagnostic_stream.println("RAW");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_RAW2:
        diagnostic_stream.println("RAW2");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_TIF:
        diagnostic_stream.println("TIF");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_PPM:
        diagnostic_stream.println("PPM");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_DCM:
        diagnostic_stream.println("DCM");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_BMP:
        diagnostic_stream.println("BMP");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_TGA:
        diagnostic_stream.println("TGA");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_JPG:
        diagnostic_stream.println("JPG");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_J2K:
        diagnostic_stream.println("J2K");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_WSQ:
        diagnostic_stream.println("WSQ");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_JP2:
        diagnostic_stream.println("JP2");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_RAW_INTERLEAVED:
        diagnostic_stream.println("RAW_INTERLEAVED");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_RAW_CHANNELS:
        diagnostic_stream.println("RAW_CHANNELS");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_DCMJ2K:
        diagnostic_stream.println("DCMJ2K");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_YUY2:
        diagnostic_stream.println("YUY2");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_PGX:
        diagnostic_stream.println("PGX");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_VIDEO_RGB24:
        diagnostic_stream.println("VIDEO_RGB24");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_RAW_REGIONS:
        diagnostic_stream.println("RAW_REGIONS");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_TIFFJ2K:
        diagnostic_stream.println("TIFFJ2K");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_VIDEO_RGB24_SINGLEFIELD:
        diagnostic_stream.println("VIDEO_RGB24_SINGLEFIELD");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_VIDEO_RGB24_SINGLEFIELD_SECOND_FIELD:
        diagnostic_stream.println("VIDEO_RGB24_SINGLEFIELD_SECOND_FIELD");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_VIDEO_RGB24_SINGLEFIELD_INTERPOLATED:
        diagnostic_stream.println("VIDEO_RGB24_SINGLEFIELD_INTERPOLATED");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_VIDEO_YUY2_SINGLEFIELD:
        diagnostic_stream.println("VIDEO_YUY2_SINGLEFIELD");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_VIDEO_YUY2_SINGLEFIELD_INTERPOLATED:
        diagnostic_stream.println("VIDEO_YUY2_SINGLEFIELD_INTERPOLATED");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_VIDEO_YUY2_SINGLEFIELD_SECOND_FIELD:
        diagnostic_stream.println("VIDEO_YUY2_SINGLEFIELD_SECOND_FIELD");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_DCMJPG:
        diagnostic_stream.println("DCMJPG");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_PDFJP2:
        diagnostic_stream.println("PDFJP2");
        break;
      case AwJ2kParameters.AW_J2K_FORMAT_DIB:
        diagnostic_stream.println("DIB");
        break;
      default:
        diagnostic_stream.println("unrecognized");
      }
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__get_input_type()
  {
    System.out.print("--get-input-type\n" +
                     "Prints the type of the input image.\n" +
                     "");
  }
  public void call__get_input_image_info()
  {
    AwInputImageInfoValue image_info;
    int columns, rows, bit_depth, channels;
  
    try {
      image_info = j2k_object.AwJ2kGetInputImageInfo();

      columns = image_info.getNumOutputImageCols();
      rows = image_info.getNumOutputImageRows();
      bit_depth = image_info.getNumOutputBitsPerPixel();
      channels = image_info.getNumOutputChannels();

      diagnostic_stream.println("Uncompressed image information:\n" +
                                "   " + columns + " columns by " +
                                rows + " rows, " + channels + " channels, " +
                                bit_depth + " bpp = " +
                                columns * rows * ((bit_depth + 7) / 8) +
                                " bytes");
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__get_input_image_info()
  {
    System.out.print("--get-input-image-info \n" +
                     "Prints the dimensions, total bit depth, and number of channels in\n" +
                     "the image.  The bit depth returned here is the sum of the bit depths\n" +
                     "of all the channels, and does not indicate whether the data is\n" +
                     "signed or not.  Use --get-input-channel-bpp to determine the\n" +
                     "bit depth of each channel, as well as whether the data in the\n" +
                     "channel is signed.\n" +
                     "");
  }

  public void call__get_input_channel_bpp()
  {
    int channel;
    int bit_depth;
  
    channel = read_int(ARG_MANDATORY, "Channel index not specified");
  
    try {
      bit_depth = j2k_object.AwJ2kGetInputChannelBpp(channel);
      if (bit_depth < 0)
        diagnostic_stream.println("Channel " + channel +
                                  " bit depth: " + (-bit_depth) + " (signed)");
      else
        diagnostic_stream.println("Channel " + channel +
                                  " bit depth: " + bit_depth + " (unsigned)");
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__get_input_channel_bpp()
  {
    System.out.print("--get-input-channel-bpp <channel index>\n" +
                     "Returns the bit depth of the specified channel in the image, as well as\n" +
                     "whether the data in the channel is signed or not.\n" +
                     "");
  }

  public void call__get_input_j2k_channel_subsampling()
  {
    int channel;
    AwInputImageChnlSubsampValue subsampling;

    channel = read_int(ARG_MANDATORY, "Channel index not specified");
  
    try {
      subsampling =
        j2k_object.AwJ2kGetInputJ2kChannelSubsampling(channel);
      diagnostic_stream.println("Channel " + channel + " Subsampling: X:" +
                                subsampling.getXSubsampling() +
                                " Y:" + subsampling.getYSubsampling());
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_input_j2k_channel_subsampling()
  {
    System.out.print("--get-input-j2k-channel-subsampling <channel index>\n" +
                     "Returns the subsampling of a channel in a JPEG 2000 image relative\n" +
                     "to the full image dimensions.\n" +
                     "");
  }

  public void call__get_input_j2k_num_comments()
  {
    try {
      diagnostic_stream.println(
        "Found " +
        j2k_object.AwJ2kGetInputNumCommentsInfo().getOutputNumComments() +
        " comments");
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_input_j2k_num_comments()
  {
    System.out.print("--get-input-j2k-num-comments \n" +
                     "Returns the number of comments that are embedded in a JPEG 2000\n" +
                     "image.\n" +
                     "");
  }

  public void call__get_input_j2k_comments()
  {
    AwInputCommentsInfoValue comment;
    int comment_index;
  
    comment_index = read_int(ARG_MANDATORY, "Comment index not specified");
  
    try {
      comment = j2k_object.AwJ2kGetInputCommentsInfo(comment_index);
      diagnostic_stream.println(
        "Comment type " +
        (comment.getOutputCommentType() == AwJ2kParameters.AW_J2K_CO_BINARY ? "binary" : "ISO-8859-1 (Latin 1)") +
        ", length " + comment.getOutputCommentLength());
      byte[] comment_buffer = comment.getOutputCommentBuffer();
      if (comment.getOutputCommentType() == AwJ2kParameters.AW_J2K_CO_BINARY) {
        print_binary(diagnostic_stream, comment_buffer);
      }
      else {
        diagnostic_stream.println("Comment string: `" +
                                  new String(comment_buffer, 0,
                                             comment_buffer.length,
                                             "US-ASCII") +
                                  "'");
      }
    }
    catch (java.io.UnsupportedEncodingException uee) {
      uee.printStackTrace(diagnostic_stream);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_input_j2k_comments()
  {
    System.out.print("--get-input-j2k-comments <comment index>\n" +
                     "Returns a comment from a JPEG 2000 image.  The number of comments can be\n" +
                     "had using --get-input-j2k-num-comments.\n" +
                     "");
  }
  public void call__get_comments()
  {
    call__get_input_j2k_comments();
  }

  public void help__get_comments()
  {
    help__get_input_j2k_comments();
  }

  public void call__get_input_j2k_progression_info()
  {
    try {
      AwProgressionInfoValue
        progression = j2k_object.AwJ2kGetProgressionInfo();
  
      diagnostic_stream.print("Progression information:\n  Progression order: ");
      switch (progression.getOutputProgressionOrder()) {
      case AwJ2kParameters.AW_J2K_PO_LAYER_RESOLUTION_COMPONENT_POSITION:
        diagnostic_stream.println("Layer, resolution, component, position");
        break;
      case AwJ2kParameters.AW_J2K_PO_RESOLUTION_LAYER_COMPONENT_POSITION:
        diagnostic_stream.println("Resolution, layer, component, position");
        break;
      case AwJ2kParameters.AW_J2K_PO_RESOLUTION_POSITION_COMPONENT_LAYER:
        diagnostic_stream.println("Resolution, position, component, layer");
        break;
      case AwJ2kParameters.AW_J2K_PO_POSITION_COMPONENT_RESOLUTION_LAYER:
        diagnostic_stream.println("Position, component, resolution, layer");
        break;
      case AwJ2kParameters.AW_J2K_PO_COMPONENT_POSITION_RESOLUTION_LAYER:
        diagnostic_stream.println("Component, position, resolution, layer");
        break;
      }
  
      diagnostic_stream.println(
        "  Resolution levels: " + progression.getOutputNumTransformLevels() +
        "\n  Quality layers: " + progression.getOutputNumLayers() +
        "\n  Color channels: " + progression.getNumOutputChannels() +
        "\n  Precincts: " + progression.getOutputNumPrecincts() +
        "\n  Progression level available: " +
        progression.getOutputProgAvailable() + " (1 is max, " +
        progression.getOutputNumProgLevels() + " is min)");
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__get_input_j2k_progression_info()
  {
    System.out.print("--get-input-j2k-progression-info \n" +
                     "Prints the progression order, number of wavelet transform levels,\n" +
                     "number of quality layers, and number of color channels in a JPEG\n" +
                     "2000 image.\n" +
                     "");
  }
  public void call__progression_info()
  {
    call__get_input_j2k_progression_info();
  }

  public void help__progression_info()
  {
    help__get_input_j2k_progression_info();
  }

  public void call__image_progression_info()
  {
    call__get_input_j2k_progression_info();
  }

  public void help__image_progression_info()
  {
    help__get_input_j2k_progression_info();
  }

  public void call__get_input_j2k_progression_byte_count()
  {
    int index;
    AwInputProgByteCountValue progression_offset;
  
    index = read_int(ARG_MANDATORY, "Progression index not specified");
  
    try {
      progression_offset = j2k_object.AwJ2kGetProgByteCountInfo(index);
      diagnostic_stream.println("Progression level " + index +
                                " at offset " +
                                progression_offset.getOutputProgOffset());
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_input_j2k_progression_byte_count()
  {
    System.out.print("--get-input-j2k-progression-byte-count <progression level index>\n" +
                     "Prints the number of bytes needed to decode a given progression\n" +
                     "level.  The type of progression level is determined by the\n" +
                     "progression order of the JPEG 2000 image.\n" +
                     "");
  }

  public void call__get_input_j2k_tile_info()
  {
    AwTileInfoValue tile_info;

    try {
      tile_info = j2k_object.AwJ2kGetInputTileInfo();
      diagnostic_stream.print("Tiling information:\n" +
                              "  tile offset: " +
                              tile_info.getOutputTileOffsetX() + "," +
                              tile_info.getOutputTileOffsetY() + "\n" +
                              "  tile size: " +
                              tile_info.getOutputNumTileCols() + "," +
                              tile_info.getOutputNumTileRows() + "\n" +
                              "  image offset: " +
                              tile_info.getOutputImageOffsetX() + "," +
                              tile_info.getOutputImageOffsetY() + "\n");
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_input_j2k_tile_info()
  {
    System.out.print("--get-input-j2k-tile-info \n" +
                     "Prints the tile size and image and tile offsets in a JPEG 2000\n" +
                     "image.\n" +
                     "");
  }
  public void call__image_tiling_info()
  {
    call__get_input_j2k_tile_info();
  }

  public void help__image_tiling_info()
  {
    help__get_input_j2k_tile_info();
  }

  public void call__get_input_j2k_selected_tile_geometry()
  {
    AwSelectedTileGeomInfoValue tile_info;
    int tile_index;
  
    tile_index = read_int(ARG_MANDATORY, "Tile index not specified");
  
    try {
      tile_info  = j2k_object.AwJ2kGetInputSelectedTileGeomInfo(tile_index);
      diagnostic_stream.println("Tile " + tile_info.getTileIndex() +
                                " information:\n" + "  tile offset: " +
                                tile_info.getOutputTileOffsetX() + "," +
                                tile_info.getOutputTileOffsetY() + "\n" +
                                "  tile size: " +
                                tile_info.getOutputNumTileCols() + "," +
                                tile_info.getOutputNumTileRows());
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_input_j2k_selected_tile_geometry()
  {
    System.out.print("--get-input-j2k-selected-tile-geometry <tile index>\n" +
                     "Returns the size of a tile and its offset from the image origin.\n" +
                     "");
  }

  public void call__get_input_j2k_component_registration()
  {
    int channel;
    AwInputCompRegValue registration_offset;
  
    channel = read_int(ARG_MANDATORY, "channel not specified");
  
    try {
      registration_offset = j2k_object.AwJ2kGetInputCompRegInfo(channel);
      diagnostic_stream.println("Channel " + channel +
                                " registration offset from origin: X:" +
                                registration_offset.getXRegistration() +
                                "/65536 Y:" +
                                registration_offset.getYRegistration() +
                                "/65536");
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_input_j2k_component_registration()
  {
    System.out.print("--get-input-j2k-component-registration <channel index>\n" +
                     "Returns a specified channel's registration offset.  The registration offsets\n" +
                     "indicate how much to offset each color channel relative to the image grid for\n" +
                     "display.  The offsets are given in units of 1/65536 of a pixel.\n" +
                     "");
  }

  public void call__get_component_registration()
  {
    call__get_input_j2k_component_registration();
  }

  public void help__get_component_registration()
  {
    help__get_input_j2k_component_registration();
  }

  public void call__get_input_j2k_bytes_read()
  {
    AwInputBytesReadInfoValue bytes;
    try {
      bytes = j2k_object.AwJ2kGetInputBytesReadInfo();
      diagnostic_stream.println("Decompression used up " +
                                bytes.getOutputNumBytesRead() + " bytes");
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_input_j2k_bytes_read()
  {
    System.out.print("--get-input-j2k-bytes-read \n" +
                     "Prints the number of bytes actually used from a JPEG 2000 image.\n" +
                     "If the full image was decompressed, this will return the size of\n" +
                     "the original image.  If a partial decompression was performed\n" +
                     "(e.g. only a single tile or a reduced resolution was decoded) then\n" +
                     "this number may be smaller than the full image.\n" +
                     "");
  }

  public void call__get_bytecount()
  {
    call__get_input_j2k_bytes_read();
  }

  public void help__get_bytecount()
  {
    help__get_input_j2k_bytes_read();
  }

  public void call__set_input_j2k_progression_level()
  {
    int progression_level;
  
    progression_level =
      read_int(ARG_MANDATORY, "Progression level not specified");
  
    try {
      j2k_object.AwJ2kSetInputJ2kProgLevel(progression_level);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_input_j2k_progression_level()
  {
    System.out.print("--set-input-j2k-progression-level <progression level>\n" +
                     "Sets the number of progression levels that will be decoded form the\n" +
                     "JPEG 2000 image.  The progression type is determined by the\n" +
                     "progression order of the image.\n" +
                     "");
  }

  public void call_pl()
  {
    call__set_input_j2k_progression_level();
  }

  public void help_pl()
  {
    help__set_input_j2k_progression_level();
  }

  public void call__progression_level()
  {
    call__set_input_j2k_progression_level();
  }

  public void help__progression_level()
  {
    help__set_input_j2k_progression_level();
  }

  public void call__set_input_j2k_resolution_level()
  {
    int resolution_level;
    boolean full_transform;
  
    resolution_level = read_int(ARG_MANDATORY,
                                "Resolution level not specified");
  
    full_transform = read_boolean(ARG_OPTIONAL, null, false);
  
    try {
      j2k_object.AwJ2kSetInputJ2kResLevel(resolution_level,
                                          (full_transform ? 1 : 0));
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_input_j2k_resolution_level()
  {
    System.out.print("--set-input-j2k-resolution-level <resolution level> [<full transform flag>]\n" +
                     "Sets the number of resolution levels to decode from the JPEG 2000\n" +
                     "image.  The full number of resolution levels is always one more\n" +
                     "than the number of wavelet transform levels in the JPEG 2000 image.\n" +
                     "To fully decode the image, set the resolution level to 1.  For quarter\n" +
                     "resolution, use 2.  The optional full transform flag, which should be 'Yes'\n" +
                     "or 'No', indicates whether the full wavelet transform should be performed\n" +
                     "(resulting in a full size image of lower quality) or not (resulting in a\n" +
                     "reduced size image).\n" +
                     "");
  }

  public void call_rl()
  {
    call__set_input_j2k_resolution_level();
  }

  public void help_rl()
  {
    help__set_input_j2k_resolution_level();
  }

  public void call__resolution_level()
  {
    call__set_input_j2k_resolution_level();
  }

  public void help__resolution_level()
  {
    help__set_input_j2k_resolution_level();
  }


  public void call__set_input_j2k_quality_level()
  {
    int quality_level =
      read_int(ARG_MANDATORY, "Quality level not specified");
  
    try {
      j2k_object.AwJ2kSetInputJ2kQualLevel(quality_level);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_j2k_quality_level()
  {
    System.out.print("--set-input-j2k-quality-level <quality level>\n" +
                     "Sets the number of quality layers to decode from a JPEG 2000 image.\n" +
                     "Setting this value to 1 decodes all the quality layers; setting it to 2\n" +
                     "drops one layer.\n" +
                     "");
  }

  public void call_ql()
  {
    call__set_input_j2k_quality_level();
  }

  public void help_ql()
  {
    help__set_input_j2k_quality_level();
  }

  public void call__quality_level()
  {
    call__set_input_j2k_quality_level();
  }

  public void help__quality_level()
  {
    help__set_input_j2k_quality_level();
  }



  public void call__set_input_j2k_color_level()
  {
    int color_level, color_transform_flag;
    Object color_transform_object;
  
    color_level = read_int(ARG_MANDATORY, "Color level not specified");
  
    color_transform_object =
      read_int_or_string(
        ARG_OPTIONAL, null,
        (Object)new Integer(AwJ2kParameters.AW_J2K_CT_DEFAULT));
  
    if (color_transform_object == null)
      color_transform_flag = AwJ2kParameters.AW_J2K_CT_DEFAULT;
    else if (color_transform_object instanceof Integer) {
      color_transform_flag = ((Integer)color_transform_object).intValue();
    }
    else if (color_transform_object instanceof String) {
      switch (((String)color_transform_object).charAt(0)) {
      case 'y': case 'Y':
        color_transform_flag = AwJ2kParameters.AW_J2K_CT_PERFORM;
        break;
      case 'n': case 'N':
        color_transform_flag = AwJ2kParameters.AW_J2K_CT_SKIP;
        break;
      default:
        color_transform_flag = AwJ2kParameters.AW_J2K_CT_DEFAULT;
      }
    }
    else
      color_transform_flag = AwJ2kParameters.AW_J2K_CT_DEFAULT;
  
    try {
      j2k_object.AwJ2kSetInputJ2kColorLevel(color_level,
                                            color_transform_flag);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_input_j2k_color_level()
  {
    System.out.print("--set-input-j2k-color-level <color level> [<color transform flag>]\n" +
                     "Sets the number of color channels to decode from a JPEG 2000 image.\n" +
                     "Setting <color level> to 1 decodes all the color channels.  Setting it to 2\n" +
                     "drops the last color channel.  The optional <color transform flag> indicates\n" +
                     "whether the color transform will be performed or not.  Use 'yes' to force the\n" +
                     "transform to be performed if possible; 'no' to disallow the color transform;\n" +
                     "and 'default' to let the transform be performed if so specified by the image.\n" +
                     "");
  }

  public void call_cl()
  {
    call__set_input_j2k_color_level();
  }

  public void help_cl()
  {
    help__set_input_j2k_color_level();
  }

  public void call__color_level()
  {
    call__set_input_j2k_color_level();
  }

  public void help__color_level()
  {
    help__set_input_j2k_color_level();
  }


  public void call__set_input_j2k_region_level()
  {
    int x0, x1, y0, y1;
  
    x0 = read_int(ARG_MANDATORY, "Left coordinate of region not specified");
    y0 = read_int(ARG_MANDATORY, "Top coordinate of region not specified");
    x1 = read_int(ARG_MANDATORY, "Right coordinate of region not specified");
    y1 = read_int(ARG_MANDATORY, "Bottom coordinate of region not specified");
  
    try {
      j2k_object.AwJ2kSetInputJ2kRegionLevel(x0, y0, x1, y1);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_j2k_region_level()
  {
    System.out.print("--set-input-j2k-region-level <left> <top> <right> <bottom>\n" +
                     "Defines a rectangular subregion to be decoded from a JPEG 2000\n" +
                     "image.  Only those precincts that intersect with the defined region will be\n" +
                     "decoded.  Precincts are set by calling  --set-output-j2k-channel-precinct-size\n" +
                     "");
  }

  public void call_wl()
  {
    call__set_input_j2k_region_level();
  }

  public void help_wl()
  {
    help__set_input_j2k_region_level();
  }

  public void call__decode_region()
  {
    call__set_input_j2k_region_level();
  }

  public void help__decode_region()
  {
    help__set_input_j2k_region_level();
  }


  public void call__set_input_j2k_selected_channel()
  {
    int channel;
  
    channel = read_int(ARG_MANDATORY, "Selected Channel not specified");
  
    try {
      j2k_object.AwJ2kSetInputJ2kSelectedChannel(channel);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_j2k_selected_channel()
  {
    System.out.print("--set-input-j2k-selected-channel <channel index>\n" +
                     "Selects a specific single color channel to decode from a JPEG 2000\n" +
                     "image.  The color channels are indexed starting at 0.  Any color\n" +
                     "rotations specified in the JPEG 2000 image will not be performed on\n" +
                     "this channel.\n" +
                     "");
  }

  public void call_sc()
  {
    call__set_input_j2k_selected_channel();
  }

  public void help_sc()
  {
    help__set_input_j2k_selected_channel();
  }

  public void call__selected_channel()
  {
    call__set_input_j2k_selected_channel();
  }

  public void help__selected_channel()
  {
    help__set_input_j2k_selected_channel();
  }


  public void call__set_input_j2k_selected_tile()
  {
    int tile;
  
    tile = read_int(ARG_MANDATORY, "Selected tile not specified");
  
    try {
      j2k_object.AwJ2kSetInputJ2kSelectedTile(tile);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_input_j2k_selected_tile()
  {
    System.out.print("--set-input-j2k-selected-tile <tile index>\n" +
                     "Selects a specific single tile to decode from a JPEG 2000 image.\n" +
                     "");
  }

  public void call_sl()
  {
    call__set_input_j2k_selected_tile();
  }

  public void help_sl()
  {
    help__set_input_j2k_selected_tile();
  }

  public void call__selected_tile()
  {
    call__set_input_j2k_selected_tile();
  }

  public void help__selected_tile()
  {
    help__set_input_j2k_selected_tile();
  }


  public void call__set_input_j2k_mct_resolution_level()
  {
    int resolution_level;
    boolean full_transform;
  
    resolution_level = read_int(ARG_MANDATORY,
                                "Resolution level not specified");
  
    full_transform = read_boolean(ARG_OPTIONAL, null, false);
  
    try {
      j2k_object.AwJ2kSetInputJ2kMCTResolutionLevel(resolution_level,
                                                    (full_transform ? 1 : 0));
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_input_j2k_mct_resolution_level()
  {
    System.out.print("--set-input-j2k-mct-resolution-level <resolution level> [<full transform flag>]\n" +
                     "Sets the number of multi-component resolution levels to decode from \n" +
                     "Part 2 MCT JPEG 2000 image.  The full number of resolution levels \n" +
                     "is always one more than the number of wavelet transform levels in \n" +
                     "the JPEG 2000 image.  \n" +
                     "To fully decode all channels in the image, set the resolution level to 1.\n" +
                     "For quarter resolution, use 2. \n" +
                     "The full_xform_flag indicates whether the full wavelet transform \n" +
                     "should be performed (resulting in a complete number of components of lower \n" +
                     "quality) or not (resulting in a reduced number of components). \n" +
                     "");
  }

  public void call_mct_rl()
  {
    call__set_input_j2k_mct_resolution_level();
  }

  public void help_mct_rl()
  {
    help__set_input_j2k_mct_resolution_level();
  }

  public void call__mct_resolution_level()
  {
    call__set_input_j2k_mct_resolution_level();
  }

  public void help__mct_resolution_level()
  {
    help__set_input_j2k_mct_resolution_level();
  }


  public void call__set_input_dcm_frame_index()
  {
    int frame_index;
    
    frame_index = read_int(ARG_MANDATORY,
                           "Selected frame index not specified"); 
    
    try {
      j2k_object.AwJ2kSetInputDcmFrameIndex(frame_index);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
  
    return;
  }
  public void help__set_input_dcm_frame_index()
  {
    System.out.print("--set-input-dcm-frame-index <frame index>\n" +
                     "Selects a specific single frame to decode from a DICOM image.\n" +
                     "");
  }

  public void call__input_reset_options()
  {
    try {
      j2k_object.AwJ2kInputResetOptions();
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__input_reset_options()
  {
    System.out.print("--input-reset-options \n" +
                     "Resets all the input options to their default values.\n" +
                     "");
  }

  public void call__set_output_type()
  {
    int image_type;

    image_type = read_type(ARG_MANDATORY, "Output image type not specified");

    try {
      j2k_object.AwJ2kSetOutputType(image_type);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_type()
  {
    System.out.print("--set-output-type <output type>\n" +
                     "Selects the type for the output image.  The output type is one of:\n" +
                     "  j2k                - JPEG2000 codestreams\n" +
                     "  jp2                - JPEG2000 file format\n" +
                     "  tif, tiff          - TIFF\n" +
                     "  pnm, pbm, pgm, ppm - Any of the portable bit/gray/pix-map formats\n" +
                     "  dcm, dcm_raw       - DICOM (with embedded raw pixels)\n" +
                     "  dcm_j2k            - DICOM (with embedded J2K codestreams)\n" +
                     "  bmp                - Windows bitmap\n" +
                     "  tga, targa         - TARGA image format\n" +
                     "  jpg, jpeg          - Original JPEG format\n" +
                     "  pgx                - Extended portable graymap format\n" +
                     "  pdf                - JPEG2000 file format embedded inside PDF\n" +
                     "  raw                - Unformatted raw data\n" +
                     "");
  }

  public void call_t()
  {
    call__set_output_type();
  }

  public void help_t()
  {
    help__set_output_type();
  }

  public void call__output_file_type()
  {
    call__set_output_type();
  }

  public void help__output_file_type()
  {
    help__set_output_type();
  }


  public void call__get_output_image()
  {
    double file_write_time, memory_write_time, memory_write_time_temp;
    String image_name =
      read_string(ARG_MANDATORY, "Output image file name not specified");
  
    try {
      int iteration;

      memory_write_time = get_precise_time();
      AwOutputImageValue image = j2k_object.AwJ2kGetOutputImage();
      memory_write_time = get_precise_time() - memory_write_time;
  
      if (benchmark_flag > 0) {
        /* discard first memory benchmark, and time the call in a loop */
        memory_write_time = 0;
        for (iteration = 0; iteration < benchmark_flag; iteration++) {
          image = null;
          memory_write_time_temp = get_precise_time();
          image = j2k_object.AwJ2kGetOutputImage();
          memory_write_time += get_precise_time() - memory_write_time_temp;
        }
        memory_write_time /= (double)benchmark_flag;
      }
      file_write_time = get_precise_time();
      write_raw_data(image_name, image.getImage(), image.getImageLength());
      file_write_time = get_precise_time() - file_write_time;
      if (verbosity_flag > VERBOSITY_MINIMUM_LEVEL)
        diagnostic_stream.printf(
          "Memory-to-memory processing in %.2f seconds\n"+
          "File-to-file in %.2f seconds\n",
          memory_read_time + memory_write_time,
          memory_read_time + memory_write_time +
          file_read_time + file_write_time);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__get_output_image()
  {
    System.out.print("--get-output-image <output image name>\n" +
                     "Writes a new image to <output image name> using the memory-buffer interface.\n" +
                     "The output image type must have been specified using --set-output-type\n" +
                     "");
  }

  public void call_o()
  {
    call__get_output_image();
  }

  public void help_o()
  {
    help__get_output_image();
  }

  public void call__output_file_name()
  {
    call__get_output_image();
  }

  public void help__output_file_name()
  {
    help__get_output_image();
  }


  public void call__get_output_image_type()
  {
    int image_type;
    double file_write_time, memory_write_time, memory_write_time_temp;
    String image_name;

    image_type = read_type(ARG_MANDATORY, "Output image type not specified");
    image_name = read_string(ARG_MANDATORY,
                             "Output image file name not specified");
  
    try {
      int iteration;

      memory_write_time = get_precise_time();
      AwOutputImageValue image = j2k_object.AwJ2kGetOutputImageType(image_type);
      memory_write_time = get_precise_time() - memory_write_time;
  
      if (benchmark_flag > 0) {
        /* discard first memory benchmark, and time the call in a loop */
        memory_write_time = 0;
        for (iteration = 0; iteration < benchmark_flag; iteration++) {
          image = null;
          memory_write_time_temp = get_precise_time();
          image = j2k_object.AwJ2kGetOutputImage();
          memory_write_time += get_precise_time() - memory_write_time_temp;
        }
        memory_write_time /= (double)benchmark_flag;
      }
      file_write_time = get_precise_time();
      write_raw_data(image_name, image.getImage(), image.getImageLength());
      file_write_time = get_precise_time() - file_write_time;
      if (verbosity_flag > VERBOSITY_MINIMUM_LEVEL)
        diagnostic_stream.printf(
          "Memory-to-memory processing in %.2f seconds\n"+
          "File-to-file in %.2f seconds\n",
          memory_read_time + memory_write_time,
          memory_read_time + memory_write_time +
          file_read_time + file_write_time);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__get_output_image_type()
  {
    System.out.print("--get-output-image-type <output type> <output image name>\n" +
                     "Writes a new image to <output image name> using the memory-buffer interface.\n" +
                     "The output type is one of:\n" +
                     "  j2k                - JPEG2000 codestreams\n" +
                     "  jp2                - JPEG2000 file format\n" +
                     "  tif, tiff          - TIFF\n" +
                     "  pnm, pbm, pgm, ppm - Any of the portable bit/gray/pix-map formats\n" +
                     "  dcm, dcm_raw       - DICOM (with embedded raw pixels)\n" +
                     "  dcm_j2k            - DICOM (with embedded J2K codestreams)\n" +
                     "  bmp                - Windows bitmap\n" +
                     "  tga, targa         - TARGA image format\n" +
                     "  jpg, jpeg          - Original JPEG format\n" +
                     "  pgx                - Extended portable graymap format\n" +
                     "  pdf                - JPEG2000 file format embedded inside PDF\n" +
                     "  raw                - Unformatted raw data\n" +
                     "");
  }

  public void call__get_output_image_raw()
  {
    int iteration;
    String image_name;
    AwOutputImageRawValue image;

    double file_write_time, memory_write_time, memory_write_time_temp;
    boolean interleaved;
  
    image_name = read_string(ARG_MANDATORY,
                             "Output image file name not specified");
  
    interleaved = read_boolean(ARG_OPTIONAL, null, false);
  
    try {
      memory_write_time = get_precise_time();
      image = j2k_object.AwJ2kGetOutputImageRaw(interleaved);
      memory_write_time = get_precise_time() - memory_write_time;

      if (benchmark_flag > 0) {
        /* discard first memory benchmark, and time the call in a loop */
        memory_write_time = 0.0F;
        for (iteration = 0; iteration < benchmark_flag; iteration++) {
          image = null;
          memory_write_time_temp = get_precise_time();
          image = j2k_object.AwJ2kGetOutputImageRaw(interleaved);
          memory_write_time += get_precise_time() - memory_write_time_temp;
        }
        memory_write_time /= (double)benchmark_flag;
      }
  
      file_write_time = get_precise_time();
      write_raw_data(image_name, image.getImage(), image.getImageLength());
      file_write_time = get_precise_time() - file_write_time;

      if (verbosity_flag > VERBOSITY_MINIMUM_LEVEL) {
        diagnostic_stream.printf(
          "Memory-to-memory processing in %.2f seconds\n" +
          "File-to-file in %.2f seconds\n",
          memory_read_time + memory_write_time,
          memory_read_time + memory_write_time +
          file_read_time + file_write_time);
        diagnostic_stream.printf(
          "Output file information:\n" +
          "   %d bytes\n" +
          "   %d rows\n" +
          "   %d columns\n" +
          "   %d channels\n" +
          "   %d total bit depth\n",
          image.getImageLength(), image.getNumRows(), image.getNumCols(),
          image.getNumChannels(), image.getNumBitsPerPixel());
      }
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_output_image_raw()
  {
    System.out.print("--get-output-image-raw <output image name> [<interleaved>]\n" +
                     "Writes a new raw image to <output image name> using the memory-buffer\n" +
                     "interface.  The size of the image will be printed if verbose operation was\n" +
                     "selected.  The optional <interleaved> flag, which may be `yes' or `no',\n" +
                     "indicates whether the color channels should be interleaved or not.\n" +
                     "");
  }

  public void call__get_output_image_raw_ex()
  {
    int iteration;
    String image_name;
    AwOutputImageRawValueEx image;

    double file_write_time, memory_write_time, memory_write_time_temp;
    boolean interleaved;
    int bits_allocated;
  
    image_name = read_string(ARG_MANDATORY,
                             "Output image file name not specified");

    bits_allocated = read_int(ARG_OPTIONAL, null, 0);
  
    interleaved = read_boolean(ARG_OPTIONAL, null, false);
  
    try {
      memory_write_time = get_precise_time();
      image = j2k_object.AwJ2kGetOutputImageRawEx(bits_allocated, interleaved);
      memory_write_time = get_precise_time() - memory_write_time;

      if (benchmark_flag > 0) {
        /* discard first memory benchmark, and time the call in a loop */
        memory_write_time = 0.0F;
        for (iteration = 0; iteration < benchmark_flag; iteration++) {
          image = null;
          memory_write_time_temp = get_precise_time();
          image = j2k_object.AwJ2kGetOutputImageRawEx(bits_allocated,
                                                      interleaved);
          memory_write_time += get_precise_time() - memory_write_time_temp;
        }
        memory_write_time /= (double)benchmark_flag;
      }
  
      file_write_time = get_precise_time();
      write_raw_data(image_name, image.getImage(), image.getImageLength());
      file_write_time = get_precise_time() - file_write_time;

      if (verbosity_flag > VERBOSITY_MINIMUM_LEVEL) {
        diagnostic_stream.printf(
          "Memory-to-memory processing in %.2f seconds\n" +
          "File-to-file in %.2f seconds\n",
          memory_read_time + memory_write_time,
          memory_read_time + memory_write_time +
          file_read_time + file_write_time);
        diagnostic_stream.printf(
          "Output file information:\n" +
          "   %d bytes\n" +
          "   %d rows\n" +
          "   %d columns\n" +
          "   %d channels\n" +
          "   %d total bit depth\n",
          image.getImageLength(), image.getNumRows(), image.getNumCols(),
          image.getNumChannels(), image.getNumBitsPerPixelAllocated());
      }
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_output_image_raw_ex()
  {
    System.out.print("--get-output-image-raw-ex <output image name> [<bits allocated>] [<interleaved>]\n" +
                     "Writes a new raw image to <output image name> using the memory-buffer\n" +
                     "interface.  The size of the image will be printed if verbose operation was\n" +
                     "selected.  The optional <bits allocated> flag controls the padding of the\n" +
                     "pixel data.  The optional <interleaved> flag, which may be `yes' or `no',\n" +
                     "indicates whether the color channels should be interleaved or not.\n" +
                     "");
  }

  public void call__get_output_image_file()
  {
    int iteration;
    String image_name;
    double file_write_time, file_write_time_temp;
  
    image_name = read_string(ARG_MANDATORY,
                             "Output image file name not specified");
  
    try {
      file_write_time = get_precise_time();
      j2k_object.AwJ2kGetOutputImageFile(image_name);
      file_write_time = get_precise_time() - file_write_time;
  
      if (benchmark_flag > 0) {
        /* discard first memory benchmark, and time the call in a loop */
        file_write_time = 0;
        for (iteration = 0; iteration < benchmark_flag; iteration++) {
          file_write_time_temp = get_precise_time();
          j2k_object.AwJ2kGetOutputImageFile(image_name);
          file_write_time += get_precise_time() - file_write_time_temp;
        }
        file_write_time /= (double)benchmark_flag;
      }
  
      if (verbosity_flag > VERBOSITY_MINIMUM_LEVEL) {
        diagnostic_stream.printf(
          "Memory-to-memory processing in %.2f seconds\n" +
          "File-to-file in %.2f seconds\n",
          memory_read_time,
          memory_read_time + file_read_time + file_write_time);
      }
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_output_image_file()
  {
    System.out.print("--get-output-image-file <output image name>\n" +
                     "Writes a new image to <output image name> using the file interface.\n" +
                     "The output image type must have been specified using --set-output-type\n" +
                     "");
  }

  public void call__get_output_image_file_type()
  {
    int image_type, iteration;
    String image_name;
    double file_write_time, file_write_time_temp;
  
    image_name = read_string(ARG_MANDATORY,
                             "Output image file name not specified");
  
    image_type = read_type(ARG_MANDATORY, "Output image type not specified");
  
    try {
      file_write_time = get_precise_time();
      j2k_object.AwJ2kGetOutputImageFileType(image_name, image_type);
      file_write_time = get_precise_time() - file_write_time;
  
      if (benchmark_flag > 0) {
        /* discard first memory benchmark, and time the call in a loop */
        file_write_time = 0;
        for (iteration = 0; iteration < benchmark_flag; iteration++) {
          file_write_time_temp = get_precise_time();
          j2k_object.AwJ2kGetOutputImageFileType(image_name, image_type);
          file_write_time += get_precise_time() - file_write_time_temp;
        }
        file_write_time /= (double)benchmark_flag;
      }
  
      if (verbosity_flag > VERBOSITY_MINIMUM_LEVEL) {
        diagnostic_stream.printf(
          "Memory-to-memory processing in %.2f seconds\n" +
          "File-to-file in %.2f seconds\n",
          memory_read_time,
          memory_read_time + file_read_time + file_write_time);
      }
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_output_image_file_type()
  {
    System.out.print("--get-output-image-file-type <output type> <output image name>\n" +
                     "Writes a new image to <output image name> using the file interface.\n" +
                     "The output type is one of:\n" +
                     "  j2k                - JPEG2000 codestreams\n" +
                     "  jp2                - JPEG2000 file format\n" +
                     "  tif, tiff          - TIFF\n" +
                     "  pnm, pbm, pgm, ppm - Any of the portable bit/gray/pix-map formats\n" +
                     "  dcm, dcm_raw       - DICOM (with embedded raw pixels)\n" +
                     "  dcm_j2k            - DICOM (with embedded J2K codestreams)\n" +
                     "  bmp                - Windows bitmap\n" +
                     "  tga, targa         - TARGA image format\n" +
                     "  jpg, jpeg          - Original JPEG format\n" +
                     "  pgx                - Extended portable graymap format\n" +
                     "  pdf                - JPEG2000 file format embedded inside PDF\n" +
                     "  raw                - Unformatted raw data\n" +
                     "");
  }

  public void call__get_output_image_file_raw()
  {
    int iteration;
    String image_name;
    int rows, columns, channels, bit_depth;
    double file_write_time, file_write_time_temp;
    boolean interleaved;
    AwOutputImageFileRawValue image;
  
    image_name = read_string(ARG_MANDATORY,
                             "Output image file name not specified");
  
    interleaved = read_boolean(ARG_OPTIONAL, null, false);
  
    try {
      file_write_time = get_precise_time();
      image = j2k_object.AwJ2kGetOutputImageFileRaw(image_name, interleaved);
      file_write_time = get_precise_time() - file_write_time;
  
      if (benchmark_flag > 0) {
        /* discard first memory benchmark, and time the call in a loop */
        file_write_time = 0;
        for (iteration = 0; iteration < benchmark_flag; iteration++) {
          file_write_time_temp = get_precise_time();
          image =
            j2k_object.AwJ2kGetOutputImageFileRaw(image_name, interleaved);
          file_write_time += get_precise_time() - file_write_time_temp;
        }
        file_write_time /= (double)benchmark_flag;
      }
  
      if (verbosity_flag > VERBOSITY_MINIMUM_LEVEL) {
        diagnostic_stream.printf(
          "Memory-to-memory processing in %.2f seconds\n" +
          "File-to-file in %.2f seconds\n",
          memory_read_time,
          memory_read_time + file_read_time + file_write_time);
        diagnostic_stream.printf(
          "Output file information:\n" +
          "   %d rows\n"               +
          "   %d columns\n"            +
          "   %d channels\n"           +
          "   %d total bit depth\n",
          image.getNumRows(), image.getNumCols(), image.getNumChannels(),
          image.getNumBitsPerPixel());
      }
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_output_image_file_raw()
  {
    System.out.print("--get-output-image-file-raw <output image name> [<interleaved>]\n" +
                     "Writes a new raw image to <output image name> using the file\n" +
                     "interface.  The size of the image will be printed if verbose operation was\n" +
                     "selected.  The optional <interleaved> flag, which may be `yes' or `no',\n" +
                     "indicates whether the color channels should be interleaved or not.\n" +
                     "");
  }

  private class J2kdriverImageCallback extends AwJ2kImageCallback {
    private String file_name_prefix;
    private String file_name_suffix;
    private int part;
    private j2kdriver driver_instance;
    public J2kdriverImageCallback(j2kdriver driver_instance,
                                  String file_name_prefix,
                                  String file_name_suffix)
    {
      this.file_name_prefix = file_name_prefix;
      this.file_name_suffix = file_name_suffix;
      this.driver_instance = driver_instance;
      part = 0;
    }
    public void ImageCallback(byte[] outputImageBuffer)
    {
      String new_name =
        new String(file_name_prefix + "." + part + "." + file_name_suffix);
      part++;
      driver_instance.write_raw_data(new_name, outputImageBuffer,
                                     outputImageBuffer.length);
    }
  }

  public void call__get_output_image_by_callback()
  {
    double file_write_time;
    String image_name;
    J2kdriverImageCallback callback;

    image_name = read_string(ARG_MANDATORY,
                             "Output image file name not specified");
  
    callback = new J2kdriverImageCallback(this, image_name, "j2k");
    try {
      file_write_time = get_precise_time();
      j2k_object.AwJ2kGetOutputImageByCallback(callback);
      file_write_time = get_precise_time() - file_write_time;
  
      if (verbosity_flag > VERBOSITY_MINIMUM_LEVEL)
        diagnostic_stream.printf(
          "Memory-to-memory processing in %.2f seconds\n" +
          "File-to-file in %.2f seconds\n",
          memory_read_time,
          memory_read_time + file_read_time + file_write_time);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_output_image_by_callback()
  {
    System.out.print("--get-output-image-by-callback <output image name>\n" +
                     "Writes a new image to <output image name> using the callback\n" +
                     "interface.  Data will be written to the output file as it becomes available, in tileparts.\n" +
                     "");
  }

  public void call_oprog()
  {
    call__get_output_image_by_callback();
  }

  public void help_oprog()
  {
    help__get_output_image_by_callback();
  }

  public void call__get_output_image_j2k_tile_part()
  {
    String image_name;
    AwOutputImageJ2kTilePartValue image;
    double file_write_time, memory_write_time;
  
    image_name = read_string(ARG_MANDATORY,
                             "Output image file name not specified");

    try {
      memory_write_time = get_precise_time();
      image = j2k_object.AwJ2kGetOutputImageJ2kTilePart();
      memory_write_time = get_precise_time() - memory_write_time;
  
      file_write_time = get_precise_time();
      write_raw_data(image_name, image.getImage(), image.getImageLength());
      file_write_time = get_precise_time() - file_write_time;
      if (verbosity_flag > VERBOSITY_MINIMUM_LEVEL) {
        diagnostic_stream.printf(
          "Memory-to-memory processing in %.2f seconds\n" +
          "File-to-file in %.2f seconds\n",
          memory_read_time + memory_write_time,
          memory_read_time + memory_write_time + file_read_time +
          file_write_time);
      }
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_output_image_j2k_tile_part()
  {
    System.out.print("--get-output-image-j2k-tile-part <tilepart name>\n" +
                     "Writes a new JPEG 2000 tilepart to <tilepart name> using the memory buffer interface\n" +
                     "");
  }

  public void call_otp()
  {
    call__get_output_image_j2k_tile_part();
  }

  public void help_otp()
  {
    help__get_output_image_j2k_tile_part();
  }

  public void call__set_output_memory_callback()
  {
    String dummy =
      read_string(ARG_MANDATORY,
                  "Memory allocation type was not specified");
    if (verbosity_flag > VERBOSITY_MINIMUM_LEVEL)
      diagnostic_stream.println("--set-output-memory-callback is maintained for compatibility with j2kdriver.c");
  }
  public void help__set_output_memory_callback()
  {
    System.out.print("--set-output-memory-callback <allocation scheme>\n" +
                     "Sets which memory allocation function will be used to create the output image\n" +
                     "buffers.  The choices are `default' for the default library allocator,\n" +
                     "`system' for the system functions (malloc on Unix, HeapAlloc on Windows),\n" +
                     "and `custom' for a custom function specified in the code.");
    System.out.println("--set-output-memory-callback is maintained for compatibility with j2kdriver.c");
  }

  public void call__set_output_j2k_bitrate()
  {
    float bitrate;
  
    bitrate = read_float(ARG_MANDATORY, "Bitrate not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kBitrate(bitrate);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_bitrate()
  {
    System.out.print("--set-output-j2k-bitrate <bitrate>\n" +
                     "Sets the output image bitrate, in bits per pixel.  A bitrate of 0\n" +
                     "indicates that all the quantized data should be included in the\n" +
                     "image.  This creates lossless images if the R53 wavelet is chosen\n" +
                     "using --set-output-j2k-xform.\n" +
                     "");
  }

  public void call_B()
  {
    call__set_output_j2k_bitrate();
  }

  public void help_B()
  {
    help__set_output_j2k_bitrate();
  }

  public void call__bitrate()
  {
    call__set_output_j2k_bitrate();
  }

  public void help__bitrate()
  {
    help__set_output_j2k_bitrate();
  }

  public void call__set_output_j2k_ratio()
  {
    float ratio;
  
    ratio = read_float(ARG_MANDATORY, "Compression ratio not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kRatio(ratio);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_ratio()
  {
    System.out.print("--set-output-j2k-ratio <ratio>\n" +
                     "Sets the compression ratio for the output image.  A ratio of 0\n" +
                     "indicates that all the quantized data should be included in the\n" +
                     "image.  This creates lossless images if the R53 wavelet is chosen\n" +
                     "using --set-output-j2k-xform.\n" +
                     "");
  }

  public void call_R()
  {
    call__set_output_j2k_ratio();
  }

  public void help_R()
  {
    help__set_output_j2k_ratio();
  }

  public void call__ratio()
  {
    call__set_output_j2k_ratio();
  }

  public void help__ratio()
  {
    help__set_output_j2k_ratio();
  }


  public void call__set_output_j2k_filesize()
  {
    int retval;
    int bytes;
  
    bytes = read_int(ARG_MANDATORY, "File size not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kFileSize(bytes);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_filesize()
  {
    System.out.print("--set-output-j2k-filesize <file size>\n" +
                     "Sets the output image size, in bytes.\n" +
                     "");
  }

  public void call_F()
  {
    call__set_output_j2k_filesize();
  }

  public void help_F()
  {
    help__set_output_j2k_filesize();
  }

  public void call__file_size()
  {
    call__set_output_j2k_filesize();
  }

  public void help__file_size()
  {
    help__set_output_j2k_filesize();
  }


  public void call__set_output_j2k_psnr()
  {
    float psnr;
  
    psnr = read_float(ARG_MANDATORY, "pSNR value not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kPsnr(psnr);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_psnr()
  {
    System.out.print("--set-output-j2k-psnr <psnr>\n" +
                     "Sets the output image pSNR, in dB.\n" +
                     "");
  }

  public void call__set_output_j2k_rd_slope()
  {
    float rd_slope;
  
    rd_slope = read_float(ARG_MANDATORY,
                          "Rate/distortion slope not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kRDSlope(rd_slope);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_rd_slope()
  {
    System.out.print("--set-output-j2k-rd-slope <rd_slope>\n" +
                     "Sets the output image rate/distortion slope.\n" +
                     "");
  }

  public void call__rd_slope()
  {
    call__set_output_j2k_rd_slope();
  }

  public void help__rd_slope()
  {
    help__set_output_j2k_rd_slope();
  }

  
  public void call__set_output_j2k_color_xform()
  {
    int color_xform_flag;
    Object color_xform_object;
  
    color_xform_object =
      read_int_or_string(ARG_MANDATORY, "Color xform not specified");

    if (color_xform_object == null)
      color_xform_flag = AwJ2kParameters.AW_J2K_CT_DEFAULT;
    else if (color_xform_object instanceof Integer) {
      color_xform_flag = ((Integer)color_xform_object).intValue();
    }
    else if (color_xform_object instanceof String) {
      switch (((String)color_xform_object).charAt(0)) {
      case 'y': case 'Y':
        color_xform_flag = AwJ2kParameters.AW_J2K_CT_PERFORM;
        break;
      case 'n': case 'N':
        color_xform_flag = AwJ2kParameters.AW_J2K_CT_SKIP;
        break;
      default:
        color_xform_flag = AwJ2kParameters.AW_J2K_CT_DEFAULT;
      }
    }
    else
      color_xform_flag = AwJ2kParameters.AW_J2K_CT_DEFAULT;

    try {
      j2k_object.AwJ2kSetOutputJ2kColorXform(color_xform_flag);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_color_xform()
  {
    System.out.print("--set-output-j2k-color-xform <color transform flag>\n" +
                     "Sets whether the color transform will be performed.  The value of <color\n" +
                     "transform flag> should be `yes' to perform and `no' to skip the transform.\n" +
                     "The color transform can only be performed only if there are 3 or more\n" +
                     "channels and the first three channels have the same bit depth, data\n" +
                     "type (signed or unsigned), and subsampling.\n" +
                     "");
  }

  public void call__color_transform()
  {
    call__set_output_j2k_color_xform();
  }

  public void help__color_transform()
  {
    help__set_output_j2k_color_xform();
  }

  public void call__set_output_j2k_color_xform_ex()
  {
    int tile_index, color_xform_flag;
    Object color_xform_object;
  
    tile_index = read_tile();
  
    color_xform_object =
      read_int_or_string(ARG_MANDATORY, "Color xform not specified");

    if (color_xform_object == null)
      color_xform_flag = AwJ2kParameters.AW_J2K_CT_DEFAULT;
    else if (color_xform_object instanceof Integer) {
      color_xform_flag = ((Integer)color_xform_object).intValue();
    }
    else if (color_xform_object instanceof String) {
      switch (((String)color_xform_object).charAt(0)) {
      case 'y': case 'Y':
        color_xform_flag = AwJ2kParameters.AW_J2K_CT_PERFORM;
        break;
      case 'n': case 'N':
        color_xform_flag = AwJ2kParameters.AW_J2K_CT_SKIP;
        break;
      default:
        color_xform_flag = AwJ2kParameters.AW_J2K_CT_DEFAULT;
      }
    }
    else
      color_xform_flag = AwJ2kParameters.AW_J2K_CT_DEFAULT;

    try {
      j2k_object.AwJ2kSetOutputJ2kColorXform(tile_index, color_xform_flag);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_color_xform_ex()
  {
    System.out.print("--set-output-j2k-color-xform-ex <tile index> <color transform flag>\n" +
                     "Sets whether the color transform will be performed in tile <tile index>.  The\n" +
                     "value of <color transform flag> should be `yes' to perform and `no' to skip\n" +
                     "the transform.  The color transform can only be performed only if there are 3\n" +
                     "or more channels and the first three channels have the same bit depth, data\n" +
                     "type (signed or unsigned), and subsampling.\n" +
                     "");
  }

  public void call__set_output_j2k_progression_order()
  {
    int progression_order;
    Object progression_order_object;
  
    progression_order_object =
      read_int_or_string(ARG_MANDATORY, "Color transform not specified");
  
    if (progression_order_object == null)
      progression_order = AwJ2kParameters.AW_J2K_PO_DEFAULT;
    else if (progression_order_object instanceof Integer) {
      progression_order = ((Integer)progression_order_object).intValue();
    }
    else if (progression_order_object instanceof String) {
      String progression_order_string =
        ((String)progression_order_object).toLowerCase();

      if (progression_order_string.equals("lrcp"))
        progression_order = AwJ2kParameters.AW_J2K_PO_LAYER_RESOLUTION_COMPONENT_POSITION;
      else if (progression_order_string.equals("rlcp"))
        progression_order = AwJ2kParameters.AW_J2K_PO_RESOLUTION_LAYER_COMPONENT_POSITION;
      else if (progression_order_string.equals("rpcl"))
        progression_order = AwJ2kParameters.AW_J2K_PO_RESOLUTION_POSITION_COMPONENT_LAYER;
      else if (progression_order_string.equals("pcrl"))
        progression_order = AwJ2kParameters.AW_J2K_PO_POSITION_COMPONENT_RESOLUTION_LAYER;
      else if (progression_order_string.equals("cprl"))
        progression_order = AwJ2kParameters.AW_J2K_PO_COMPONENT_POSITION_RESOLUTION_LAYER;
      else {
        diagnostic_stream.println("Warning: unrecognized progression order `" +
                                  progression_order_string +
                                  "'; using default");
        progression_order = AwJ2kParameters.AW_J2K_PO_DEFAULT;
      }
    }
    else
      progression_order = AwJ2kParameters.AW_J2K_PO_DEFAULT;
  
    try {
      j2k_object.AwJ2kSetOutputJ2kProgOrder(progression_order);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_progression_order()
  {
    System.out.print("--set-output-j2k-progression-order <progression order>\n" +
                     "Sets the progression order of the compressed image file.  The value of\n" +
                     "<progression order> is one of the following:\n" +
                     "\n" +
                     "lrcp - Layer, Resolution, Component, Position\n" +
                     "rlcp - Resolution, Layer, Component, Position\n" +
                     "rpcl - Resolution, Position, Component, Layer\n" +
                     "pcrl - Position, Component, Resolution, Layer\n" +
                     "cprl - Component, Position, Resolution, Layer\n" +
                     "");
  }

  public void call_p()
  {
    call__set_output_j2k_progression_order();
  }

  public void help_p()
  {
    help__set_output_j2k_progression_order();
  }

  public void call__progression_order()
  {
    call__set_output_j2k_progression_order();
  }

  public void help__progression_order()
  {
    help__set_output_j2k_progression_order();
  }

  public void call__set_output_j2k_tile_size()
  {
    int width, height;
  
    width = read_int(ARG_MANDATORY, "Tile width not specified");
    height = read_int(ARG_MANDATORY, "Tile height not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kTileSize(width, height);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_tile_size()
  {
    System.out.print("--set-output-j2k-tile-size <tile width> <tile height>\n" +
                     "Sets the tile size for JPEG 2000 output.  All tiles, except those\n" +
                     "at the edges of the image, will be of this size.\n" +
                     "");
  }

  public void call__tile_size()
  {
    call__set_output_j2k_tile_size();
  }

  public void help__tile_size()
  {
    help__set_output_j2k_tile_size();
  }

  public void call__set_output_j2k_add_comment()
  {
    byte[] data;
    String file_name, comment_string, type_string, location_string;
    int type, location, need_to_free_data;
    int length;
  
    comment_string = null;

    if (argv[arg].equals("--add-comment-from-file")) {
      file_name = read_string(ARG_MANDATORY,
                              "Comment file name not specified");
      data = load_raw_data(file_name);
  
      if (data == null || data.length == 0) {
        if (file_name.charAt(0) == '-' && file_name.charAt(1) == '\0')
          System.err.println("Error: unable to read comment from stdin");
        else
          System.err.println("Error: unable to read comment from `" +
                             file_name + "'");
        return;
      }
  
      try {
        comment_string = new String(data, 0, data.length, "US-ASCII");
      }
      catch (java.io.UnsupportedEncodingException uee) {
        uee.printStackTrace(diagnostic_stream);
      }
      type = AwJ2kParameters.AW_J2K_CO_BINARY;
    }
    else {
      comment_string = read_string(ARG_MANDATORY, "Comment not specified");
      type = AwJ2kParameters.AW_J2K_CO_ISO_8859;
    }
  
    type_string = read_string(ARG_OPTIONAL, null);
    type = AwJ2kParameters.AW_J2K_CO_ISO_8859;
    if (type_string != null) {
      switch (type_string.charAt(0)) {
      case 'b': case 'B':
        type = AwJ2kParameters.AW_J2K_CO_BINARY;
        break;
      default:
        type = AwJ2kParameters.AW_J2K_CO_ISO_8859;
      }
    }
  
    location = AwJ2kParameters.AW_J2K_CO_LOCATION_MAIN_HEADER;
    location_string = read_string(ARG_OPTIONAL, null);
    if (location_string != null) {
      if (Character.isDigit(location_string.charAt(0))) {
        location = Integer.parseInt(location_string);
      }
      else {
        location = AwJ2kParameters.AW_J2K_CO_LOCATION_MAIN_HEADER;
      }
    }
  
    try {
      j2k_object.AwJ2kSetOutputJ2kAddComment(comment_string, type,
                                             comment_string.length(),
                                             location);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_add_comment()
  {
    System.out.print("--set-output-j2k-add-comment <comment string> [<comment type> [<comment location>]]\n" +
                     "Adds a comment to the JPEG 2000 image.  The value of <comment string> is used\n" +
                     "verbatim for the comment.  The optional <comment type> flag, whose values may\n" +
                     "be `binary' or `text', denotes whether the comment is binary data or Latin-1\n" +
                     "(ISO-8859-15) text.  Text is the default type.  The optional <comment\n" +
                     "location> field may be `main' to denote that the comment will be stored in the\n" +
                     "main header, or an index to denote that the comment will be stored in the\n" +
                     "header of the indexed tile.  The default location is the main header.\n" +
                     "");
  }

  public void call__add_comment()
  {
    call__set_output_j2k_add_comment();
  }

  public void help__add_comment()
  {
    help__set_output_j2k_add_comment();
  }
  public void call__add_comment_from_file()
  {
    call__set_output_j2k_add_comment();
  }

  public void help__add_comment_from_file()
  {
    help__set_output_j2k_add_comment();
  }


  public void call__set_output_j2k_image_offset()
  {
    int x_offset, y_offset;
  
    x_offset = read_int(ARG_MANDATORY,
                        "Image horizontal offset not specified");
    y_offset = read_int(ARG_MANDATORY,
                        "Image Vertical offset not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kImageOffset(x_offset, y_offset);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_image_offset()
  {
    System.out.print("--set-output-j2k-image-offset <x offset> <y offset>\n" +
                     "Offsets the image boundary from the top-left corner of the image\n" +
                     "grid, thereby cropping the image.\n" +
                     "");
  }

  public void call__image_offset()
  {
    call__set_output_j2k_image_offset();
  }

  public void help__image_offset()
  {
    help__set_output_j2k_image_offset();
  }

  public void call__set_output_j2k_tile_offset()
  {
    int x_offset, y_offset;
  
    x_offset = read_int(ARG_MANDATORY,
                        "Tile horizontal offset not specified");
    y_offset = read_int(ARG_MANDATORY,
                        "Tile Vertical offset not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kTileOffset(x_offset, y_offset);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_tile_offset()
  {
    System.out.print("--set-output-j2k-tile-offset <x offset> <y offset>\n" +
                     "Offsets the tile boundary from the top-left corner of the image\n" +
                     "grid.  The tile offset must be within the rectangle defined by the\n" +
                     "origin and the image offset.\n" +
                     "");
  }

  public void call__tile_offset()
  {
    call__set_output_j2k_tile_offset();
  }

  public void help__tile_offset()
  {
    help__set_output_j2k_tile_offset();
  }

  private class ErrorResilienceOptions {
    boolean use_SOP, use_EPH, use_SEG;
    ErrorResilienceOptions(String error_resilience_string)
    {
      use_SOP = use_EPH = use_SEG = false;
      int offset = 0;
      while (offset < error_resilience_string.length()) {
        int segment_length = error_resilience_string.indexOf(',', offset);
        if (segment_length < 0)
          segment_length = error_resilience_string.length() - offset;
        else
          segment_length -= offset;

        if (segment_length > 0) {
          boolean use_all =
            error_resilience_string.regionMatches(true, offset, "all", 0,
                                                  segment_length);
          boolean use_none =
            error_resilience_string.regionMatches(true, offset, "none", 0,
                                                  segment_length);
          use_SOP = (!use_none) &&
            (use_SOP || use_all ||
             error_resilience_string.regionMatches(true, offset, "sop",
                                                   0, segment_length));
          use_EPH = (!use_none) &&
            (use_EPH || use_all ||
             error_resilience_string.regionMatches(true, offset, "eph",
                                                   0, segment_length));
          use_SEG = (!use_none) &&
            (use_SEG || use_all ||
             error_resilience_string.regionMatches(true, offset, "seg",
                                                   0, segment_length));
        }
        offset += segment_length + 1;
      }
    }
  }

  public void call__set_output_j2k_error_resilience()
  {
    ErrorResilienceOptions opts =
      new ErrorResilienceOptions(
        read_string(ARG_MANDATORY, "Error resilience options not specified"));

    try {
      j2k_object.AwJ2kSetOutputJ2kErrorRes((opts.use_SOP ? 1 : 0),
                                           (opts.use_EPH ? 1 : 0),
                                           (opts.use_SEG ? 1 : 0));
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_error_resilience()
  {
    System.out.print("--set-output-j2k-error-resilience <error resilience options list>\n" +
                     "Enables and disables the use of the error resilience features of JPEG 2000.\n" +
                     "Allows Start of Packet and End of Packet Header markers to be added to the\n" +
                     "codestream, as well as Segmentation Symbols to be embedded in it.\n" +
                     "The error resilience options are:\n" +
                     "  SOP  - to enable Start of Packet markers\n" +
                     "  EPH  - to enable End of Packet Header markers\n" +
                     "  SEG  - to enable segmentation symbols\n" +
                     "  ALL  - to enable all of the above\n" +
                     "  NONE - to disable all of the options\n" +
                     "Multiple options may be listed, separated by commas.\n" +
                     "");
  }

  public void call_E()
  {
    call__set_output_j2k_error_resilience();
  }

  public void help_E()
  {
    help__set_output_j2k_error_resilience();
  }

  public void call__error_resilience()
  {
    call__set_output_j2k_error_resilience();
  }

  public void help__error_resilience()
  {
    help__set_output_j2k_error_resilience();
  }


  public void call__set_output_j2k_error_resilience_ex()
  {
    int tile, channel;

    tile = read_tile();
    channel = read_channel();
  
    ErrorResilienceOptions opts =
      new ErrorResilienceOptions(
        read_string(ARG_MANDATORY, "Error resilience options not specified"));

    try {
      j2k_object.AwJ2kSetOutputJ2kErrorResEx(tile, channel,
                                             (opts.use_SOP ? 1 : 0),
                                             (opts.use_EPH ? 1 : 0),
                                             (opts.use_SEG ? 1 : 0));
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_error_resilience_ex()
  {
    System.out.print("--set-output-j2k-error-resilience-ex <tile index> <channel index> <error resilience options list>\n" +
                     "Enables and disables the use of the error resilience features of JPEG 2000\n" +
                     "for the given channel of a tile.  Allows Start of Packet and End of Packet\n" +
                     "Header markers to be added to the codestream, as well as Segmentation Symbols\n" +
                     "to be embedded in it.  SOP and EPH markers cannot be set individually by\n" +
                     "channel; they must be enabled or disabled for all channels of a tile.\n" +
                     "The error resilience options are:\n" +
                     "  SOP  - to enable Start of Packet markers\n" +
                     "  EPH  - to enable End of Packet Header markers\n" +
                     "  SEG  - to enable segmentation symbols\n" +
                     "  ALL  - to enable all of the above\n" +
                     "  NONE - to disable all of the options\n" +
                     "Multiple options may be listed, separated by commas.\n" +
                     "");
  }

  public void call__error_resilience_ex()
  {
    call__set_output_j2k_error_resilience_ex();
  }

  public void help__error_resilience_ex()
  {
    help__set_output_j2k_error_resilience_ex();
  }


  public void call__set_output_j2k_xform()
  {
    int retval, type, levels;
    String type_string;

    type_string = read_string(ARG_MANDATORY,
                              "Wavelet transform type not specified");

    type = AwJ2kParameters.AW_J2K_WV_TYPE_DEFAULT;
    if (type_string != null) {
      switch (type_string.charAt(0)) {
      case 'i': case 'I':
        type = AwJ2kParameters.AW_J2K_WV_TYPE_I97;
        break;
      case 'r': case 'R':
        type = AwJ2kParameters.AW_J2K_WV_TYPE_R53;
        break;
      default:
        type = AwJ2kParameters.AW_J2K_WV_TYPE_DEFAULT;
      }
    }

    levels = read_int(ARG_OPTIONAL, null,
                      AwJ2kParameters.AW_J2K_WV_DEPTH_DEFAULT);

    try {
      j2k_object.AwJ2kSetOutputJ2kXform(type, levels);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_xform()
  {
    System.out.print("--set-output-j2k-xform <transform type> [<transform depth>]\n" +
                     "Selects the type of wavelet and (optionally) the transform depth to use for\n" +
                     "compression.  The wavelet choices are:\n" +
                     "  I97 - irreversible 9-7 wavelet\n" +
                     "  R53 - reversible 5-3 wavelet\n" +
                     "");
  }

  public void call_w()
  {
    call__set_output_j2k_xform();
  }

  public void help_w()
  {
    help__set_output_j2k_xform();
  }

  public void call__wavelet_transform()
  {
    call__set_output_j2k_xform();
  }

  public void help__wavelet_transform()
  {
    help__set_output_j2k_xform();
  }


  public void call__set_output_j2k_xform_ex()
  {
    int type, levels, tile_index, channel_index;
    String type_string;

    tile_index = read_tile();
    channel_index = read_channel();

    type_string = read_string(ARG_MANDATORY,
                              "Wavelet transform type not specified");
  
    type = AwJ2kParameters.AW_J2K_WV_TYPE_DEFAULT;
    if (type_string != null) {
      switch (type_string.charAt(0)) {
      case 'i': case 'I':
        type = AwJ2kParameters.AW_J2K_WV_TYPE_I97;
        break;
      case 'r': case 'R':
        type = AwJ2kParameters.AW_J2K_WV_TYPE_R53;
        break;
      default:
        type = AwJ2kParameters.AW_J2K_WV_TYPE_DEFAULT;
      }
    }
  
    levels = read_int(ARG_OPTIONAL, null,
                      AwJ2kParameters.AW_J2K_WV_DEPTH_DEFAULT);
  
    try {
      j2k_object.AwJ2kSetOutputJ2kXformEx(tile_index, channel_index, type,
                                          levels);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_xform_ex()
  {
    System.out.print("--set-output-j2k-xform-ex <tile index> <channel index> <transform type> [<transform depth>]\n" +
                     "Selects the type of wavelet and (optionally) the transform depth to use for\n" +
                     "compression.  The wavelet choices are:\n" +
                     "  I97 - irreversible 9-7 wavelet\n" +
                     "  R53 - reversible 5-3 wavelet\n" +
                     "");
  }


  public void call__set_output_j2k_wavelet_mct()
  {
    int type, levels, Nmcc;
    String type_string;
  
    type_string = read_string(ARG_MANDATORY, "MCT Wavelet type not specified");
  
    type = AwJ2kParameters.AW_J2K_WV_TYPE_DEFAULT;
    if (type_string != null) {
      switch (type_string.charAt(0)) {
      case 'i': case 'I':
        type = AwJ2kParameters.AW_J2K_WV_TYPE_I97;
        break;
      case 'r': case 'R':
        type = AwJ2kParameters.AW_J2K_WV_TYPE_R53;
        break;
      default:
        type = AwJ2kParameters.AW_J2K_WV_TYPE_DEFAULT;
      }
    }
  
    levels = read_int(ARG_OPTIONAL, null,
                      AwJ2kParameters.AW_J2K_WV_DEPTH_DEFAULT);
    
    Nmcc = read_int(ARG_OPTIONAL, null,
                    AwJ2kParameters.AW_J2K_SELECT_ALL_CHANNELS);
  
    try {
      j2k_object.AwJ2kSetOutputJ2kWaveletMct(type, levels, Nmcc);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_wavelet_mct()
  {
    System.out.print("--set-output-j2k-wavelet-mct <transform type> [<transform depth>] [<number of components>]\n" +
                     "Selects the type of multi-component wavelet transform, (optionally) the transform depth to use for\n" +
                     "compression and (optionally) the number of components for each component collection.  The wavelet choices are:\n" +
                     "  I97 - irreversible 9-7 wavelet\n" +
                     "  R53 - reversible 5-3 wavelet\n" +
                     "");
  }

  public void call_mct()
  {
    call__set_output_j2k_wavelet_mct();
  }

  public void help_mct()
  {
    help__set_output_j2k_wavelet_mct();
  }


  public void call__set_output_j2k_layers()
  {
    int layers;
  
    layers = read_int(ARG_MANDATORY,
                      "Number of quality layers not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kLayers(layers);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_layers()
  {
    System.out.print("--set-output-j2k-layers <quality layers>\n" +
                     "Sets the number of quality layers to be embedded in a JPEG 2000 image.\n" +
                     "");
  }

  public void call_y()
  {
    call__set_output_j2k_layers();
  }

  public void help_y()
  {
    help__set_output_j2k_layers();
  }

  public void call__layers()
  {
    call__set_output_j2k_layers();
  }

  public void help__layers()
  {
    help__set_output_j2k_layers();
  }


  public void call__set_output_j2k_layer_bitrate()
  {
    int layer_index;
    float bitrate;
  
    layer_index = read_int(ARG_MANDATORY,
                           "Layer index not specified");
  
    bitrate = read_float(ARG_MANDATORY,
                         "Layer bitrate not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kLayerBitrate(layer_index, bitrate);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_layer_bitrate()
  {
    System.out.print("--set-output-j2k-layer-bitrate <layer index> <bitrate>\n" +
                     "Sets the target bitrate, in bits per pixel, for the selected quality layer.\n" +
                     "");
  }

  public void call_yB()
  {
    call__set_output_j2k_layer_bitrate();
  }

  public void help_yB()
  {
    help__set_output_j2k_layer_bitrate();
  }

  public void call__layer_bitrate()
  {
    call__set_output_j2k_layer_bitrate();
  }

  public void help__layer_bitrate()
  {
    help__set_output_j2k_layer_bitrate();
  }

  public void call__set_output_j2k_layer_bitrate_ex()
  {
    int tile_index, layer_index;
    float bitrate;
  
    tile_index = read_tile();
  
    layer_index = read_int(ARG_MANDATORY,
                           "Layer index not specified");
  
    bitrate = read_float(ARG_MANDATORY,
                         "Layer bitrate not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kLayerBitrateEx(tile_index, layer_index,
                                                 bitrate);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_layer_bitrate_ex()
  {
    System.out.print("--set-output-j2k-layer-bitrate-ex <tile index> <layer index> <bitrate>\n" +
                     "Sets the target bitrate, in bits per pixel, for the selected quality layer\n" +
                     "of the selected tile.\n" +
                     "");
  }

  public void call__set_output_j2k_layer_ratio()
  {
    int layer_index;
    float ratio;
  
    layer_index = read_int(ARG_MANDATORY,
                           "Layer index not specified");
  
    ratio = read_float(ARG_MANDATORY,
                       "Layer ratio not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kLayerRatio(layer_index, ratio);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_layer_ratio()
  {
    System.out.print("--set-output-j2k-layer-ratio <layer index> <ratio>\n" +
                     "Sets the target compression ratio for the selected quality layer.\n" +
                     "");
  }

  public void call_yR()
  {
    call__set_output_j2k_layer_ratio();
  }

  public void help_yR()
  {
    help__set_output_j2k_layer_ratio();
  }

  public void call__layer_ratio()
  {
    call__set_output_j2k_layer_ratio();
  }

  public void help__layer_ratio()
  {
    help__set_output_j2k_layer_ratio();
  }


  public void call__set_output_j2k_layer_ratio_ex()
  {
    int tile_index, layer_index;
    float ratio;
  
    tile_index = read_tile();
  
    layer_index = read_int(ARG_MANDATORY,
                           "Layer index not specified");
  
    ratio = read_float(ARG_MANDATORY,
                       "Layer ratio not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kLayerRatioEx(tile_index, layer_index, ratio);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_layer_ratio_ex()
  {
    System.out.print("--set-output-j2k-layer-ratio-ex <tile index> <layer index> <ratio>\n" +
                     "Sets the target compression ratio for the selected quality layer of the\n" +
                     "selected tile.\n" +
                     "");
  }


  public void call__set_output_j2k_layer_size()
  {
    int layer_index;
    int bytes;
  
    layer_index = read_int(ARG_MANDATORY,
                           "Layer index not specified");
  
    bytes = read_int(ARG_MANDATORY,
                     "Layer size not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kLayerSize(layer_index, bytes);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_layer_size()
  {
    System.out.print("--set-output-j2k-layer-size <layer index> <byte count>\n" +
                     "Sets the target size, in bytes, of the selected quality layer.\n" +
                     "");
  }

  public void call_yF()
  {
    call__set_output_j2k_layer_size();
  }

  public void help_yF()
  {
    help__set_output_j2k_layer_size();
  }

  public void call__layer_size()
  {
    call__set_output_j2k_layer_size();
  }

  public void help__layer_size()
  {
    help__set_output_j2k_layer_size();
  }


  public void call__set_output_j2k_layer_size_ex()
  {
    int tile_index, layer_index;
    int bytes;
  
    tile_index = read_tile();
  
    layer_index = read_int(ARG_MANDATORY,
                           "Layer index not specified");
  
    bytes = read_int(ARG_MANDATORY,
                     "Layer size not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kLayerSizeEx(tile_index, layer_index, bytes);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_layer_size_ex()
  {
    System.out.print("--set-output-j2k-layer-size-ex <tile index> <layer index> <byte count>\n" +
                     "Sets the target size, in bytes, of the selected quality layer of the selected\n" +
                     "tile.\n" +
                     "");
  }


  public void call__set_output_j2k_layer_psnr()
  {
    int layer_index;
    float psnr;
  
    layer_index = read_int(ARG_MANDATORY,
                           "Layer index not specified");
  
    psnr = read_float(ARG_MANDATORY,
                      "Layer pSNR not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kLayerPsnr(layer_index, psnr);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_layer_psnr()
  {
    System.out.print("--set-output-j2k-layer-psnr <layer index> <psnr>\n" +
                     "Sets the output image pSNR for a specific layer, in dB.\n" +
                     "");
  }

  public void call__set_output_j2k_layer_psnr_ex()
  {
    int tile_index, layer_index;
    float psnr;
  
    tile_index = read_tile();
  
    layer_index = read_int(ARG_MANDATORY,
                           "Layer index not specified");
  
    psnr = read_float(ARG_MANDATORY,
                      "Layer pSNR not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kLayerPsnrEx(tile_index, layer_index, psnr);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_layer_psnr_ex()
  {
    System.out.print("--set-output-j2k-layer-psnr-ex <tile index> <layer index> <psnr>\n" +
                     "Sets the output image pSNR for a specific layer of the selected tile, in dB.\n" +
                     "");
  }

  public void call__set_output_j2k_layer_rd_slope()
  {
    int layer_index;
    float rd_slope;
  
    layer_index = read_int(ARG_MANDATORY,
                           "Layer index not specified");
  
    rd_slope = read_float(ARG_MANDATORY,
                          "Layer rate/distortion slope not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kLayerRDSlope(layer_index,
                                               rd_slope);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_layer_rd_slope()
  {
    System.out.print("--set-output-j2k-layer-rd-slope <layer index> <rd_slope>\n" +
                     "Sets the target rate/distortion slope for the selected quality layer.\n" +
                     "");
  }

  public void call_yS()
  {
    call__set_output_j2k_layer_rd_slope();
  }

  public void help_yS()
  {
    help__set_output_j2k_layer_rd_slope();
  }

  public void call__layer_rd_slope()
  {
    call__set_output_j2k_layer_rd_slope();
  }

  public void help__layer_rd_slope()
  {
    help__set_output_j2k_layer_rd_slope();
  }

  public void call__set_output_j2k_layer_rd_slope_ex()
  {
    int tile_index, layer_index;
    float rd_slope;
  
    tile_index = read_tile();
  
    layer_index = read_int(ARG_MANDATORY,
                           "Layer index not specified");
  
    rd_slope = read_float(ARG_MANDATORY,
                          "Layer rate/distortion slope not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kLayerRDSlopeEx(tile_index, layer_index,
                                                 rd_slope);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_layer_rd_slope_ex()
  {
    System.out.print("--set-output-j2k-layer-rd_slope-ex <tile index> <layer index> <rd_slope>\n" +
                     "Sets the target rate/distortion slope for the selected quality layer\n" +
                     "of the selected tile.\n" +
                     "");
  }

  public void call__get_output_j2k_layer_rd_slope()
  {
    int retval, layer_index;
    float rd_slope;
  
    layer_index = read_int(ARG_MANDATORY,
                           "Layer index not specified");
  
    try {
      rd_slope = j2k_object.AwJ2kGetOutputJ2kLayerRDSlope(layer_index);
      diagnostic_stream.printf(
        "The rate/distortion slope for layer %d is %g\n",
        layer_index, rd_slope);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
  
    return;
  }
  public void help__get_output_j2k_layer_rd_slope()
  {
    System.out.print("--get-output-j2k-layer-rd-slope <layer index>\n" +
                     "Gets the target rate/distortion slope for the selected quality layer.\n" +
                     "");
  }

  public void call__get_rd_slope()
  {
    call__get_output_j2k_layer_rd_slope();
  }

  public void help__get_rd_slope()
  {
    help__get_output_j2k_layer_rd_slope();
  }


  public void call__set_output_j2k_channel_quantization()
  {
    int channel_index, quantization_option;
    String quantization_string;

    channel_index = AwJ2kParameters.AW_J2K_SELECT_ALL_CHANNELS;
    quantization_option = AwJ2kParameters.AW_J2K_QUANTIZATION_EXPOUNDED;
  
    channel_index = read_channel();
  
    quantization_string = read_string(ARG_MANDATORY,
                                      "Quantization option not specified");
    if (quantization_string != null) {
      switch (quantization_string.charAt(0)) {
      case 'r': case 'R':
        quantization_option = AwJ2kParameters.AW_J2K_QUANTIZATION_REVERSIBLE;
        break;
      case 'd': case 'D':
        quantization_option = AwJ2kParameters.AW_J2K_QUANTIZATION_DERIVED;
        break;
      case 'e': case 'E':
        quantization_option = AwJ2kParameters.AW_J2K_QUANTIZATION_EXPOUNDED ;
        break;
      default:
        diagnostic_stream.println("Warning: Quantization option `" +
                                  quantization_string + "' not recognized\n");
      }
    }
  
    try {
      j2k_object.AwJ2kSetOutputJ2kChanQuant(channel_index,
                                            quantization_option);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_channel_quantization()
  {
    System.out.print("--set-output-j2k-channel-quantization <channel index> <quantization type>\n" +
                     "Sets the quantization type for a channel of a JPEG 2000 image.  The channel\n" +
                     "index may be `all' to set the quantization for all channels.  The supported\n" +
                     "quantization types are:\n" +
                     "  reversible - Reversible quantization (used only with the 5-3 wavelet)\n" +
                     "  derived    - Derived irreversible quantization (used with the 9-7 wavelet)\n" +
                     "  expounded  - Expounded irreversible quantization (used with the 9-7 wavelet)\n" +
                     "");
  }

  public void call_q()
  {
    call__set_output_j2k_channel_quantization();
  }

  public void help_q()
  {
    help__set_output_j2k_channel_quantization();
  }

  public void call__quantization_type()
  {
    call__set_output_j2k_channel_quantization();
  }

  public void help__quantization_type()
  {
    help__set_output_j2k_channel_quantization();
  }


  public void call__set_output_j2k_quantization_ex()
  {
    int tile_index, channel_index, quantization_option;
    String quantization_string;
  
    tile_index = read_tile();
    channel_index = read_channel();
  
    channel_index = AwJ2kParameters.AW_J2K_SELECT_ALL_CHANNELS;
    quantization_option = AwJ2kParameters.AW_J2K_QUANTIZATION_EXPOUNDED;
  
    quantization_string = read_string(ARG_MANDATORY,
                                      "Quantization option not specified");
    if (quantization_string != null) {
      switch (quantization_string.charAt(0)) {
      case 'r': case 'R':
        quantization_option = AwJ2kParameters.AW_J2K_QUANTIZATION_REVERSIBLE;
        break;
      case 'd': case 'D':
        quantization_option = AwJ2kParameters.AW_J2K_QUANTIZATION_DERIVED;
        break;
      case 'e': case 'E':
        quantization_option = AwJ2kParameters.AW_J2K_QUANTIZATION_EXPOUNDED ;
        break;
      default:
        diagnostic_stream.println("Warning: Quantization option `" +
                                  quantization_string + "' not recognized\n");
      }
    }
  
    try {
      j2k_object.AwJ2kSetOutputJ2kChanQuantEx(tile_index, channel_index,
                                              quantization_option);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_quantization_ex()
  {
    System.out.print("--set-output-j2k-quantization-ex <tile index> <channel index> <quantization type>\n" +
                     "Sets the quantization type for a channel of a tile of a JPEG 2000 image.  The\n" +
                     "tile index may be `all' to set the quantization for all the tiles; similarly,\n" +
                     "the channel index may be `all' to set the quantization for all channels.  The\n" +
                     "supported quantization types are:\n" +
                     "  reversible - Reversible quantization (used only with the 5-3 wavelet)\n" +
                     "  derived    - Derived irreversible quantization (used with the 9-7 wavelet)\n" +
                     "  expounded  - Expounded irreversible quantization (used with the 9-7 wavelet)\n" +
                     "");
  }

  public void call__set_output_j2k_quantization_binwidth_scale()
  {
    float binwidth_scale;
  
    binwidth_scale = read_float(ARG_MANDATORY,
                                "Binwidth scale factor not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kQuantBinwidthScale(binwidth_scale);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_quantization_binwidth_scale()
  {
    System.out.print("--set-output-j2k-quantization-binwidth-scale <binwidth scale>\n" +
                     "Scales the default binwidths by the factor <binwidth scale>.  This\n" +
                     "scale is only applied to the derived and expounded quantization options.\n" +
                     "");
  }

  public void call__binwidth_scale()
  {
    call__set_output_j2k_quantization_binwidth_scale();
  }

  public void help__binwidth_scale()
  {
    help__set_output_j2k_quantization_binwidth_scale();
  }


  public void call__set_output_j2k_quantization_binwidth_scale_ex()
  {
    int tile_index, channel_index;
    float binwidth_scale;
  
    tile_index = read_tile();
    channel_index = read_channel();
  
    binwidth_scale = read_float(ARG_MANDATORY,
                                "Binwidth scale factor not specified");
  
  
    try {
      j2k_object.AwJ2kSetOutputJ2kQuantBinwidthScale(tile_index,
                                                     channel_index,
                                                     binwidth_scale);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_quantization_binwidth_scale_ex()
  {
    System.out.print("--set-output-j2k-quantization-binwidth-scale-ex <tile index> <channel index> <binwidth scale>\n" +
                     "Scales the default binwidths for a channel of a tile by the factor <binwidth\n" +
                     "scale>.  This scale is only applied to the derived and expounded quantization\n" +
                     "options.\n" +
                     "");
  }

  public void call__set_output_j2k_guard_bits()
  {
    int guard_bits;
  
    guard_bits = read_int(ARG_MANDATORY,
                          "Guard bits not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kGuardBits(guard_bits);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_guard_bits()
  {
    System.out.print("--set-output-j2k-guard-bits <guard bits>\n" +
                     "Sets the number of guard bits, which are used to ensure the the\n" +
                     "block encoder does not overflow.  The legal values for this parameter\n" +
                     "range from 0 to 7.  The default is 2.\n" +
                     "");
  }

  public void call_g()
  {
    call__set_output_j2k_guard_bits();
  }

  public void help_g()
  {
    help__set_output_j2k_guard_bits();
  }

  public void call__guard_bits()
  {
    call__set_output_j2k_guard_bits();
  }

  public void help__guard_bits()
  {
    help__set_output_j2k_guard_bits();
  }

  public void call__set_output_j2k_guard_bits_ex()
  {
    int guard_bits, tile_index, channel_index;
  
    tile_index = read_tile();
    channel_index = read_channel();

    guard_bits = read_int(ARG_MANDATORY,
                          "Guard bits not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kGuardBitsEx(tile_index, channel_index,
                                              guard_bits);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_guard_bits_ex()
  {
    System.out.print("--set-output-j2k-guard-bits-ex <tile index> <channel index> <guard bits>\n" +
                     "Sets the number of guard bits, which are used to ensure the the\n" +
                     "block encoder does not overflow, for a specified channel of a tile.  The legal\n" +
                     "values for this parameter range from 0 to 7.  The default is 2.\n" +
                     "");
  }
  public void call__set_output_j2k_channel_precinct_size()
  {
    int channel_index, resolution_index, precinct_height, precinct_width;
  
    channel_index = read_channel();
  
    resolution_index = read_int(ARG_MANDATORY,
                                "resolution index not specified");
    precinct_height = read_int(ARG_MANDATORY,
                               "precinct height not specified");
    precinct_width = read_int(ARG_MANDATORY,
                              "precinct width not specified");
    try {
      j2k_object.AwJ2kSetOutputJ2kPrecinctSize(channel_index, resolution_index,
                                               precinct_height,
                                               precinct_width);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_channel_precinct_size()
  {
    System.out.print("--set-output-j2k-channel-precinct-size <channel index> <resolution index> <precinct height> <precinct width>\n" +
                     "Sets the dimensions of the precincts in a JPEG 2000 image.  <Channel index>\n" +
                     "can either be `all' for all channels or the index of a channel for which the\n" +
                     "precinct sizes are set.  <Resolution index> runs from 0 for the lowest\n" +
                     "resolution to one more than the number of transform levels.  <Precinct height>\n" +
                     "and <precinct width> are the base-2 logarithm of the desired precinct sizes.\n" +
                     "They can range from 0 to 15.  Precinct size of 0 is only allowed for\n" +
                     "resolution level 0.\n" +
                     "");
  }

  public void call_P()
  {
    call__set_output_j2k_channel_precinct_size();
  }

  public void help_P()
  {
    help__set_output_j2k_channel_precinct_size();
  }

  public void call__precinct()
  {
    call__set_output_j2k_channel_precinct_size();
  }

  public void help__precinct()
  {
    help__set_output_j2k_channel_precinct_size();
  }

  public void call__set_output_j2k_precinct_size_ex()
  {
    int tile_index, channel_index, resolution_index, precinct_height,
      precinct_width;
  
    tile_index = read_tile();
    channel_index = read_channel();
  
    resolution_index = read_int(ARG_MANDATORY,
                                "resolution index not specified");
    precinct_height = read_int(ARG_MANDATORY,
                               "precinct height not specified");
    precinct_width = read_int(ARG_MANDATORY,
                              "precinct width not specified");

    try {
      j2k_object.AwJ2kSetOutputJ2kChanPrecSizeEx(tile_index, channel_index,
                                                 resolution_index,
                                                 precinct_height,
                                                 precinct_width);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_precinct_size_ex()
  {
    System.out.print("--set-output-j2k-precinct-size-ex <tile index> <channel index> <resolution index> <precinct height> <precinct width>\n" +
                     "Sets the dimensions of the precincts for a channel in a tile.  <Resolution\n" +
                     "index> runs from 0 for the lowest resolution, to N, where N is the number of\n" +
                     "transform levels.  <Precinct height> and <precinct width> are the base-2\n" +
                     "logarithm of the desired precinct sizes.  They can range from 0 to 15.\n" +
                     "Precinct size of 0 is only allowed for resolution level 0.\n" +
                     "");
  }

  public void call__set_output_j2k_codeblock_size()
  {
    int codeblock_height, codeblock_width;
    codeblock_height = read_int(ARG_MANDATORY,
                                "Codeblock height not specified");
    codeblock_width = read_int(ARG_MANDATORY,
                               "Codeblock width not specified");
    try {
      j2k_object.AwJ2kSetOutputJ2kCblockSize(codeblock_height,
                                             codeblock_width);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_codeblock_size()
  {
    System.out.print("--set-output-j2k-codeblock-size <codeblock height> <codeblock width>\n" +
                     "Sets the dimensions of the codeblocks.  The values for <codeblock height> and\n" +
                     "<codeblock width> are the base-2 logarithm of the actual codeblock sizes.\n" +
                     "Each of height and width may range from 2 to 10, and their sum must be less\n" +
                     "than or equal to 12.\n" +
                     "");
  }

  public void call_cb()
  {
    call__set_output_j2k_codeblock_size();
  }

  public void help_cb()
  {
    help__set_output_j2k_codeblock_size();
  }

  public void call__codeblock_size()
  {
    call__set_output_j2k_codeblock_size();
  }

  public void help__codeblock_size()
  {
    help__set_output_j2k_codeblock_size();
  }

  public void call__set_output_j2k_codeblock_size_ex()
  {
    int tile_index, channel_index, codeblock_height, codeblock_width;
    tile_index = read_tile();
    channel_index = read_channel();
  
    codeblock_height = read_int(ARG_MANDATORY,
                                "Codeblock height not specified");
    codeblock_width = read_int(ARG_MANDATORY,
                               "Codeblock width not specified");
    try {
      j2k_object.AwJ2kSetOutputJ2kCblockSizeEx(tile_index, channel_index,
                                               codeblock_height,
                                               codeblock_width);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_codeblock_size_ex()
  {
    System.out.print("--set-output-j2k-codeblock-size-ex <tile index> <channel index> <codeblock height> <codeblock width>\n" +
                     "Sets the dimensions of the codeblocks in a channel of a tile.  The values for\n" +
                     "<codeblock height> and <codeblock width> are the base-2 logarithm of the\n" +
                     "actual codeblock sizes.  Each of height and width may range from 2 to 10, and\n" +
                     "their sum must be less than or equal to 12.\n" +
                     "");
  }

  public void call__set_output_j2k_arithmetic_coding_option()
  {
    int option, value = 0;
    String option_string;
  
    if (argv[arg].equals("--context-reset"))
      option = AwJ2kParameters.AW_J2K_ARITH_OPT_CONTEXT_RESET;
    else if (argv[arg].equals("--ac-term"))
      option = AwJ2kParameters.AW_J2K_ARITH_OPT_ARITHMETIC_TERMINATION;
    else if (argv[arg].equals("--pred-term"))
      option = AwJ2kParameters.AW_J2K_ARITH_OPT_PREDICTABLE_TERMINATION;
    else if (argv[arg].equals("--vert-causal"))
      option = AwJ2kParameters.AW_J2K_ARITH_OPT_VERTICALLY_CAUSAL_CONTEXT;
    else {
      option_string = read_string(ARG_MANDATORY,
                                  "Arithmetic coding option not specified");
      switch (option_string.charAt(0)) {
      case 'c': case 'C':
        option = AwJ2kParameters.AW_J2K_ARITH_OPT_CONTEXT_RESET;
        break;
      case 'a': case 'A':
        option = AwJ2kParameters.AW_J2K_ARITH_OPT_ARITHMETIC_TERMINATION;
        break;
      case 'p': case 'P':
        option = AwJ2kParameters.AW_J2K_ARITH_OPT_PREDICTABLE_TERMINATION;
        break;
      case 'v': case 'V':
        option = AwJ2kParameters.AW_J2K_ARITH_OPT_VERTICALLY_CAUSAL_CONTEXT;
        break;
      case 'b': case 'B':
        option = AwJ2kParameters.AW_J2K_ARITH_OPT_ARITHMETIC_CODING_BYPASS;
        break;
      default:
        diagnostic_stream.print("Unrecognized arithmetic coding option `" +
                                option_string + "'.");
        return;
      }
    }
  
    switch (option) {
    case AwJ2kParameters.AW_J2K_ARITH_OPT_CONTEXT_RESET:
      option_string =
        read_string(ARG_MANDATORY,
                    "Arithmetic coding context reset frequency not specified");
      switch (option_string.charAt(0)) {
      case 'p': case 'P':
        value = AwJ2kParameters.AW_J2K_ACR_AT_EACH_CODEPASS_END;
        break;
      default:
        value = AwJ2kParameters.AW_J2K_ACR_ONLY_AT_CODEBLOCK_END;
      }
      break;
    case AwJ2kParameters.AW_J2K_ARITH_OPT_ARITHMETIC_TERMINATION:
      option_string =
        read_string(ARG_MANDATORY,
                    "Arithmetic coding termination frquency not specified");
      switch (option_string.charAt(0)) {
      case 'p': case 'P':
        value = AwJ2kParameters.AW_J2K_AT_AT_EACH_CODEPASS_END;
        break;
      default:
        value = AwJ2kParameters.AW_J2K_AT_ONLY_AT_CODEBLOCK_END;
      }
      break;
    case AwJ2kParameters.AW_J2K_ARITH_OPT_PREDICTABLE_TERMINATION:
      option_string =
        read_string(ARG_MANDATORY,
                    "Arithmetic coding predictable termination choice not specified");
      switch (option_string.charAt(0)) {
      case 'y': case 'Y':
        value = AwJ2kParameters.AW_J2K_PT_USE_PREDICTABLE_TERMINATION;
        break;
      default:
        value = AwJ2kParameters.AW_J2K_PT_NO_PREDICTABLE_TERMINATION;
      }
      break;
    case AwJ2kParameters.AW_J2K_ARITH_OPT_VERTICALLY_CAUSAL_CONTEXT:
      option_string =
        read_string(ARG_MANDATORY,
                    "Vertically causal context formation choice not specified");
      switch (option_string.charAt(0)) {
      case 'y': case 'Y':
        value = AwJ2kParameters.AW_J2K_VC_USE_VERTICALLY_CAUSAL_CONTEXT;
        break;
      default:
        value = AwJ2kParameters.AW_J2K_VC_NO_VERTICALLY_CAUSAL_CONTEXT;
      }
      break;
    case AwJ2kParameters.AW_J2K_ARITH_OPT_ARITHMETIC_CODING_BYPASS:
      option_string =
        read_string(ARG_MANDATORY,
                    "Arithmetic coding bypass choice not specified");
      switch (option_string.charAt(0)) {
      case 'y': case 'Y':
        value = AwJ2kParameters.AW_J2K_BY_USE_ARITHMETIC_CODING_BYPASS;
        break;
      default:
        value = AwJ2kParameters.AW_J2K_BY_NO_ARITHMETIC_CODING_BYPASS;
      }
    }
    try {
      j2k_object.AwJ2kSetOutputJ2kArithCodingOpt(option, value);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_arithmetic_coding_option()
  {
    System.out.print("--set-output-j2k-arithmetic-coding-option <option> <value>\n" +
                     "Sets any of the arithmetic coding options.  The following options, and their\n" +
                     "corresponding values, are supported:\n" +
                     "\n" +
                     "  context - sets how frequently the arithmetic coder is reset.  The allowed\n" +
                     "            values are:\n" +
                     "              block - only at the end of codeblock\n" +
                     "              pass  - at the end of each coding pass\n" +
                     "            Reset at end of codeblock is the default\n" +
                     "\n" +
                     "  arith   - sets how frequently the arithmetic coder is terminated.  The\n" +
                     "            allowed values are:\n" +
                     "              block - only at the end of codeblock\n" +
                     "              pass  - at the end of each coding pass\n" +
                     "            Termination at end of codeblock is the default\n" +
                     "\n" +
                     "  pred    - determines whether predictable termination will be used.  The\n" +
                     "            allowed values are:\n" +
                     "              yes   - use predictable termination\n" +
                     "              no    - do not use predictable termination (use normal\n" +
                     "                      termination)\n" +
                     "            Normal termination is the default.\n" +
                     "\n" +
                     "  vert    - sets whether the aritmetic coder's context formation will be\n" +
                     "            vertically causal.  The allowed values are:\n" +
                     "              yes - use vertically causal context formation\n" +
                     "              no  - do not use vertically causal context formation (use\n" +
                     "                    normal context formation)\n" +
                     "            Normal context formation is the default.\n" +
                     "  bypass  - sets whether the arithmetic coder is bypassed for late coding\n" +
                     "            passes, which can improve runtime performance at the expense of\n" +
                     "            compression efficiency.  The allowed values are:\n" +
                     "              yes - enable the arithmetic coding bypass option\n" +
                     "              no  - disable the arithmetic coding bypass option\n" +
                     "            Disabled arithmetic coding bypass is the default.\n" +
                     "");
  }
  public void call__context_reset()
  {
    call__set_output_j2k_arithmetic_coding_option();
  }
  public void help__context_reset()
  {
    System.out.print("--context-reset <context reset frequency>\n" +
                     "Sets how frequently the arithmetic coder is reset.  The allowed values are:\n" +
                     "  block - only at the end of codeblock\n" +
                     "  pass  - at the end of each coding pass\n" +
                     "Reset at end of codeblock is the default\n" +
                     "");
  }

  public void call__ac_term()
  {
    call__set_output_j2k_arithmetic_coding_option();
  }
  public void help__ac_term()
  {
    System.out.print("--ac-term <arithmetic termination frequency>\n" +
                     "Sets how frequently the arithmetic coder is terminated.  The allowed values\n" +
                     "are:\n" +
                     "  block - only at the end of codeblock\n" +
                     "  pass  - at the end of each coding pass\n" +
                     "Termination at end of codeblock is the default\n" +
                     "");
  }

  public void call__pred_term()
  {
    call__set_output_j2k_arithmetic_coding_option();
  }
  public void help__pred_term()
  {
    System.out.print("--pred-term <predictable termination flag>\n" +
                     "Determines whether predictable termination will be used.  The allowed values\n" +
                     "are:\n" +
                     "  yes - use predictable termination\n" +
                     "  no  - do not use predictable termination (use normal termination)\n" +
                     "Normal termination is the default.\n" +
                     "");
  }

  public void call__vert_causal()
  {
    call__set_output_j2k_arithmetic_coding_option();
  }
  public void help__vert_causal()
  {
    System.out.print("--vert-causal <vertically causal context flag>\n" +
                     "Sets whether the aritmetic coder's context formation will be vertically\n" +
                     "causal.  The allowed values are:\n" +
                     "  yes - use vertically causal context formation\n" +
                     "  no  - do not use vertically causal context formation (use normal context\n" +
                     "        formation)\n" +
                     "Normal context formation is the default.\n" +
                     "");
  }

  public void call__set_output_j2k_arithmetic_coding_option_ex()
  {
    int tile_index, channel_index, option, value = 0;
    String option_string;
    tile_index = read_tile();
    channel_index = read_channel();
  
    option_string = read_string(ARG_MANDATORY,
                                "Arithmetic coding option not specified");
    switch (option_string.charAt(0)) {
    case 'c': case 'C':
      option = AwJ2kParameters.AW_J2K_ARITH_OPT_CONTEXT_RESET;
      break;
    case 'a': case 'A':
      option = AwJ2kParameters.AW_J2K_ARITH_OPT_ARITHMETIC_TERMINATION;
      break;
    case 'p': case 'P':
      option = AwJ2kParameters.AW_J2K_ARITH_OPT_PREDICTABLE_TERMINATION;
      break;
    case 'v': case 'V':
      option = AwJ2kParameters.AW_J2K_ARITH_OPT_VERTICALLY_CAUSAL_CONTEXT;
      break;
    case 'b': case 'B':
      option = AwJ2kParameters.AW_J2K_ARITH_OPT_ARITHMETIC_CODING_BYPASS;
      break;
    default:
      diagnostic_stream.print("Unrecognized arithmetic coding option `" +
                              option_string + "'.");
      return;
    }
  
    switch (option) {
    case AwJ2kParameters.AW_J2K_ARITH_OPT_CONTEXT_RESET:
      option_string =
        read_string(ARG_MANDATORY,
                    "Arithmetic coding context reset frequency not specified");
      switch (option_string.charAt(0)) {
      case 'p': case 'P':
        value = AwJ2kParameters.AW_J2K_ACR_AT_EACH_CODEPASS_END;
        break;
      default:
        value = AwJ2kParameters.AW_J2K_ACR_ONLY_AT_CODEBLOCK_END;
      }
      break;
    case AwJ2kParameters.AW_J2K_ARITH_OPT_ARITHMETIC_TERMINATION:
      option_string =
        read_string(ARG_MANDATORY,
                    "Arithmetic coding termination frquency not specified");
      switch (option_string.charAt(0)) {
      case 'p': case 'P':
        value = AwJ2kParameters.AW_J2K_AT_AT_EACH_CODEPASS_END;
        break;
      default:
        value = AwJ2kParameters.AW_J2K_AT_ONLY_AT_CODEBLOCK_END;
      }
      break;
    case AwJ2kParameters.AW_J2K_ARITH_OPT_PREDICTABLE_TERMINATION:
      option_string =
        read_string(ARG_MANDATORY,
                    "Arithmetic coding predictable termination choice not specified");
      switch (option_string.charAt(0)) {
      case 'y': case 'Y':
        value = AwJ2kParameters.AW_J2K_PT_USE_PREDICTABLE_TERMINATION;
        break;
      default:
        value = AwJ2kParameters.AW_J2K_PT_NO_PREDICTABLE_TERMINATION;
      }
      break;
    case AwJ2kParameters.AW_J2K_ARITH_OPT_VERTICALLY_CAUSAL_CONTEXT:
      option_string =
        read_string(ARG_MANDATORY,
                    "Vertically causal context formation choice not specified");
      switch (option_string.charAt(0)) {
      case 'y': case 'Y':
        value = AwJ2kParameters.AW_J2K_VC_USE_VERTICALLY_CAUSAL_CONTEXT;
        break;
      default:
        value = AwJ2kParameters.AW_J2K_VC_NO_VERTICALLY_CAUSAL_CONTEXT;
      }
      break;
    case AwJ2kParameters.AW_J2K_ARITH_OPT_ARITHMETIC_CODING_BYPASS:
      option_string =
        read_string(ARG_MANDATORY,
                    "Arithmetic coding bypass choice not specified");
      switch (option_string.charAt(0)) {
      case 'y': case 'Y':
        value = AwJ2kParameters.AW_J2K_BY_USE_ARITHMETIC_CODING_BYPASS;
        break;
      default:
        value = AwJ2kParameters.AW_J2K_BY_NO_ARITHMETIC_CODING_BYPASS;
      }
    }
    try {
      j2k_object.AwJ2kSetOutputJ2kArithCodingOptEx(tile_index, channel_index,
                                                   option, value);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_arithmetic_coding_option_ex()
  {
    System.out.print("--set-output-j2k-arithmetic-coding-option-ex <tile index> <channel index> <option> <value>\n" +
                     "Sets any of the arithmetic coding options for a channel of a tile.  The\n" +
                     "following options, and their corresponding values, are supported:\n" +
                     "\n" +
                     "  context - sets how frequently the arithmetic coder is reset.  The allowed\n" +
                     "            values are:\n" +
                     "              block - only at the end of codeblock\n" +
                     "              pass  - at the end of each coding pass\n" +
                     "            Reset at end of codeblock is the default\n" +
                     "\n" +
                     "  arith   - sets how frequently the arithmetic coder is terminated.  The\n" +
                     "            allowed values are:\n" +
                     "              block - only at the end of codeblock\n" +
                     "              pass  - at the end of each coding pass\n" +
                     "            Termination at end of codeblock is the default\n" +
                     "\n" +
                     "  pred    - determines whether predictable termination will be used.  The\n" +
                     "            allowed values are:\n" +
                     "              yes   - use predictable termination\n" +
                     "              no    - do not use predictable termination (use normal\n" +
                     "                      termination)\n" +
                     "            Normal termination is the default.\n" +
                     "\n" +
                     "  vert    - sets whether the aritmetic coder's context formation will be\n" +
                     "            vertically causal.  The allowed values are:\n" +
                     "              yes - use vertically causal context formation\n" +
                     "              no  - do not use vertically causal context formation (use\n" +
                     "                    normal context formation)\n" +
                     "            Normal context formation is the default.\n" +
                     "  bypass  - sets whether the arithmetic coder is bypassed for late coding\n" +
                     "            passes, which can improve runtime performance at the expense of\n" +
                     "            compression efficiency.  The allowed values are:\n" +
                     "              yes - enable the arithmetic coding bypass option\n" +
                     "              no  - disable the arithmetic coding bypass option\n" +
                     "            Disabled arithmetic coding bypass is the default.\n" +
                     "");
  }

  public void call__set_output_j2k_coding_predictor_offset()
  {
    int predictor_offset;
  
    predictor_offset = read_int(ARG_MANDATORY,
                                "Coding predictor offset not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kPredOffset(predictor_offset);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_coding_predictor_offset()
  {
    System.out.print("--set-output-j2k-coding-predictor-offset <predictor offset>\n" +
                     "Sets the offset from the predicted point at which coding will stop.  A\n" +
                     "smaller number will result in faster compression, though with a possible\n" +
                     "reduction in quality.  The default value is 2; a value of 1 will speed\n" +
                     "up compression and reduce quality; 3 will reduce speed and increase quality;\n" +
                     "0 will cause the library to code everything, resulting in the lowest speed\n" +
                     "but best quality.\n" +
                     "");
  }

  public void call__predictor_offset()
  {
    call__set_output_j2k_coding_predictor_offset();
  }

  public void help__predictor_offset()
  {
    help__set_output_j2k_coding_predictor_offset();
  }

  public void call__set_output_j2k_coding_predictor_offset_ex()
  {
    int tile_index, predictor_offset;
  
    tile_index = read_tile();
  
    predictor_offset = read_int(ARG_MANDATORY,
                                "Coding predictor offset not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kPredOffsetEx(tile_index, predictor_offset);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_coding_predictor_offset_ex()
  {
    System.out.print("--set-output-j2k-coding-predictor-offset-ex <tile index> <predictor offset>\n" +
                     "Sets the offset from the predicted point at which coding will stop for the\n" +
                     "given tile.  A smaller number will result in faster compression, though with a\n" +
                     "possible reduction in quality.  The default value is 2; a value of 1 will speed\n" +
                     "up compression and reduce quality; 3 will reduce speed and increase quality;\n" +
                     "0 will cause the library to code everything, resulting in the lowest speed\n" +
                     "but best quality.\n" +
                     "");
  }

  public void call__set_output_j2k_component_registration()
  {
    int channel, x_registration_offset, y_registration_offset;
  
    channel = read_int(ARG_MANDATORY,
                       "Channel index not specified");
  
    x_registration_offset =
      read_int(ARG_MANDATORY, "Horizontal registration offset not specified");
    y_registration_offset =
      read_int(ARG_MANDATORY, "Vertical registration offset not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kCompReg(channel,
                                          x_registration_offset,
                                          y_registration_offset);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_component_registration()
  {
    System.out.print("--set-output-j2k-component-registration <channel> <x registration offset> <y registration offset>\n" +
                     "Sets a color channel's registration offset in a JPEG 2000 image.\n" +
                     "The registration offsets indicate how much to offset each color\n" +
                     "channel relative to the image grid for display.  The offsets are\n" +
                     "given in units of 1/65536 of a pixel.\n" +
                     "");
  }

  public void call__set_component_registration()
  {
    call__set_output_j2k_component_registration();
  }

  public void help__set_component_registration()
  {
    help__set_output_j2k_component_registration();
  }

  public void call__set_output_j2k_tile_toc()
  {
    try {
      j2k_object.AwJ2kSetOutputJ2kTileToc();
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_tile_toc()
  {
    System.out.print("--set-output-j2k-tile-toc \n" +
                     "Adds to the JPEG 2000 image a Tile Length Marker (TLM) segment.\n" +
                     "");
  }

  public void call__add_tile_toc()
  {
    call__set_output_j2k_tile_toc();
  }

  public void help__add_tile_toc()
  {
    help__set_output_j2k_tile_toc();
  }

  public void call__set_output_j2k_tile_data_toc()
  {
    try {
      j2k_object.AwJ2kSetOutputJ2kTileDataToc();
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_tile_data_toc()
  {
    System.out.print("--set-output-j2k-tile-data-toc \n" +
                     "Adds to the JPEG 2000 image a Packet Length, Tilepart Header Marker (PLT)\n" +
                     "segment.\n" +
                     "");
  }

  public void call__add_tile_data_toc()
  {
    call__set_output_j2k_tile_data_toc();
  }

  public void help__add_tile_data_toc()
  {
    help__set_output_j2k_tile_data_toc();
  }

  public void call__set_output_j2k_tile_data_toc_ex()
  {
    int tile_index;
    boolean include_plt;
    
    tile_index = read_tile();
    include_plt = read_boolean(ARG_MANDATORY,
                               "PLT inclusion is not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kTileDataTocEx(tile_index, include_plt);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_tile_data_toc_ex()
  {
    System.out.print("--set-output-j2k-tile-data-toc-ex <tile index> <inclusion>\n" +
                     "Specifies whether to add to the given tile a Packet Length, Tilepart Header\n" +
                     "Marker (PLT) segment.  The <inclusion> parameter is boolean -- i.e. `Yes' or\n" +
                     "`No' are its expected values.\n" +
                     "");
  }

  public void call__set_output_j2k_tile_partition_depth()
  {
    int tp_depth;
    tp_depth = read_int(ARG_MANDATORY,
                        "Tile partition depth not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kTilePartitionDepth(tp_depth);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_tile_partition_depth()
  {
    System.out.print("--set-output-j2k-tile-partition-depth <tp depth>\n" +
                     "Specifies how tiles be should partitioned into tile parts.\n" +
                     "Depth value of 0 indicates no partitioning, \n" +
                     "depth of 1 will generate 1 tilepart for the entire quality layer (LRCP progression), as so on.\n" +
                     "");
  }

  public void call__tp_depth()
  {
    call__set_output_j2k_tile_partition_depth();
  }

  public void help__tp_depth()
  {
    help__set_output_j2k_tile_partition_depth();
  }

  public void call__set_output_j2k_header_option()
  {
    boolean header, end_marker;
  
    header = read_boolean(ARG_MANDATORY, "header option not specified");
    end_marker = read_boolean(ARG_MANDATORY,
                              "end_marker option not specified");
    try {
      j2k_object.AwJ2kSetOutputJ2kHeaderOption(header, end_marker);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_header_option()
  {
    System.out.print("--set-output-j2k-header-option <header> <end_marker>\n" +
                     "Determines whether the output j2k code stream will have a header and an end of\n" +
                     "stream marker.  By default both of the parameters are true.\n" +
                     "");
  }

  public void call__set_output_j2k_transform_weight()
  {
    int tile_index, channel_index, transform_level, subband_index;
    String subband_string;
    float weight;
  
    tile_index = read_tile();
    channel_index = read_channel();

    transform_level =
      read_int_or_all_string(AwJ2kParameters.AW_J2K_SELECT_ALL_LEVELS,
                             ARG_MANDATORY, "Transform level not specified",
                             "transform level");

    subband_string = read_string(ARG_MANDATORY,
                                 "Subband was not specified");
  
    weight = read_float(ARG_MANDATORY,
                        "Weight for the subband was not specified");
  
    if (subband_string.charAt(0) == 'a' || subband_string.charAt(0) == 'A')
      subband_index = AwJ2kParameters.AW_J2K_SELECT_ALL_SUBBANDS;
    else if ((subband_string.charAt(0) == 'l' ||
              subband_string.charAt(0) == 'L') &&
             (subband_string.charAt(1) == 'l' ||
              subband_string.charAt(1) == 'L'))
      subband_index = AwJ2kParameters.AW_J2K_SELECT_LL_SUBBAND;
    else if ((subband_string.charAt(0) == 'h' ||
              subband_string.charAt(0) == 'H') &&
             (subband_string.charAt(1) == 'l' ||
              subband_string.charAt(1) == 'L'))
      subband_index = AwJ2kParameters.AW_J2K_SELECT_HL_SUBBAND;
    else if ((subband_string.charAt(0) == 'l' ||
              subband_string.charAt(0) == 'L') &&
             (subband_string.charAt(1) == 'h' ||
              subband_string.charAt(1) == 'H'))
      subband_index = AwJ2kParameters.AW_J2K_SELECT_LH_SUBBAND;
    else if ((subband_string.charAt(0) == 'h' ||
              subband_string.charAt(0) == 'H') &&
             (subband_string.charAt(1) == 'h' ||
              subband_string.charAt(1) == 'H'))
      subband_index = AwJ2kParameters.AW_J2K_SELECT_HH_SUBBAND;
    else {
      diagnostic_stream.println( "Subband specification `" + subband_string +
                                 "' is not recognized");
      return;
    }
  
    try {
      j2k_object.AwJ2kSetOutputJ2kTransformWeight(tile_index, channel_index,
                                                  transform_level,
                                                  subband_index, weight);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_transform_weight()
  {
    System.out.print("--set-output-j2k-transform-weight <tile> <channel> <level> <subband> <weight>\n" +
                     "Specifies the relative weight given to a subband (LL, HL, LH, HH, or ALL) in the\n" +
                     "specified transform level (1 to the number of transform levels, or all) for the\n" +
                     "given channel in the given tile (all is a valid option for both).  The default\n" +
                     "weight for all subbands is 1.0\n" +
                     "");
  }

  public void call__weight()
  {
    call__set_output_j2k_transform_weight();
  }

  public void help__weight()
  {
    help__set_output_j2k_transform_weight();
  }



  public void call__set_output_j2k_clear_comments()
  {
    try {
      j2k_object.AwJ2kSetOutputJ2kClearComnts();
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_clear_comments()
  {
    System.out.print("--set-output-j2k-clear-comments \n" +
                     "Clears all comments from a JPEG 2000 image.\n" +
                     "");
  }


  public void call__output_reset_options()
  {
    try {
      j2k_object.AwJ2kOutputResetOptions();
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__output_reset_options()
  {
    System.out.print("--output-reset-options \n" +
                     "Resets all of the options set by the output image functions.\n" +
                     "");
  }

  public void call__set_output_j2k_roi_from_image()
  {
    String image_name;
    byte[] buffer;
  
    image_name = read_string(ARG_MANDATORY,
                             "ROI image file name not specified");
    buffer = load_raw_data(image_name);
  
    if (buffer == null || buffer.length == 0) {
      if (image_name.charAt(0) == '-' && image_name.charAt(1) == '\0')
        diagnostic_stream.println("Error: unable to read from stdin");
      else
        diagnostic_stream.println("Error: unable to read `" + image_name +
                                  "'");
      return;
    }
  
    try {
      j2k_object.AwJ2kSetOutputJ2kRoiFromImage(buffer, buffer.length);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_roi_from_image()
  {
    System.out.print("--set-output-j2k-roi-from-image <ROI image file name>\n" +
                     "Defines a region of interest from an image.  The image is input to the library\n" +
                     "through the memory-buffer interface, and its type is automatically determined.\n" +
                     "");
  }

  public void call__roi_image()
  {
    call__set_output_j2k_roi_from_image();
  }

  public void help__roi_image()
  {
    help__set_output_j2k_roi_from_image();
  }


  public void call__set_output_j2k_roi_from_image_type()
  {
    int image_type;
    String image_name;
    byte[] buffer;
  
    image_name = read_string(ARG_MANDATORY,
                             "ROI image file name not specified");
    buffer = load_raw_data(image_name);
  
    if (buffer == null || buffer.length == 0) {
      if (image_name.charAt(0) == '-' && image_name.charAt(1) == '\0')
        diagnostic_stream.println("Error: unable to read from stdin");
      else
        diagnostic_stream.println("Error: unable to read `" + image_name +
                                  "'");
      return;
    }
  
    image_type = read_type(ARG_MANDATORY, "ROI image type not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kRoiFromImageType(buffer, buffer.length,
                                                   image_type);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_roi_from_image_type()
  {
    System.out.print("--set-output-j2k-roi-from-image-type <ROI image file name> <ROI image type>\n" +
                     "Defines a region of interest from an image.  The image is input to the library\n" +
                     "through the memory-buffer interface, and its type is as given.\n" +
                     "");
  }

  public void call__set_output_j2k_roi_from_image_raw()
  {
    String image_name;
    byte[] buffer;
    int rows, cols, bit_depth;
    boolean interleaved;
  
    image_name = read_string(ARG_MANDATORY,
                             "ROI image file name not specified");
  
    rows = read_int(ARG_MANDATORY, "ROI image rows not specified");
    cols = read_int(ARG_MANDATORY, "ROI image columns not specified");
    bit_depth = read_int(ARG_MANDATORY,
                         "Total ROI image bit depth not specified");
  
    interleaved = read_boolean(ARG_OPTIONAL, null, false);
  
    buffer = load_raw_data(image_name);
  
    if (buffer == null || buffer.length == 0) {
      if (image_name.charAt(0) == '-' && image_name.charAt(1) == '\0')
        diagnostic_stream.println("Error: unable to read from stdin");
      else
        diagnostic_stream.println("Error: unable to read `" + image_name +
                                  "'");
      return;
    }

    try {
      j2k_object.AwJ2kSetOutputJ2kRoiFromImageRaw(buffer, rows, cols,
                                                  bit_depth, interleaved);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_roi_from_image_raw()
  {
    System.out.print("--set-output-j2k-roi-from-image-raw <ROI image file name> <rows> <columns> <bit_depth> [<interleaved>]\n" +
                     "Defines a region of interest from an image.  The raw image is input to the\n" +
                     "library throught the memory-buffer interface.  The size of the image is\n" +
                     "specified using <rows>, <columns>, and <bit_depth>.  Only one channel of the\n" +
                     "image is read.\n" +
                     "");
  }

  public void call__set_output_j2k_roi_from_file()
  {
    String image_name = read_string(ARG_MANDATORY,
                                    "ROI image file name not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kRoiFromFile(image_name);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_roi_from_file()
  {
    System.out.print("--set-output-j2k-roi-from-file <ROI image file name>\n" +
                     "Defines a region of interest from an image.  The image is input to the library\n" +
                     "through the file interface, and its type is automatically determined.\n" +
                     "");
  }

  public void call__set_output_j2k_roi_from_file_raw()
  {
    String image_name;
    int rows, cols, bit_depth;
    boolean interleaved;
  
    image_name = read_string(ARG_MANDATORY,
                             "ROI image file name not specified");
  
    rows = read_int(ARG_MANDATORY, "ROI image rows not specified");
    cols = read_int(ARG_MANDATORY, "ROI image columns not specified");
    bit_depth = read_int(ARG_MANDATORY,
                         "Total ROI image bit depth not specified");
  
    interleaved = read_boolean(ARG_OPTIONAL, null, false);

    try {
      j2k_object.AwJ2kSetOutputJ2kRoiFromFileRaw(image_name, rows, cols,
                                                 bit_depth, interleaved);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_roi_from_file_raw()
  {
    System.out.print("--set-output-j2k-roi-from-file-raw <ROI image file name> <rows> <columns> <bit_depth> [<interleaved>]\n" +
                     "Defines a region of interest from an image.  The raw image is input to the\n" +
                     "library throught the file interface.  The size of the image is specified using\n" +
                     "<rows>, <columns>, and <bit_depth>.  Only one channel of the image is read.\n" +
                     "");
  }

  public void call__set_output_j2k_roi_add_shape()
  {
    String shape_string;
    int shape;
    int x, y, width, height;
  
    if (argv[arg].equals("--roi-rect"))
      shape = AwJ2kParameters.AW_ROISHAPE_RECTANGLE;
    else if (argv[arg].equals("--roi-ellipse"))
      shape = AwJ2kParameters.AW_ROISHAPE_ELLIPSE;
    else {
      shape_string = read_string(ARG_MANDATORY,
                                 "ROI shape not specified");
      switch (shape_string.charAt(0)) {
      case 'r': case 'R':
        shape = AwJ2kParameters.AW_ROISHAPE_RECTANGLE;
        break;
      case 'e': case 'E':
        shape = AwJ2kParameters.AW_ROISHAPE_ELLIPSE;
        break;
      default:
        diagnostic_stream.println("Warning: Unknown ROI shape `" +
                                  shape_string + "' ignored");
        return;
      }
    }
  
    x = read_int(ARG_MANDATORY,
                 "ROI shape left coordinate not specified");
    y = read_int(ARG_MANDATORY,
                 "ROI shape top coordinate not specified");
    width = read_int(ARG_MANDATORY,
                     "ROI shape width not specified");
    height = read_int(ARG_MANDATORY,
                      "ROI shape height not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJ2kRoiAddShape(shape, x, y, width, height);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_j2k_roi_add_shape()
  {
    System.out.print("--set-output-j2k-roi-add-shape <shape> <left> <top> <width> <height>\n" +
                     "A filled shape is added to the region of interest.  The shapes are:\n" +
                     "  rectangle\n" +
                     "  ellipse\n" +
                     "");
  }
  public void call__roi_rect()
  {
    call__set_output_j2k_roi_add_shape();
  }
  public void help__roi_rect()
  {
    System.out.print("--roi-rect <left> <top> <width> <height>\n" +
                     "A filled rectangle is added to the region of interest.\n" +
                     "");
  }

  public void call__roi_ellipse()
  {
    call__set_output_j2k_roi_add_shape();
  }
  public void help__roi_ellipse()
  {
    System.out.print("--roi-ellipse <left> <top> <width> <height>\n" +
                     "A filled ellipse is added to the region of interest.\n" +
                     "");
  }


  public void call__set_output_j2k_clear_roi()
  {
    try {
      j2k_object.AwJ2kSetOutputJ2kClearRoi();
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_j2k_clear_roi()
  {
    System.out.print("--set-output-j2k-clear-roi \n" +
                     "Clears all region of interest information.\n" +
                     "");
  }

  public void call__set_output_jpg_options()
  {
    int quality;
  
    quality = read_int(ARG_MANDATORY,
                       "JPEG quality not specified");
    if ((quality < 0 && quality != -1) || quality > 100) {
      diagnostic_stream.println("JPEG quality not specified");
      return;
    }
  
    try {
      j2k_object.AwJ2kSetOutputJpegOptions(quality);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_jpg_options()
  {
    System.out.print("--set-output-jpg-options <quality>\n" +
                     "Sets the quality parameter for JPEG compression (not JPEG 2000).  The quality\n" +
                     "parameter ranges from 0 to 100. Set quality to -1 for lossless compression.\n" +
                     "");
  }

  public void call__quality()
  {
    call__set_output_jpg_options();
  }

  public void help__quality()
  {
    help__set_output_jpg_options();
  }

  public void call__set_output_com_geometry_rotation()
  {
    int angle = read_int(ARG_MANDATORY,
                         "Rotation angle not specified");
  
    try {
      j2k_object.AwJ2kSetOutputComGeometryRotation(angle);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_com_geometry_rotation()
  {
    System.out.print("--set-output-com-geometry-rotation <angle>\n" +
                     "Rotates the input image by <angle> degrees.  <Angle> must be an whole multiple\n" +
                     "of 90.\n" +
                     "");
  }

  public void call__rotate()
  {
    call__set_output_com_geometry_rotation();
  }

  public void help__rotate()
  {
    help__set_output_com_geometry_rotation();
  }

  public void
  call__set_output_com_image_size()
  {
    int aspect_ratio;
    long rows, cols; 

    rows = read_long(ARG_MANDATORY,
                     "Number of rows in output image not specified");
    cols = read_long(ARG_MANDATORY,
                     "Number of colums in output image not specified");
    aspect_ratio = read_int(ARG_OPTIONAL, null,
                            AwJ2kParameters.AW_J2K_PRESERVE_ASPECT_RATIO);

    try {
      j2k_object.AwJ2kSetOutputComImageSize(rows, cols, aspect_ratio);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }

  public void
  help__set_output_com_image_size()
  {
    System.out.print("--set-output-com-image-size" +
                     "<rows> <columns> [<aspect ratio>}\n" +
                     "Specifies the output image size. <Rows> and <columns> must be larger than or equal to \n" +
                     "original image size. The optional <aspect_ratio> argument indicates whether the image aspect \n" +
                     "ratio will be preserved. Use AW_J2K_PRESERVE_ASPECT_RATIO to preserve aspect ratio (and pad the \n" +
                     "image) or AW_J2K_MODIFY_ASPECT_RATIO to modify the image aspect ratio (no padding). Use \n" +
                     "--set-output-com-padding-value to specify the padding value. \n" +
                     "");
  }

  public void
  call__set_output_com_padding_value()
  {
    long padding_value;
    int channel_index;

    channel_index = read_channel();

    padding_value = read_long(ARG_MANDATORY,
                             "Padding value for output image not specified");

    try {
      j2k_object.AwJ2kSetOutputComPaddingValue(channel_index, padding_value);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }

  public void
  help__set_output_com_padding_value()
  {
    System.out.print("--set-output-com-padding-value" +
                     "<channel index> <padding value> \n" +
                     "Specifies the padding value of each channel for the situtation when the output image is resized and the aspect \n" +
                     "ratio is being preserved.  The channel index may be `all' to set the padding value for all channels.\n" +
                     "");
  }

  public void call__set_output_com_bit_depth()
  {
    int bit_depth;
    int channel_index;
    channel_index = read_channel();

    bit_depth = read_int(ARG_MANDATORY, "Bitdepth value for not specified");

    try {
      j2k_object.AwJ2kSetOutputComBitDepth(channel_index, bit_depth);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
  }

  public void help__set_output_com_bit_depth()
  {
    System.out.print(
      "--set-output-com-bit-depth " +
      "<channel index> <bit-depth> \n" +
      "Specifies the bitdepth of the output image, for each channel. <Bit-depth> must be smaller than\n" +
      "the original size. The channel index may be `all' to set the padding value for all channels.\n" +
      "Use --set-output-com-bit-depth-scaling-parameters to specify the scaling method and relevant parameters.\n" +
      "");
  }

  public void call__bit_depth()
  {
    call__set_output_com_bit_depth();
  }
  public void help__bit_depth()
  {
    help__set_output_com_bit_depth();
  }

  public void call__set_output_com_bit_depth_scaling_parameters()
  {
    int method;
    int channel_index;
    float parameter1, parameter2;

    channel_index = read_channel();

    method = read_int(ARG_MANDATORY, "Method for scaling not specified");
    parameter1 = read_float(ARG_OPTIONAL, "Parameter1 for bit-depth scaling not specified");
    parameter2 = read_float(ARG_OPTIONAL, "Parameter2 for bit-depth scaling not specified");

    try {
      j2k_object.AwJ2kSetOutputComBitDepthScalingParameters(
        channel_index, method, parameter1, parameter2);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }

  public void help__set_output_com_bit_depth_scaling_parameters()
  {
    System.out.print(
      "--set-output-com-bit-depth-scaling-parameters " +
      "<channel index> <method> <parameter1> <parameter2>\n" +
      "Specifies the method and relevant parameters for the bit-depth scaling of the output image.\n" +
      "");
  }

  public void call__bd_scaling()
  {
    call__set_output_com_bit_depth_scaling_parameters();
  }

  public void help__bd_scaling()
  {
    help__set_output_com_bit_depth_scaling_parameters();
  }

  public void call__set_output_raw_endianness()
  {
    String endianness_string;
    int endianness;
  
    endianness_string = read_string(ARG_MANDATORY,
                                    "Output Raw endianness not specified");
  
    switch (endianness_string.charAt(0)) {
    case 'b': case 'B':
      endianness = AwJ2kParameters.AW_J2K_ENDIAN_BIG;
      break;
    case 's': case 'S': case 'l': case 'L':
      endianness = AwJ2kParameters.AW_J2K_ENDIAN_SMALL;
      break;
    default:
      endianness = AwJ2kParameters.AW_J2K_ENDIAN_LOCAL_MACHINE;
    }
  
    try {
      j2k_object.AwJ2kSetOutputRawEndianness(endianness);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_raw_endianness()
  {
    System.out.print("--set-output-raw-endianness <endianness>\n" +
                     "Sets the endianness of an output raw image.  The endianness values are:\n" +
                     "  big\n" +
                     "  little\n" +
                     "");
  }

  public void call__set_input_j2k_error_handling()
  {
    String mode_string;
    int mode;

    mode_string = read_string(ARG_MANDATORY,
                              "Error handling mode not specified");
  
    switch (mode_string.charAt(0)) {
    case 's': case 'S':           /* strict */
      mode = AwJ2kParameters.AW_J2K_ERROR_STRICT_MODE;
      break;
    case 'r': case 'R':           /* resilient */
      mode = AwJ2kParameters.AW_J2K_ERROR_RESILIENT_MODE;
      break;
    default:
      diagnostic_stream.println("Warning: Error handling mode `" +
                                mode_string + "' not recognized.");
      return;
    }
  
    try {
      j2k_object.AwJ2kSetInputJ2kErrorHandling(mode);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_input_j2k_error_handling()
  {
    System.out.print("--set-input-j2k-error-handling <mode>\n" +
                     "Sets the error handling mode of the JPEG 2000 decoder.  The modes are:\n" +
                     "  resilient - attempts to recover from errors\n" +
                     "  strict    - stops decoding on the first error detection\n" +
                     "");
  }

  public void call__get_input_j2k_decoder_status()
  {
    try {
      AwInputDecoderStatusValue status =
        j2k_object.AwJ2kGetInputDecoderStatus();
      switch (status.getDecoderStatus()) {
      case AwJ2kParameters.AW_J2K_DECODER_FULL_DECODE:
        diagnostic_stream.println(
          "JPEG 2000 Decoder Status: codestream successfully decoded");
        break;
      case AwJ2kParameters.AW_J2K_DECODER_PARTIAL_DECODE_TRUNCATION:
        diagnostic_stream.println(
          "JPEG 2000 Decoder Status: codestream truncation detected");
        break;
      case AwJ2kParameters.AW_J2K_DECODER_PARTIAL_DECODE_CORRUPTION:
        diagnostic_stream.println(
          "JPEG 2000 Decoder Status: codestream corruption detected");
        break;
      }
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_input_j2k_decoder_status()
  {
    System.out.print("--get-input-j2k-decoder-status \n" +
                     "Returns the status of the JPEG 2000 decoder, which will signal whether a JPEG\n" +
                     "2000 image was successfully decoded, or whether errors were found\n" +
                     "");
  }

  public void call__set_output_dcm_style()
  {
    int style = AwJ2kParameters.AW_J2K_DICOM_LITTLE_ENDIAN_EXPLICIT_VR;
    String style_string;

    style_string = read_string(ARG_MANDATORY,
                               "DICOM coding style not specified");

    if (style_string != null) {
      switch (style_string.charAt(0)) {
      case 'b': case 'B': /* BEE */
        style = AwJ2kParameters.AW_J2K_DICOM_BIG_ENDIAN_EXPLICIT_VR;
        break;

      case 'l': case 'L': /* LEE/LEI */
        switch (style_string.charAt(2)) {
        case 'e': case 'E':
          style = AwJ2kParameters.AW_J2K_DICOM_LITTLE_ENDIAN_EXPLICIT_VR;
          break;
        case 'i': case 'I':
          style = AwJ2kParameters.AW_J2K_DICOM_LITTLE_ENDIAN_IMPLICIT_VR;
          break;
        default:
          diagnostic_stream.println("The DICOM coding style `" +
                                    style_string +
                                    "' not recognized; ignored");
        }
        break;

      default:
        diagnostic_stream.println("The DICOM coding style `" +
                                  style_string +
                                  "' not recognized; ignored");
      }
    }

    try {
      j2k_object.AwJ2kSetOutputDcmStyle(style);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_dcm_style()
  {
    System.out.print("--set-output-dcm-style <style>\n" +
                     "Sets the coding style of the output DICOM image.  The choices are:\n" +
                     "  LEE - Little-Endian, Explicit VR\n" +
                     "  LEI - Little-Endian, Implicit VR\n" +
                     "  BEE - Big-Endian, Explicit VR\n" +
                     ""
      );
  }

  public void call__set_input_jp2_color_profile_option()
  {
    long color_profile_flag = 0;
    String color_profile_flag_string;
  
    color_profile_flag_string =
      read_string(ARG_MANDATORY,
                  "JP2 color profile handling option not specified");
  
    if (color_profile_flag_string != null) {
      if (color_profile_flag_string.charAt(0) == 's' ||
          color_profile_flag_string.charAt(0) == 'S') {
        color_profile_flag = AwJ2kParameters.AW_JP2_COLOR_SKIP_SRGB_CONVERSION;
      }
      else {
        diagnostic_stream.println("The JP2 color profile handling option `" +
                                  color_profile_flag_string +
                                  "' not recognized; ignored");
      }
    }
  
    try {
      j2k_object.AwJ2kSetInputJp2ColorProfileOption(color_profile_flag);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_input_jp2_color_profile_option()
  {
    System.out.print("--set-input-jp2-color-profile-option <flag>\n" +
                     "Sets the color-profile handling option for the decoding of JP2 images.\n" +
                     "By default, color profiles are applied to JP2 images as they are decoded;\n" +
                     "use the value `skip' to get the raw color pixels.\n" +
                     "");
  }


  public void call__set_output_jp2_add_metadata_box()
  {
    int type, data_length, uuid_length;
    String data_file_name, uuid_file_name;
    byte[] uuid, data;

    uuid = null;

    type = read_jp2_box_type(ARG_MANDATORY,
                             "JP2 Metadata box type not specified");
  
    data_file_name = read_string(ARG_MANDATORY,
                                 "JP2 metadata file name not specified");
    data = load_raw_data(data_file_name);
  
    if (data == null || data.length == 0) {
      if (data_file_name.charAt(0) == '-' && data_file_name.charAt(1) == '\0')
        diagnostic_stream.println("Error: unable to metadata read from stdin");
      else
        diagnostic_stream.println("Error: unable to metadata read `" +
                                  data_file_name + "'");
      return;
    }
  
    if (type == AwJ2kParameters.AW_JP2_MDTYPE_UUID) {
      uuid_file_name = read_string(ARG_MANDATORY,
                                   "JP2 UUID file name not specified");
      uuid = load_raw_data(uuid_file_name);
  
      if (uuid == null || uuid.length == 0) {
        if (uuid_file_name.charAt(0) == '-' &&
            uuid_file_name.charAt(1) == '\0')
          diagnostic_stream.println("Error: unable to UUID read from stdin");
        else
          diagnostic_stream.println("Error: unable to UUID read `" +
                                    uuid_file_name + "'");
        return;
      }
    }
  
    try {
      j2k_object.AwJ2kSetOutputJp2AddMetadataBox(
        type, data, data.length, uuid, (uuid == null ? 0 : uuid.length));
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_jp2_add_metadata_box()
  {
    System.out.print("--set-output-jp2-add-metadata-box <type> <data file name> [<uuid file name>]\n" +
                     "Add the data found in <data file name> to a metadata box of a JP2 image.\n" +
                     "<type> is one of:\n" +
                     "  jp2i - to add intellectual property metadata\n" +
                     "  xml  - to add XML\n" +
                     "  uuid - to add an UUID box\n" +
                     "The <uuid file name> argument should be used only if adding a UUID box.  The\n" +
                     "UUID contained in that file must be 16 bytes long.\n" +
                     "");
  }


  public void call__set_output_jp2_add_UUIDInfo_box()
  {
    int num_uuid;
    String uuid_list_file_name, url;
    byte[] uuid;
  
    num_uuid = 0;
  
    uuid_list_file_name = read_string(ARG_MANDATORY,
                                      "UUID list file name not specified");
    uuid = load_raw_data(uuid_list_file_name);
  
    if (uuid == null || uuid.length == 0) {
      if (uuid_list_file_name.charAt(0) == '-' &&
          uuid_list_file_name.charAt(1) == '\0')
        diagnostic_stream.println("Error: unable to UUID list read from stdin");
      else
        diagnostic_stream.println("Error: unable to UUID list read `" +
                                  uuid_list_file_name + "'");
      return;
    }
  
    if (uuid.length % 16 != 0)
      diagnostic_stream.println(
        "Warning: found an incomplete UUID at the end of `" +
        uuid_list_file_name + "', discarding.");
    num_uuid = uuid.length / 16;
  
    url = read_string(ARG_MANDATORY, "URL not specified");
  
    try {
      j2k_object.AwJ2kSetOutputJp2AddUUIDInfoBox(uuid, num_uuid,
                                                 url, url.length());
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__set_output_jp2_add_UUIDInfo_box()
  {
    System.out.print("--set-output-jp2-add-UUIDInfo-box <UUID list file name> <url>\n" +
                     "Adds a UUID Information box to a JP2 image.  <UUID list file> is a file\n" +
                     "containing a list of the UUIDs to add to the box.  Each <uuid> is 16 bytes\n" +
                     "long.\n" +
                     "");
  }

  public void call__set_output_enum_colorspace()
  {
    int color_space;
    String color_space_string;
  
    color_space = AwJ2kParameters.AW_JP2_CS_DEFAULT;
  
    color_space_string =
      read_string(ARG_MANDATORY, "Color space not specified").toLowerCase();
  
    if (color_space_string != null) {
      if (color_space_string.equals("greyscale") ||
          color_space_string.equals("grayscale"))
        color_space = AwJ2kParameters.AW_JP2_CS_GREYSCALE;
      else if (color_space_string.equals("srgb"))
        color_space = AwJ2kParameters.AW_JP2_CS_sRGB;
      else if (color_space_string.equals("sycc"))
        color_space = AwJ2kParameters.AW_JP2_CS_sYCC;
      else if (color_space_string.equals("default"))
        color_space = AwJ2kParameters.AW_JP2_CS_DEFAULT;
      else 
        diagnostic_stream.println(
          "Warning: unrecognized color space `" + color_space_string +
          "' ignored.");
    }
  
    try {
      j2k_object.AwJ2kSetOutputEnumColorspace(color_space);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_enum_colorspace()
  {
    System.out.print("--set-output-enum-colorspace <color space>\n" +
                     "Sets the color space of the output image, which can be one of:\n" +
                     "  greyscale\n" +
                     "  sRGB\n" +
                     "  sYCC\n" +
                     "  default\n" +
                     "The default action is to set the color space to greyscale for single channel\n" +
                     "images, and sRGB for multi-channel images.\n" +
                     "");
  }

  public void call__set_output_jp2_restricted_ICCProfile()
  {
    String icc_profile_file;
    byte[] icc_buffer;
  
    icc_profile_file = read_string(ARG_MANDATORY,
                                   "ICC Profile file name not specified");
  
    icc_buffer = load_raw_data(icc_profile_file);
    if (icc_buffer == null || icc_buffer.length == 0) {
      if (icc_profile_file.charAt(0) == '-' &&
          icc_profile_file.charAt(1) == '\0')
        diagnostic_stream.println("Error: unable to read ICC profile from stdin");
      else
        diagnostic_stream.println("Error: unable to read ICC profile `" +
                                  icc_profile_file + "'");
      return;
    }
  
    try {
      j2k_object.AwJ2kSetOutputJp2RestrictedICCProfile(icc_buffer,
                                                       icc_buffer.length);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }

    return;
  }
  public void help__set_output_jp2_restricted_ICCProfile()
  {
    System.out.print("--set-output-jp2-restricted-ICCProfile <ICC Profile file>\n" +
                     "Reads a restricted ICC color space profile from the given file and uses it\n" +
                     "to set the output color space of a JP2 image, without performing any color\n" +
                     "conversions.\n" +
                     "");
  }

  public void call__get_output_j2k_layer_psnr_estimate()
  {
    int layer_index;
    AwInputPsnrValue psnr;

    layer_index = read_layer();

    try {
      psnr = j2k_object.AwJ2kGetOutputJ2kLayerPsnrEstimate(layer_index);
      if (layer_index == -1)
        diagnostic_stream.printf("pSNR estimate for entire image = %f\n",
                                 psnr.getPsnr());
      else
        diagnostic_stream.printf("pSNR estimate for layer %d = %f\n",
                                 psnr.getLayer_index(), psnr.getPsnr());
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_output_j2k_layer_psnr_estimate()
  {
    System.out.print("--get-output-j2k-layer-psnr-estimate <layer index>\n" +
                     "Returns the estimated pSNR for the specified layer. \n" +
                     "<Layer Index> can either be `all' for all layers or the index of the specific \n" +
                     "layer. For an image with N layers, layer index runs from 0 for the first \n" +
                     "layer to N-1 for all layers.  For images with more than one channel \n" +
                     "the value returned is the average estimate for all channels. \n" +
                     "This option should be used after the -o option, on the command line.\n" +
                     "");
  }


  public void call__get_input_jp2_num_metadata_boxes()
  {
    int type, metadata_box_count;
    String type_string;
    AwInputNumMetadataBoxesValue metadata_boxes;
    metadata_box_count = 0;
  
    type = read_jp2_box_type(ARG_MANDATORY,
                             "JP2 Metadata box type not specified");
    type_string = argv[arg];

    try {
      metadata_boxes = j2k_object.AwJ2kGetInputJp2NumMetadataBoxes(type);
      diagnostic_stream.println("Found " +
                                metadata_boxes.getNumMetadataBoxes() +
                                " " + type_string + " metadata boxes.");
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
  
    return;
  }
  public void help__get_input_jp2_num_metadata_boxes()
  {
    System.out.print("--get-input-jp2-num-metadata-boxes <box type>\n" +
                     "Prints the count of metadata box of the given type in an input JP2 image.\n" +
                     "The <box type> can be one of:\n" +
                     "  jp2i     - for Intellectual Property boxes;\n" +
                     "  xml      - for XML boxes;\n" +
                     "  uuid     - for UUID boxes; or\n" +
                     "  uuidinfo - for UUID Information boxes.\n" +
                     "");
  }



  public void call__get_input_jp2_metadata_box()
  {
    int type, metadata_box_index;
    String metadata_file_name, uuid_file_name;
    AwInputMetadataBoxValue metadata;
  
    uuid_file_name = null;
  
    type = read_jp2_box_type(ARG_MANDATORY,
                             "JP2 metadata box type not specified");
  
    metadata_box_index = read_int(ARG_MANDATORY,
                                  "JP2 metadata box index not specified");
  
    metadata_file_name = read_string(ARG_MANDATORY,
                                     "JP2 metadata file name not specified");
  
    if (type == AwJ2kParameters.AW_JP2_MDTYPE_UUID)
      uuid_file_name = read_string(ARG_MANDATORY,
                                   "JP2 UUID file name not specified");
  
    try {
      metadata =
        j2k_object.AwJ2kGetInputJp2MetadataBox(type, metadata_box_index);
      byte[] metadata_buffer = metadata.getMetadata();
      write_raw_data(metadata_file_name, metadata_buffer,
                     metadata_buffer.length);
      if (uuid_file_name != null) {
        byte[] uuid_buffer = metadata.getUuid();
        write_raw_data(uuid_file_name, uuid_buffer, uuid_buffer.length);
      }
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
  
    return;
  }
  public void help__get_input_jp2_metadata_box()
  {
    System.out.print("--get-input-jp2-metadata-box <box type> <box index> [<data file name> [<UUID file name>]]\n" +
                     "Prints, or optionally stores to the named files, the contents of the box of\n" +
                     "the given type and index.  The <box type> can be one of:\n" +
                     "  jp2i     - for Intellectual Property boxes;\n" +
                     "  xml      - for XML boxes;\n" +
                     "  uuid     - for UUID boxes; or\n" +
                     "The <UUID file name> may only be supplied if the <box type> is ``uuid''.\n" +
                     "");
  }


  public void call__get_input_jp2_UUIDInfo_box()
  {
    int uuid_box_index, uuid_count, uuid_length;
    byte[] uuid, url;
    String url_file_name, uuid_file_name;
    AwInputUUIDInfoBoxValue uuid_box;
  
    uuid_box_index = read_int(ARG_MANDATORY,
                              "JP2 UUID box index not specified");
  
    uuid_file_name = read_string(ARG_OPTIONAL, null, null);
    url_file_name = read_string(ARG_OPTIONAL, null, null);
  
    try {
      uuid_box = j2k_object. AwJ2kGetInputJp2UUIDInfoBox(uuid_box_index);
      uuid_count = uuid_box.getNumUUIDs();
      uuid_length = uuid_count * AwJ2kParameters.AW_JP2_UUID_LENGTH;
      uuid = uuid_box.getUUIDdata();
      url = uuid_box.getUrl();

      if (uuid_file_name != null) {
        write_raw_data(uuid_file_name, uuid, uuid.length);
      }
      else {
        diagnostic_stream.println("Contents of the UUID:");
        print_binary(diagnostic_stream, uuid);
      }
      if (url_file_name != null)
        write_raw_data(url_file_name, url, url.length);
      else
        diagnostic_stream.println(new String(url, 0, url.length, "US-ASCII"));
    }
    catch (java.io.UnsupportedEncodingException uee) {
      uee.printStackTrace(diagnostic_stream);
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
  
    return;
  }
  public void help__get_input_jp2_UUIDInfo_box()
  {
    System.out.print("--get-input-jp2-UUIDInfo-box <box index> [<UUID file name> [<URL file name>]]\n" +
                     "Prints, or optionally stores to the named files, the contets of the UUID\n" +
                     "Information box denoted by the given index.  If a single file name is given,\n" +
                     "The UUID list is stored to that file and the URL is printed to screen.\n" +
                     "");
  }

  public void call__get_input_jp2_enum_colorspace()
  {
    AwInputEnumColorspaceValue color_space;
  
    try {
      color_space = j2k_object.AwJ2kGetInputJp2EnumColorspace();
      switch (color_space.getEnumColorspace()) {
      case AwJ2kParameters.AW_JP2_CS_GREYSCALE:
        diagnostic_stream.println( "JP2 greyscale image image.\n");
        break;
      case AwJ2kParameters.AW_JP2_CS_sRGB:
        diagnostic_stream.println( "JP2 sRGB image image.\n");
        break;
      case AwJ2kParameters.AW_JP2_CS_sYCC:
        diagnostic_stream.println( "JP2 sYCC image image.\n");
        break;
      default:
        diagnostic_stream.println(
          "JP2 image image in an unknown color space.\n");
        break;
      }
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_input_jp2_enum_colorspace()
  {
    System.out.print("--get-input-jp2-enum-colorspace \n" +
                     "Prints the color space of a JP2 input image, if the color space is stored as\n" +
                     "an enumerated color space.\n" +
                     "");
  }

  public void call__get_input_jp2_restricted_ICCProfile()
  {
    String icc_file_name;
    AwInputICCProfileValue icc_data;
  
    icc_file_name = read_string(ARG_OPTIONAL, null, null);
  
    try {
      icc_data = j2k_object.AwJ2kGetInputJp2RestrictedICCProfile();
      if (icc_file_name != null)
        write_raw_data(icc_file_name, icc_data.getICCData(),
                       icc_data.getICCData().length);
      else {
        diagnostic_stream.println(
          "Contents of the Restricted ICC Color Profile:\n");
        print_binary(diagnostic_stream, icc_data.getICCData());
      }
    }
    catch (AwJ2kException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    return;
  }
  public void help__get_input_jp2_restricted_ICCProfile()
  {
    System.out.print("--get-input-jp2-restricted-ICCProfile [<file name>]\n" +
                     "Prints, or optionally stores to the named file, the color space of a JP2 input\n" +
                     "image, if the color space is stored as a Restricted ICC Profile.\n" +
                     "");
  }

  public void call__verbose()
  {
    verbosity_flag++;
    if (verbosity_flag > VERBOSITY_MAXIMUM_LEVEL)
      verbosity_flag = VERBOSITY_MAXIMUM_LEVEL;
    return;
  }
  public void help__verbose()
  {
    System.out.print("--verbose \n" +
                     "Increases the verbosity level of the program.\n" +
                     "");
  }

  public void call_v()
  {
    call__verbose();
  }

  public void help_v()
  {
    help__verbose();
  }

  public void call__quiet()
  {
    verbosity_flag--;
    if (verbosity_flag < VERBOSITY_MINIMUM_LEVEL)
      verbosity_flag = VERBOSITY_MINIMUM_LEVEL;
    return;
  }
  public void help__quiet()
  {
    System.out.print("--quiet \n" +
                     "Decreases the verbosity level of the program.\n" +
                     "");
  }

  public void call__benchmark()
  {
    benchmark_flag = read_int(ARG_OPTIONAL, null, 1);
    return;
  }
  public void help__benchmark()
  {
    System.out.print("--benchmark [<repetitions>]\n" +
                     "Enables benchmarking mode.\n" +
                     "");
  }

  public void call__verbose_to_stdout()
  {
    diagnostic_stream = System.out;
    return;
  }
  public void help__verbose_to_stdout()
  {
    System.out.print("--verbose-to-stdout \n" +
                     "Redirects all verbose and diagnostic output from stderr to stdout.  Note that\n" +
                     "this disables the use of stdout for retrieving images.\n" +
                     "");
  }


/* read_string: read a string argument from the args list */
  String read_string(int optional_flag, String err_message)
  {
    return read_string(optional_flag, err_message, null);
  }

  String read_string(int optional_flag, String err_message,
                     String default_value)
  {
    arg++;
    if (argv.length > arg && (argv[arg].charAt(0) != '-' ||
                              argv[arg].charAt(1) == '\0'))
      return argv[arg];
    else {
      arg--;
      if (err_message != null)
        diagnostic_stream.println(err_message != null);
      if (ARG_MANDATORY == optional_flag)
        System.exit(1);
    }
    return default_value;
  }

/* read_int: read an integer argument from the args list */
  int read_int(int optional_flag, String err_message)
  {
    return read_int(optional_flag, err_message, 0);
  }
  int read_int(int optional_flag, String err_message, int default_value)
  {
    arg++;
    if (argv.length > arg && (argv[arg].charAt(0) != '-' ||
                              Character.isDigit(argv[arg].charAt(1))))
      return Integer.parseInt(argv[arg]);
    else {
      arg--;
      if (err_message != null)
        diagnostic_stream.println(err_message != null);
      if (ARG_MANDATORY == optional_flag)
        System.exit(1);
    }
    return default_value;
  }
  long read_long(int optional_flag, String err_message)
  {
    return read_long(optional_flag, err_message, 0);
  }
  long read_long(int optional_flag, String err_message, long default_value)
  {
    arg++;
    if (argv.length > arg && (argv[arg].charAt(0) != '-' ||
                              Character.isDigit(argv[arg].charAt(1))))
      return Long.parseLong(argv[arg]);
    else {
      arg--;
      if (err_message != null)
        diagnostic_stream.println(err_message != null);
      if (ARG_MANDATORY == optional_flag)
        System.exit(1);
    }
    return default_value;
  }
/* read_int_or_string: read an argument from the args list, and return it
 * as either an Integer (if parseable as an int) or a String
 */
  Object read_int_or_string(int optional_flag, String err_message)
  {
    return
      read_int_or_string(optional_flag, err_message, null);
  }

  Object read_int_or_string(int optional_flag, String err_message,
                            Object default_value)
  {
    arg++;
    if (argv.length > arg && (argv[arg].charAt(0) != '-' ||
                              Character.isDigit(argv[arg].charAt(1)))) {
      int l = argv[arg].length();
      boolean number =
        (Character.isDigit(argv[arg].charAt(0))) ||
        (argv[arg].charAt(0) == '-');
      for (int c = 1; c < l && number; c++)
        number = number && (Character.isDigit(argv[arg].charAt(c)));

      if (number)
        return (Object)(new Integer(argv[arg]));
      else
        return (Object)argv[arg];
    }
    else {
      arg--;
      if (err_message != null)
        diagnostic_stream.println(err_message != null);
      if (ARG_MANDATORY == optional_flag)
        System.exit(1);
    }
    return default_value;
  }

/* read_int_or_all_string: read an argument from the list, and return
 * either its value or the `all' value if the string is "all"
 */
  int read_int_or_all_string(int value_for_all, int optional_flag,
                             String err_message, String name_of_arg)
  {
    Object value =
      read_int_or_string(optional_flag, err_message);

    if (value instanceof java.lang.String) {
      char c = ((String)value).charAt(0);
      if (c == 'a' || c == 'A')
        return value_for_all;
      else {
        diagnostic_stream.println("Warning: " + name_of_arg + " `" +
                                  ((String)value) + "' not recognized");
        return 0;
      }
    }
    else if (value instanceof Integer) {
      return ((Integer)value).intValue();
    }
    return 0;
  }

/* read_float: read a float argument from the args list */
  float read_float(int optional_flag, String err_message)
  {
    arg++;
    if (argv.length > arg && (argv[arg].charAt(0) != '-' ||
                              Character.isDigit(argv[arg].charAt(1))))
      return Float.valueOf(argv[arg]);
    else {
      arg--;
      if (err_message != null)
        diagnostic_stream.println(err_message);
      if (ARG_MANDATORY == optional_flag)
        System.exit(1);
    }
    return 0;
  }

/* read_boolean: read a boolean argument from the args list.  Anything
 * starting with 'T', 't', 'Y', 'y' is considered true; everything
 * else is false.
 */
  boolean read_boolean(int optional_flag, String err_message,
                       boolean default_value)
  {
    arg++;
    if (argv.length > arg && argv[arg].charAt(0) != '-') {
      switch (argv[arg].charAt(0)) {
      case 'T': case 't': case 'Y': case 'y':
        return true;

      default:
        return false;
      }
    }
    else {
      arg--;
      if (err_message != null)
        diagnostic_stream.println(err_message);
      if (ARG_MANDATORY == optional_flag)
        System.exit(1);
    }
    return default_value;
  }
  boolean read_boolean(int optional_flag, String err_message)
  {
    return read_boolean(optional_flag, err_message, false);
  }

  int
  read_type(int optional_flag, String err_message)
  {
    String type_string;
    type_string = read_string(optional_flag, err_message).toLowerCase();

    if (type_string.equals("j2k"))
      return AwJ2kParameters.AW_J2K_FORMAT_J2K;
    else if (type_string.equals("jp2"))
      return AwJ2kParameters.AW_J2K_FORMAT_JP2;
    else if (type_string.equals("raw"))
      return AwJ2kParameters.AW_J2K_FORMAT_RAW;
    else if (type_string.equals("tif") || type_string.equals("tiff"))
      return AwJ2kParameters.AW_J2K_FORMAT_TIF;
    else if (type_string.equals("pnm") || type_string.equals("pbm") ||
             type_string.equals("pgm") || type_string.equals("ppm"))
      return AwJ2kParameters.AW_J2K_FORMAT_PPM;
    else if (type_string.equals("dcm") || type_string.equals("dcm_raw"))
      return AwJ2kParameters.AW_J2K_FORMAT_DCM;
    else if (type_string.equals("dcm_j2k"))
      return AwJ2kParameters.AW_J2K_FORMAT_DCMJ2K;
    else if (type_string.equals("dcm_jpg"))
      return AwJ2kParameters.AW_J2K_FORMAT_DCMJPG;
    else if (type_string.equals("bmp"))
      return AwJ2kParameters.AW_J2K_FORMAT_BMP;
    else if (type_string.equals("tga") || type_string.equals("targa"))
      return AwJ2kParameters.AW_J2K_FORMAT_TGA;
    else if (type_string.equals("jpg") || type_string.equals("jpeg"))
      return AwJ2kParameters.AW_J2K_FORMAT_JPG;
    else if (type_string.equals("raw_i"))
      return AwJ2kParameters.AW_J2K_FORMAT_RAW_INTERLEAVED;
    else if (type_string.equals("pgx"))
      return AwJ2kParameters.AW_J2K_FORMAT_PGX;
    else if (type_string.equals("pdf"))
      return AwJ2kParameters.AW_J2K_FORMAT_PDFJP2;
    else
      System.err.println("Warning: Unrecognized type `" +
                         type_string + "' ignored. Defaulting to J2K");

    return AwJ2kParameters.AW_J2K_FORMAT_J2K;
  }
  
  int read_jp2_box_type(int optional_flag, String err_message)
  {
    String type;
    type = read_string(optional_flag, err_message);

    if (type.equalsIgnoreCase("jp2i"))
      return AwJ2kParameters.AW_JP2_MDTYPE_JP2I;
    else if (type.equalsIgnoreCase("uuid"))
      return AwJ2kParameters.AW_JP2_MDTYPE_UUID;
    else if (type.equalsIgnoreCase("uuidinfo"))
      return AwJ2kParameters.AW_JP2_MDTYPE_UUIDINFO;
    else if (type.equalsIgnoreCase("url"))
      return AwJ2kParameters.AW_JP2_MDTYPE_URL;
    else if (type.equalsIgnoreCase("xml"))
      return AwJ2kParameters.AW_JP2_MDTYPE_XML;
    else
      diagnostic_stream.println("Warning: Unrecognized type `" + type +
                                "' ignored. Defaulting to xml");
    return AwJ2kParameters.AW_JP2_MDTYPE_XML;
  }

  int read_tile()
  {
    return
      read_int_or_all_string(AwJ2kParameters.AW_J2K_SELECT_ALL_TILES,
                             ARG_MANDATORY, "Tile index not specified",
                             "tile index");
  }
  int read_channel()
  {
    return
      read_int_or_all_string(AwJ2kParameters.AW_J2K_SELECT_ALL_CHANNELS,
                             ARG_MANDATORY, "Channel index not specified",
                             "channel index");
  }
//void
//read_tile_and_channel(int *tile_index, int *channel_index, args_t *args,
//                      state_flags *flags)
//{
//  *channel_index = AW_J2K_SELECT_ALL_CHANNELS;
//
//  read_tile(tile_index, args, flags);
//  read_channel(channel_index, args, flags);
//}
  int read_layer()
  {
    return
      read_int_or_all_string(AwJ2kParameters.AW_J2K_GLOBAL_LAYER_INDEX,
                             ARG_MANDATORY, "Layer index not specified",
                             "layer index");
  }

  double get_precise_time()
  {
    return new Date().getTime() / (double)1000;
  }

  byte[] load_raw_data(String fileName)
  {
    BufferedInputStream bin = null;
    byte[] data             = null;
    try {
      bin = new BufferedInputStream(new FileInputStream(fileName));
      int numBytes = bin.available();
      data = new byte [numBytes];
      bin.read(data);
    }
    catch (IOException exc) {
      data = null;
    }
    finally {
      try {
        if (bin != null)
          bin.close();
      }
      catch (IOException exc) {}
    }

    return(data);
  }
  public void write_raw_data(String imageFileName, byte[] imageData,
                             int imageLength)
  {
    BufferedOutputStream bos = null;
    try {
      bos = new BufferedOutputStream(
        new FileOutputStream(imageFileName));
      bos.write(imageData, 0, imageLength);
    }
    catch (IOException exc) {
      exc.printStackTrace(diagnostic_stream);
    }
    finally {
      try {
        if (bos != null)
          bos.close();
      }
      catch (IOException exc) {}
    }
  }

  boolean is_printable(byte val)
  {
    String s = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_=+\\|`~[]{};:'\",.<>/? ";
    return s.indexOf(val) > -1;
    // Character.isWhitespace(val) ||
    //Character.isLetterOrDigit(val);
  }

  void print_binary(PrintStream out, byte[] buffer)
  {
    int c, d, e, f;
    e = (buffer.length/16)*16;
    f = 16;
    for (c = 0; c < buffer.length; c+=16) {
      out.printf("%08x: ", c);
      if (c == e)
        f = buffer.length % 16;
      for (d = 0; d < f; d++) {
        out.printf("%02x", buffer[c+d]);
        if ((d%2)==1)
          out.printf(" ");
      }
      for (; d < 16; d++) {
        out.printf("  ");
        if ((d%2)==1)
          out.printf(" ");
      }
      out.print("  ");
      for (d = 0; d < f; d++) {
        if (is_printable(buffer[c+d]))
          out.printf("%c", buffer[c+d]);
        else
          out.printf(".");
      }
      out.println("");
    }
  }


  public void usage()
  {
    try {
      Method[] methods = this.getClass().getMethods();
      for (int i = 0; i < methods.length; i++) {
        String s = methods[i].getName();
        if (s.startsWith("call_")) {
          System.err.println("  " + s.substring(4).replace("_", "-"));
        }
      }
    }
    catch (SecurityException e) {
      System.out.println(e);
    }

    System.exit(0);

  }

  public void run(String[] argv)
  {
    Class c = this.getClass();
    for (arg = 0; arg < argv.length; arg++) {
      try {
        String method;
        if (help_flag)
          method = "help" + argv[arg].replace("-", "_");
        else
          method = "call" + argv[arg].replace("-", "_");
        Method f = c.getMethod(method, (Class[])null);
        f.invoke(this, (java.lang.Object[])null);
      }
      catch (NoSuchMethodException e) {
        System.err.println("Error: Option `" + argv[arg] + "' not recognized");
        e.printStackTrace(System.out);
      }
      catch (IllegalAccessException e) {
        e.printStackTrace(System.out);
      }
      catch (InvocationTargetException e) {
        e.printStackTrace(System.out);
      }
    }

    if (help_flag && argv.length == 1)
      usage();
  }

  public static void main(String[] argv)
  {
    j2kdriver driver = new j2kdriver(argv);
    try {
      driver.run(argv);
    }
    catch (Exception e) {
      e.printStackTrace(System.out);
    }
    System.exit(0);
  }
}
