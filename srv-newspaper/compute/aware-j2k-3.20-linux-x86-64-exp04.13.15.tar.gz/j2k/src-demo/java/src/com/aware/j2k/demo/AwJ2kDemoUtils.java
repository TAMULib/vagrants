
 package com.aware.j2k.demo;

//  ******************************************************************
//  Copyright 2000 Aware, Inc.
//
//  $Workfile: AwJ2kDemoUtils.java $    $Revision: 3 $
//  Last Modified: $Date: 9/16/03 8:22a $ by: $Author: Esharp $
//
//  File   : AwJ2kDemoUtils.java
//  Creator: Stephen DelMarco
//
//  utilities for the J2K demonstration driver
//
//  ******************************************************************

 import java.io.*;
 import com.aware.j2k.codec.engine.*;


/**
  * This class contains utilities for the
  * java-wrapped JPEG2000 library demonstration driver
  *
  * @author Stephen DelMarco
  * @version 1.0,   Copyright (c) Aware, Inc., 2002
  *
  *
  */

 public class AwJ2kDemoUtils {


/**
  * This method writes out image data.
  *
  * @param imageFileName output image file name
  * @param imageData     output image byte data
  * @param imageLength   output image byte data length in number of bytes
  *
  * @throws com.aware.j2k.codec.engine.AwJ2kException
  */
  public static void writeImageFile(
                            String  imageFileName,
                            byte[]  imageData,
                            int     imageLength)  throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************

    BufferedOutputStream bos = null;
    try {
		bos             = new BufferedOutputStream(
                        	        new FileOutputStream(imageFileName));
        bos.write(imageData, 0, imageLength);
    }
    catch (IOException exc) {
        throw new AwJ2kException("***IOException during data writing= "+exc);
    }
    finally {
        try {
            if (bos != null)
              bos.close();
        } catch (IOException exc) {}
    }


}
/**
  * This method reads in image data.
  *
  * @param fileName input image data file name
  *
  * @return image data
  *
  * @throws com.aware.j2k.codec.engine.AwJ2kException
  */
  public static byte[] readImageFile(
                    String  fileName) throws AwJ2kException
{
// ******************************************************************
//
// ******************************************************************

    BufferedInputStream bin = null;
    byte[] data             = null;
    try {
        bin             = new BufferedInputStream(
                                    new FileInputStream(fileName));
        int numBytes    = bin.available();
        data            = new byte [numBytes];
        bin.read(data);
    }
    catch (IOException exc) {
        throw new AwJ2kException("***IOException during data reading= "+exc);
    }
    finally {
        try {
            if (bin != null)
              bin.close();
        } catch (IOException exc) {}
    }

    return(data);
}






} // end of class



