package com.aware.j2k.demo;

//  ******************************************************************
//  Copyright 2000 Aware, Inc.
//
//  $Workfile: AwJ2kResolutionDemo.java $    $Revision: 2 $
//  Last Modified: $Date: 9/16/03 8:23a $ by: $Author: Esharp $
//
//  File   : com.aware.j2k.demo.AwJ2kResolutionDemo.java
//  Creator: Stephen DelMarco
//
//  a demonstration driver showing how to use the java-wrapped
//  JPEG2000 library to decompress sub-resolution images
//
//  ******************************************************************

 import com.aware.j2k.codec.engine.*;
import com.aware.j2k.codec.engine.AwJ2kParameters;


/**
  * This class is a demonstration driver showing how
  * to use the java-wrapped JPEG2000 library to decompress 
  * sub-resolution images. 
  *
  * @author Stephen DelMarco
  * @version 1.0,   Copyright (c) Aware, Inc., 2002
  *
  */

 public class AwJ2kResolutionDemo {






/**
  * This method is the main method.
  *
  * @param argv command line arguments
  */

  public static void main(String argv[])
{
// ******************************************************************
//
// ******************************************************************

    runResLevelDemo();

}
/**
  * This demo shows how to decompress sub-resolution images contained
  * in the JPEG2000 codestream. First, the image is compressed,
  * using a resolution-progressive progression order. Five levels
  * of wavelet transform are used, which provide six resolution levels:
  * five sub-resolution images and one full resolution image. After compression 
  * each of the five available sub-resolution image is decompressed. The
  * decompression starts from the largest sub-resolution image and ends
  * with the smallest sub-resolution image. In this example the
  * the input image file is a 512 by 512 rgb color image in bmp
  * format named lena.bmp. The decompressed images are contained in
  * files named recX_lena.bmp, where X refers to the resolution level.
  */
  public static void runResLevelDemo()
{
// ******************************************************************
//
// ******************************************************************

// ---------- hard code compression parameters

    String inputFileName        = "lena.bmp";
    int outputFileType          = AwJ2kParameters.AW_J2K_FORMAT_J2K;
    String outputFileName       = "lena_cmp.j2k";
    int progOrder               = AwJ2kParameters.AW_J2K_PO_RESOLUTION_LAYER_COMPONENT_POSITION;
    int transformType           = AwJ2kParameters.AW_J2K_WV_TYPE_R53;
    int numTransformLevels      = 5;

 // ---------- hard code decompression parameters
   
    int recOutputFileType       = AwJ2kParameters.AW_J2K_FORMAT_BMP;
    int full_xform_flag         = 0; // does not interpolate to present a full size image
        
// ---------- run demo

    AwJ2k codec = null;
    try {
// --------------------------------------------------- compression
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(inputFileName);
        codec.AwJ2kSetOutputType(outputFileType);
        codec.AwJ2kSetOutputJ2kProgOrder(progOrder);
        codec.AwJ2kSetOutputJ2kXform(transformType, numTransformLevels);
        codec.AwJ2kGetOutputImageFile(outputFileName);
        codec.AwJ2kDestroy();
// --------------------------------------------------- decompression
        codec = new AwJ2k();
        codec.AwJ2kSetInputImageFile(outputFileName);       // set the input image to be the compressed image  
        codec.AwJ2kSetOutputType(recOutputFileType);        // set decompressed image type
        AwProgressionInfoValue valueObj= codec.AwJ2kGetProgressionInfo();
    	int numResLevels  = valueObj.getOutputNumTransformLevels(); // get num res levels
        for (int i=2; i<=numResLevels; ++i) {               // loop over sub-res images and decompress          
          codec.AwJ2kSetInputJ2kResLevel(
                                        i,                  // resolution_level
                                        full_xform_flag);   // indicates if interpolation is used
          codec.AwJ2kGetOutputImageFile("rec"+i+"_"+inputFileName); // decompress to an output file              
        }
        codec.AwJ2kDestroy();
    }
    catch (AwJ2kException exc) {
        System.out.println(" AwJ2kException exc= "+exc.getMessage());
        exc.printStackTrace();
    }


}





} // end of class



