Aware JPEG2000 SDK
Version 3.20.0
December 8, 2014


See the changes.txt file for a complete release history

See the LICENSE file for license details

The SDK installs the following files:

Folder Description
-----------------------------------
\bin                     Demo executable
\include                 C/C++ include files
\java                    Java jar file and javadoc
\lib                     C/C++ LIB files
\manuals                 SDK documentation
\samples                 Sample data files
\src-demo                Source code for demo application